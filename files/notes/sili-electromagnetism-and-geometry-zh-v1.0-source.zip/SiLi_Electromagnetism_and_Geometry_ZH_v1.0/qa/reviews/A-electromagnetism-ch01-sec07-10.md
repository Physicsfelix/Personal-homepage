# 电磁1.7–1.10独立源审校（A）

结论：四单位当前exact字节批准。实际逐幅读原物22–27全6页1.8倍图，逐段式核Gauss链环数/Faraday/Ampère–Maxwell/势与规范全部正文、推导、定向、系数与原交叉引。

| 文件 | 当前SHA256 |
|---|---|
| book/chapters/ch01-sec07.tex | `6266dc6bf5f3be35d63cdaed7dfff0c0269d82e5840320b843c2eff5c209bdd0` |
| book/chapters/ch01-sec08.tex | `892d73c045047cf22b8287118f8a9b94c5a2fb93458c37c00aebb541e890f42d` |
| book/chapters/ch01-sec09.tex | `fcc53dc87c51fdc1bc333abe948df6deb4ada5700682e95e93b86149f11d95b3` |
| book/chapters/ch01-sec10.tex | `65034916a078bf78d0b0ef42a1ead7ad4911409bb7eb932b06a460d337ac3b7e` |

四原图全部保留。两原crop我实际看，并独立从当前源4倍重建逐像素相等；两重画TikZ从当前exact文件独立抽出编译2页，实际3倍看Gauss链环上下交叉/电流方向及Faraday五场线/B/S/C标签，正确对应原页。实际测试PDF和资产SHA在JSON。

“任意曲线以圆盘填充”的原文保留，关于一般带结曲线须用定向张成曲面或奇异2链的短注独立核验正确。其他三节没有新增注。Lorenz规范d*A的星紧随d是Hodge星复合，d^*A则是伴随；原两种写法精确保留。Box负号和全部c⁻²/ε₀/μ₀归一化逐式核。

本报告不代签最终全文PDF视觉、目录导航或冷编。
