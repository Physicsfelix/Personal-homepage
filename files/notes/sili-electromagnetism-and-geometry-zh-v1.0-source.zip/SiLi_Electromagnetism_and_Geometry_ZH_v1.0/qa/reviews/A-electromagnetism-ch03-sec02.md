# 电磁学 §3.2 独立审校

批准当前五叶。A实际逐页阅读原物理72–77，所有段、显示式、数学行、粒子/电路表逐格与原练习提示均核齐；三原例完整，未添加练习答案。

独立复算内乘与运动通量负号、Faraday磁通量定则、互感对称性、自感匝数/长度因子和全部静磁能链。原首n后N真实大小写切换，短注准确。73页charge在flux变化上下文按change译，原字已以source comment留证，未替换任何作者数学式。

五幅PNG图实际4倍逐幅看，实际源同clip独立重算尺寸/RGB全部相等。跳环nativePDF实际3倍看，两处英语标签译金属环/螺线管，数学几何/电流箭头/蓝色环齐；掩去两标签区域后有33像素抗锯齿级差异、单通道最大14/255，未声称像素全同。

- `book/chapters/ch03-sec02-intro.tex` SHA256 `4a0714a5ab5471ba1c0921872bc80f1b4c14a7480966c72c2cd18797e485d814`；4源锚。
- `book/chapters/ch03-sec02-sub01.tex` SHA256 `2d0363bb07246550ce5b75020810c7530a61d1ba6dd39ad73730e43c7aeb700b`；35源锚。
- `book/chapters/ch03-sec02-sub02.tex` SHA256 `4be5f6af9ddbfc5e5e065a388f3f00daf0ab54732f2ea2e751459f870346ad88`；15源锚。
- `book/chapters/ch03-sec02-sub03.tex` SHA256 `f19fe85fd0fe3275d16693d0d40ecaa08c4a8edec43ddfccde20436d6df90603`；12源锚。
- `book/chapters/ch03-sec02-sub04.tex` SHA256 `724805d491b7d3eea4fe67c3cf03ef80182cbe25b4a60644538627ac969d4108`；32源锚。

源SHA256 `44a7ce8867705d62c53cfa0aecaa879642ebb060cc10623b4a331d84ace0db41`，所有当前字节与A读稿快照一致，批准快照已另存。无待修发现；本次不作为最终全页PDF版式或冷重建结论。
