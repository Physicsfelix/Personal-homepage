# EM ch05-sec02-sub02 独立源审

B 对 root 译稿，当前 SHA `cd23d3a3cea41564c32d6dd3d43c24b51231814f1e7875af8af8ea7eadf7b17f`，approved。

实际原页：[151]，每全页2x，逐段式及全部原编号/证明/注核验。

完整J电荷电流1form/Λ拉回与两个求值点/boost矩阵/ρ及j四行及末说明完整；原10个粗体电流j已恢复，B原审before与current差分逆还原严格成立。

独立由J0=ρ/(ε0c)、Ji=−μ0ji及ε0μ0=1/c²得到原ρ加v jx/c²及jx加ρv，正号与pullback约定一致。

不据此签署合编译本 PDF 最终版式。