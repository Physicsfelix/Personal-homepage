电磁 §3.5 三单元当前源语义独立批准。A 实际逐页读取原物理88–92全五页，完整对照章导语、球面源、远区两类展开、电流积分至偶极矩、磁场两项、电场两条推导、Poynting向量、角向积分、Larmor例及所有中间式与源锚。原1例、3图组、无原脚注或习题，无新增解答。

独立计算核对全部符号及4π、c、μ0因子；原j′未定义的最短注成立，当前作者全文不需修改。

两个PNG各以原PDF同clip/4x独立重算，RGB和尺寸严格相同，并实际逐图看；一个nativePDF仅dipole译偶极子，A在3x原clip独立对比，标签区域外像素差为0，且实际看全部角度、坐标、箭头、点与中文标签。报告不把源资产核对冒称最终整书版式验收。

- book/chapters/ch03-sec05-intro.tex：`4fb89a89e4a1ec798768612532e427c9f6bdde096db67a247e4e9f6af565e337`；8锚，actual快照qa/reviews/A-ch03-sec05-current-approved-snapshots/ch03-sec05-intro.tex。
- book/chapters/ch03-sec05-sub01.tex：`3fd3bc0cef2f512de304db3398a057bdf11db21cd491cbad7ff5a1c7aa873ae8`；14锚，actual快照qa/reviews/A-ch03-sec05-current-approved-snapshots/ch03-sec05-sub01.tex。
- book/chapters/ch03-sec05-sub02.tex：`58050f3421424631962924df3c351e732104e4dd5eb72a324a9646d5bb9171f7`；78锚，actual快照qa/reviews/A-ch03-sec05-current-approved-snapshots/ch03-sec05-sub02.tex。
