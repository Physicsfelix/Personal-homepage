# 电磁1.4–1.5独立源审校（A）

结论：两文件当前exact字节批准，原物17–20实际1.8倍全页看，逐段式核完整Coulomb/Gauss推导、场概念说明、Ampère历史介绍与稳恒方程。

| 文件 | 当前SHA256 |
|---|---|
| book/chapters/ch01-sec04.tex | `dad81989b1c8bfdec4e008486273531ebe0e86e5c6481f1ace977ec3ac5cfed4` |
| book/chapters/ch01-sec05.tex | `32cb400b4a9de69e12e7c4af67239eadd0aa6b38540ff9c80ec5c7a7f0dd7b10` |

四图完整，两重画图的电荷/位移方向与S、S′、N相对包含关系已核，两原图crop已独立按当前源PDF/4x/clip重建且逐像素同，绑定实际资产SHA。分布恒等式−4πδ、Gauss归一化ε₀与稳恒电流相容性均核。没有新增题解或译校注。最终版式、目录导航、冷编另验。
