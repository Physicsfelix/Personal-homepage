# 电磁讲义首批前后置独立源审校（A）

结论：封面、反馈、前言、女儿画作页4单位当前exact字节批准。译者C，审者A。实际单页1.8倍看原物1、2、6、7；逐段核全部文字、题名、版本年月、作者与学校、URL/邮箱、前言人名与致谢、画作说明。

原PDF SHA256 `44a7ce8867705d62c53cfa0aecaa879642ebb060cc10623b4a331d84ace0db41`。

| 文件 | 当前SHA256 |
|---|---|
| book/matter/cover.tex | `ddecb02eeef729cf4b096cbf533cccd8c68ea01357555a5e4905d3743de5b295` |
| book/matter/front-support.tex | `02d5f19dc490b26b81641d0ce59d983852e28183cdeb69f1a43ef8f883e4c42a` |
| book/matter/front-preface.tex | `daaec257184f6597185fd50f5bcf40ad8a87b89278eb38e5188a696fbe9f1007` |
| book/matter/front-artwork.tex | `abfc205031679d429953c143236ad6dc0765cd5f8aeaee3d1f6a1db809c255b8` |

三资产均实际查看；QR与画作分别与原PDF XObject77/212提取的编码JPEG逐byte相等；封面符号与独立重建XObject5+softmask4后编码PNG逐byte相等。见JSON实际SHA。符号合成PNG经premultiplied/unpremultiplied步骤会有边缘1级色值舍入，不能以直接premultiplied samples误称图像有改动；独立编码重建完全一致。

原全局目录尚待全部标题集成后另审，未计本次4单位。当前译稿最终排版与冷编另验。
