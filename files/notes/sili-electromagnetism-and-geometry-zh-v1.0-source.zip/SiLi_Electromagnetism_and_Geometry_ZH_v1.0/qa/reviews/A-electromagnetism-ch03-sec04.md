EM §3.4 独立逐源审校通过。A 实际逐幅阅读原物理83–88共六页，完整对照四当前单元的全部段落、公式每行、空间与时间两类边界项、延迟/超前两情形及最终 Lorenz 规范证明。本节无原编号对象、图、脚注或练习。

独立分部积分核对所有边界符号；核对径向 Laplacian、4π 归一化、源项和 c² 因子。源点/观测点逆序、超前段源位置 r/r′、末梯度只作用 G 的三原注均数学成立，区域 V∈R³ 的原误记现保留并说明。

两处修订由 A 先捕获 before 原字节；C 所存 before 与 A 相同，A 独立按指定替换从旧字节重建当前全文，正逆严格一致：三个标量 A 分量恢复原 CMMI 普通斜体，V∈R³ 原记号恢复并追加最短可见说明。作者其余正文、行尾与全部锚保持。

本报告只批准当前源语义，不替代最终全书版式、交互、实际包及冷编验收。

- book/chapters/ch03-sec04-intro.tex：`f411b1058c5656b691abcb8a574dbb64eab3e6374017155cfd59ac29995f4cfa`；1 源锚；快照 qa/reviews/A-ch03-sec04-current-approved-snapshots/ch03-sec04-intro.tex。
- book/chapters/ch03-sec04-sub01.tex：`89218f3047a18847e1bcde576384b2a2c128a6dee0cd267b6ca3cba6d1743d28`；41 源锚；快照 qa/reviews/A-ch03-sec04-current-approved-snapshots/ch03-sec04-sub01.tex。
- book/chapters/ch03-sec04-sub02.tex：`cb7930f648c390ad89d9d4e55a6c5128ae4ba4a174c44841fedb57170d653337`；47 源锚；快照 qa/reviews/A-ch03-sec04-current-approved-snapshots/ch03-sec04-sub02.tex。
- book/chapters/ch03-sec04-sub03.tex：`66c942b6af9e8c9945401d261c04e818ce5df91193af5277409134a634e5cc35`；47 源锚；快照 qa/reviews/A-ch03-sec04-current-approved-snapshots/ch03-sec04-sub03.tex。
