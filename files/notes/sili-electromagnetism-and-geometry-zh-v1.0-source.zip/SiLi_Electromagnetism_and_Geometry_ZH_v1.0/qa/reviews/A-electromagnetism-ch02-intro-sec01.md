# 电磁第二章导语与2.1完整独立源审校（A）

结论：6单位当前exact字节批准。实际看原物28–34全7页1.8倍图，逐段式对照至2.2前；Poisson/Laplace边值表述、点电荷、均匀球内外场与分段势、线电荷的全部r±代数及两极限展开完整，未新增解答。

| 文件 | 当前SHA256 |
|---|---|
| book/chapters/ch02-intro.tex | `713f8b9d803649e26bb50bcd2c98fb09326b8bcee764fa92a2003cb1b564efd5` |
| book/chapters/ch02-sec01-intro.tex | `2545e06db68b9dc92a564090c2d795bb28f6d8f14dc685bbcb4a3f3824bb6cc7` |
| book/chapters/ch02-sec01-sub01.tex | `3f706e996f79e6b0fe5c45360cbf7ccf6d35beb223dd87dfa64d8f08a1d7c313` |
| book/chapters/ch02-sec01-sub02.tex | `abe6d6b28ca8fcdebb90408cd5c0a81a67fde75b5317b591e7d794e744f30df8` |
| book/chapters/ch02-sec01-sub03.tex | `0caebedde3d7e6219ca2f1b0327c1c19dcb05d45ad949d82dbc69e2ceeac7a48` |
| book/chapters/ch02-sec01-sub04.tex | `d82899bd5511145a3af21baf1b5d9002491d63d53252123d6612572ec4baba3c` |

点电荷积分δ中缺撇号为实际源误；短注独立核算正确。原式按底本保留。源30底到31首的球内部段落用跨页源锚正确覆盖。

8图组/9面板全核。A从当前exact源码独立抽7个TikZ编7页、实际逐图2.5倍看；原33等势图actual4x crop独立重建逐像素相等。发现球图R标签被阴影斜线穿过，已只移动该标签到箭头右上，不改任何图线/正文/公式。C修前actualbytes与A先存阅读快照逐byte相等，指定唯一node替换精确生成当前；A再从新源码独立抽图编1页3倍实际看R不交线，问题关闭。

最终整书PDF翻页、版式及冷编另验。本次不把源34上2.2文字算作已审。
