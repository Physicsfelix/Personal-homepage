# EM ch05-sec03-sub01 独立源审

B 对 root 译稿，当前 SHA `e9b01aa55030d18de058abe1a75e9edc79f19fc38e774b77841e6cd02967e0fe`，approved。

实际原页：[154]，每全页2x，逐段式及全部原编号/证明/注核验。

非相对论Lorentz力/轨迹/Newton方程/完整Lagrangian和作用量及原外书例1.2.3引用完整，标势φ与粗体向量A/F/E/B、plain轨迹r按源保持。

不据此签署合编译本 PDF 最终版式。