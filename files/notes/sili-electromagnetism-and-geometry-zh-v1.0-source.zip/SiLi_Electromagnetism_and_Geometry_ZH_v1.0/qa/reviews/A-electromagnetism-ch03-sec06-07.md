电磁 §3.6–3.7 两单元当前独立逐源审校通过。A 实际逐幅读原93–100共八页，完整比对 δ 换元、延迟时刻存在/唯一讨论、全部 Liénard--Wiechert 长微分链、两个匀速例及其 Cartesian 分量、Thomson 与 Rayleigh 散射全过程。全部167锚逐定位；原2例、4图组、无习题/脚注，不补答案。

四条译校注均独核：矢势δ漏撇、δ复合须单根与绝对Jacobian、亚光速本身不保证延迟时刻存在、匀速矢势漏电荷因子。A 独立构造 c=1、ξ(s)=(√(1+s²),0,0)、观察事件(0,0)，其 f(s)=s+√(1+s²)>0 而速率始终<1，确认存在性注；再由统一上界vmax<c的估计确认注中充分条件。

四PNG均由A用原PDF同clip/4x独立重算，尺寸与RGB严格相同，并逐幅实际看全部点、撇号、夹角、长度、实虚线与方向。当前两TeX全文与A初捕获字节完全相同，不需作者修订。最终整书版式及交互/冷包仍另验。

- book/chapters/ch03-sec06.tex：`1e270a89f8bed07aa6ffe9ff2539a4a8128cd2e609126803aebc5bc58fdac60d`；129源锚；快照qa/reviews/A-ch03-sec06-07-current-approved-snapshots/ch03-sec06.tex。
- book/chapters/ch03-sec07.tex：`bf30f4b08694668ea829535df5f35af144066aa695a1bdaba96f89a0866ed956`；38源锚；快照qa/reviews/A-ch03-sec06-07-current-approved-snapshots/ch03-sec07.tex。
