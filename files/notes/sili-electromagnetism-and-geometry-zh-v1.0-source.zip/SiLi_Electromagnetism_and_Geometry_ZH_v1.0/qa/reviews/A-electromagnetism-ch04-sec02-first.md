电磁4.2导语、4.2.1垂直向量场、4.2.2联络1形式三叶当前独立源审批准。A实际逐幅读原112–115全四页，到4.2.3标题前；全部三个原号、无穷小右作用、曲线/导数/垂直性与2π周期、联络两条件及平凡/一般局部坐标表达每行完整比对。无原脚注或习题，无新译校注或新增题解。

独核U(1)连通性下Lie导数零等价旋转不变，及i_VA=1、theta方向不变给出原局部式。逐span核A及系数Euler、Lie导L的rsfs、Lie代数g的Fraktur三种源字体，当前保留。

三native图逐幅实际看，2PNG与sourceclip/4x独立RGB和尺寸exact；输运PDF仅两英语词组译中文，源γ保留，标签外13像素最大15/255细微栅格差，全部几何/端点/箭头/标签实际核。2数学图actual私抽编2页并2.5x实际看。三个TeX当前字节与A最初捕获完全相同，无需作者修改；最终整书布局等另验。

- book/chapters/ch04-sec02-intro.tex：`cb35597b0839d3a06b5360606c2381f2fe7dca7223f331c5ea771a4b8440dc9f`；10锚；快照qa/reviews/A-ch04-sec02-first-current-approved-snapshots/ch04-sec02-intro.tex。
- book/chapters/ch04-sec02-sub01.tex：`9d6f787c510cdf4976ecccce7b35742fc2f577f748ba67651163ec0b235ce8f5`；17锚；快照qa/reviews/A-ch04-sec02-first-current-approved-snapshots/ch04-sec02-sub01.tex。
- book/chapters/ch04-sec02-sub02.tex：`4ef5de420e0da781c24d469b36b414fe0c9ffa3466340011df5af7c521850095`；28锚；快照qa/reviews/A-ch04-sec02-first-current-approved-snapshots/ch04-sec02-sub02.tex。
