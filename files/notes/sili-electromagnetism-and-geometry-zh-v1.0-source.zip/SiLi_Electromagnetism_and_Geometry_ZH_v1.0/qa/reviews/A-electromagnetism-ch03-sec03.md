# 电磁学 §3.3 独立审校

批准当前五叶。A实际1.7倍逐页阅读原物理78–83，范围自3.3标题至83页3.4标题之前；原所有段、Maxwell/波动方程、平面波约束、三偏振情形、双Fourier积分及全部c.c.项逐式逐行核齐。原评注3.3.1完整，无原脚注/练习，未添加答案。

独立复算真空c因子、旋度约束双符号、偏振相位与原旋向、复振幅双线性点积注、正负波矢交项以及电/磁能交项抵消，最终总能量系数epsilon0/[2(2pi)^3]准确。实际字体span核傅里叶系数E为EUSM、E1/E2为原粗体；当前符号分清楚。

七幅当前PNG原图实际4倍逐幅看，轴/旋向箭头/大小关系及端点全齐；独立从实际原PDF同clip重算尺寸与RGB全部相等。原时间/空间频率和左右圆偏振英语图注完整译中，未更换作者旋向约定。

- `book/chapters/ch03-sec03-intro.tex` SHA256 `644eac1ca07e8389119b0f518c56845fbdb4a4f4865328eadae398a0c7cf2e0e`；2源锚。
- `book/chapters/ch03-sec03-sub01.tex` SHA256 `f4f8b87d2fd4711153ade12d93ae3db170a40b4f3a3844f0628a2febc15569d5`；24源锚。
- `book/chapters/ch03-sec03-sub02.tex` SHA256 `91782ae925ed4e0edc30c6f378309126380d50032c689a91dcb4b1cedeb11d0b`；34源锚。
- `book/chapters/ch03-sec03-sub03.tex` SHA256 `d483a1910f75bf010424b2d7b157436b7b011c27767ed7dfc6ca13739a8e97ff`；31源锚。
- `book/chapters/ch03-sec03-sub04.tex` SHA256 `9c365407b8180ece57efc6e0b9f17b16e8f720e5fdd51fc9bf08ba88e24bd852`；27源锚。

源SHA256 `44a7ce8867705d62c53cfa0aecaa879642ebb060cc10623b4a331d84ace0db41`，当前raw字节与A实际读稿快照相等，批准快照已保存。无未闭合发现。本次为源语义/数学/图内容独审，不冒称最终全页版式或冷重建通过。
