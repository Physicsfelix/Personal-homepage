# EM ch05-intro 独立源审

B审root译稿，当前 `c7c4021490240d702beb7fcdb1a57689da270afca8a4b2abae07818c720a937f` 已通过。原物理页[144]逐页2x，完整段式/原号/证明/源误注实际核。

章导语全部Lorentz历史/相容性与Maxwell目标完整。

不签最终合编PDF或包。