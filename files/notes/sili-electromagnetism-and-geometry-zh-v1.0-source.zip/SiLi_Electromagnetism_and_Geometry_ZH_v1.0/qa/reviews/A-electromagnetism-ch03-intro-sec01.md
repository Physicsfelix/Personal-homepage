# 电动力学导语与 §3.1 独立审校

批准当前四叶。A实际1.7倍逐页阅读原物理67–72，范围至72页3.2标题之前；所有自然段、显示式、每个数学行及源锚完整对照。原五例全部推导与七原图完整，含v_z=0图注；无原脚注/练习，未新增答案。

独立核验静电与稳流合力对称号/分部积分衰减条件、回旋解、Poynting全能量链/外流号、球壳能量积分、平面波正频与能量流关系。原F2m比较记号与正频范围两注分别从可见原字及公式独立复核正确。七幅当前native图实际4倍逐幅看，并从实际原PDF同clip重算，尺寸与RGB全相等；吸引/排斥图注完整译为中文。

- `book/chapters/ch03-intro.tex` SHA256 `6986654705f97c186f7f13918cd84ef11c5cfacb5ade826e402dcfe545f961f9`；2源锚。
- `book/chapters/ch03-sec01-intro.tex` SHA256 `4237c82414c39f36bd57fae478baef1d4e6a9add13d4049231b77aa4c49a8db7`；1源锚。
- `book/chapters/ch03-sec01-sub01.tex` SHA256 `14412dbf403cb4777cbdfd06c3d574347078c804bcbe73ebb79bf8028d850a0b`；44源锚。
- `book/chapters/ch03-sec01-sub02.tex` SHA256 `25536e0a8dcc320d01086c1cbd49493d9a6f970bab494cbf0c5600766fdfb9c7`；59源锚。

源SHA256 `44a7ce8867705d62c53cfa0aecaa879642ebb060cc10623b4a331d84ace0db41`。全部当前字节与A开始本批时持有的实际快照相等，另存批准快照。无待修发现。本次不承担最终全页分页或冷重建结论。
