电磁4.3导语/4.3.1曲率2形式两叶当前独立逐源批准。A实际逐幅读119–121全三页，到4.3.2前；全部两原号、曲率坐标式与反对称因子、换平凡化计算、π*单射及基本形式、一般G曲率评注完整逐式比对。当前全文与A初捕获原字节一致。

三条译校注独核成立：平凡R²×U(1)上的dθ+xdy在单位圆上和乐−1，故非平凡和乐不蕴含拓扑非平凡；实相位一般只有局部提升；一般G的曲率按Ad等变而非普通不变，自然是ad(P)值底2形式。原作者陈述及公式完整保留。

一个native环路图用source同clip/4x独立重算RGB尺寸exact，实际看完整环向、x0、γ和Holγ∈U1；两个TikZ图式从actual当前源码独抽编2页并2.5x逐看，全部映射/元素行/旋转membership正确。无原脚注、练习或额外题解。最终整书版式/导航/冷包仍另验。

- book/chapters/ch04-sec03-intro.tex：`e13528583cee064c2e398be580ff548f0c7f361d03f89b5dd9914c07de66422f`；7锚；快照qa/reviews/A-ch04-sec03-first-current-approved-snapshots/ch04-sec03-intro.tex。
- book/chapters/ch04-sec03-sub01.tex：`dd22013ef14cedc8557bb8583ca473109461e1673c920712a1d50a92623994b9`；40锚；快照qa/reviews/A-ch04-sec03-first-current-approved-snapshots/ch04-sec03-sub01.tex。
