# 李思《电磁与几何》中文重排译本 v1.0

依据用户提供的 159 页完整原件逐节翻译。固定来源 SHA 见 qa/source/identity.json。正文采用用户泛函分析 I 模板的视觉复原，封面重新制作。原著正文、证明、习题、图表、前后置及书目均完整保留；原著疑点保留原式，并另附独立核过的译校注。

## 编译

使用带 XeLaTeX、latexmk、CTeX、Fandol 与 Latin Modern 的 TeX Live（本版验收环境为 TeX Live 2026）。Windows 在本目录运行 `./build.ps1`，或进入 book 执行：

```
latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
```

输出 book/build/main.pdf。正式入口无条件输入全部章节，缺失文件会报错。无需私有字体或原件 PDF。包中不附编译缓存或预览入口。

## 审校与版本

全部 110 个内容单元的当前文件 SHA 与非译者独立批准见 qa/source-unit-map.json；报告及实际审阅字节快照见 qa/reviews。TeX 注释保留原件物理页及细粒度锚点。原始库存清单、作者初稿报告及历史修改记录是过程证据，其旧状态不替代当前映射。

qa/compile-input-manifest.json 记录实际全部 213 个编译输入。完整成书另经全页视觉检查、引用/书签/字体检查；实际源码 ZIP 还须在全新目录冷重建并作全页比较，其结果在最终包验收说明中提供。

## 完整成品验收

实际源码 ZIP 的冷重建已通过。逐页结果及编译输入闭包见 `qa/cold-rebuild-01.json`，成品说明见 `验收说明.md`。
