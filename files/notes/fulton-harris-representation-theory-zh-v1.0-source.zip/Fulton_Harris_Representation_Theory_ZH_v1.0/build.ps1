$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath (Join-Path $PSScriptRoot 'book')
try {
    & latexmk '-xelatex' '-interaction=nonstopmode' '-halt-on-error' '-file-line-error' '-outdir=build' 'main.tex'
    if ($LASTEXITCODE -ne 0) {
        throw "XeLaTeX compilation failed with exit code $LASTEXITCODE."
    }
    Write-Output (Join-Path $PSScriptRoot 'book/build/main.pdf')
}
finally {
    Pop-Location
}
