"""Freeze actual formal XeLaTeX inputs after a complete reviewed build."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import check_current_reviews
import check_source_coverage

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("build", type=Path, help="Actual complete main.tex build directory")
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    build = args.build.resolve()
    book = (ROOT / "book").resolve()
    reviews = check_current_reviews.inspect()
    coverage = check_source_coverage.inspect()
    assert reviews["pass"], "Current nonauthor unit review gate failed"
    assert coverage["pass"], "Whole source coverage failed"
    pdf = build / "main.pdf"
    log = (build / "main.log").read_text("utf-8", errors="replace")
    bad = [term for term in ("Overfull \\hbox", "Overfull \\vbox", "Missing character:",
                             "Undefined control sequence", "There were undefined references",
                             "Label(s) may have changed", "Fatal error", "multiply defined",
                             "Package fancyhdr Warning", "Token not allowed in a PDF string") if term in log]
    assert not bad, bad
    assert not re.search(r"LaTeX Warning:.*undefined", log)
    declared, generated, runtime, unexpected = {}, set(), set(), set()
    runtime_prefixes = ["C:/texlive/2026/"]
    for line in (build / "main.fls").read_text("utf-8", errors="replace").splitlines():
        if not line.startswith("INPUT "):
            continue
        path = Path(line[6:].strip().strip('"'))
        path = (path if path.is_absolute() else book / path).resolve()
        try:
            path.relative_to(build)
            if path.suffix not in (".aux", ".toc", ".out", ".xdv", ".lof", ".lot"):
                unexpected.add(str(path))
            else:
                generated.add(path.name)
            continue
        except ValueError:
            pass
        try:
            rel = path.relative_to(book)
            if path.suffix.lower() not in (".tex", ".sty", ".png", ".jpg", ".jpeg", ".pdf", ".eps"):
                unexpected.add(str(path))
                continue
            declared["book/" + rel.as_posix()] = digest(path)
            continue
        except ValueError:
            pass
        if any(path.as_posix().lower().startswith(prefix.lower()) for prefix in runtime_prefixes):
            runtime.add(str(path))
        else:
            unexpected.add(str(path))
    assert not unexpected, sorted(unexpected)
    formal_tex = {"book/" + p.relative_to(book).as_posix() for p in book.rglob("*.tex")}
    assert formal_tex <= set(declared), sorted(formal_tex - set(declared))
    assert "book/textbook-template.sty" in declared
    dependencies = {rec["file"]: rec["sha256"] for rec in reviews["index_dependencies"]}
    report = {
        "status": "complete-current-reviewed-compile-inputs-frozen",
        "verified_pdf_sha256": digest(pdf), "pdf": str(pdf),
        "compile_inputs": dict(sorted(declared.items())), "compile_input_count": len(declared),
        "index_generation_inputs": dependencies, "runtime_prefixes": runtime_prefixes,
        "observed_runtime_files": sorted(runtime), "generated_inputs": sorted(generated),
        "unexplained_inputs": sorted(unexpected),
        "reviewed_book_units": reviews["current_independently_approved_units"],
        "physical_source_pages": coverage["physical_pages_expected"],
        "limitations": "This manifest binds inputs only; visual and navigation acceptance, cold build and actual ZIP audit are separate.",
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k not in ("compile_inputs", "index_generation_inputs", "observed_runtime_files")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
