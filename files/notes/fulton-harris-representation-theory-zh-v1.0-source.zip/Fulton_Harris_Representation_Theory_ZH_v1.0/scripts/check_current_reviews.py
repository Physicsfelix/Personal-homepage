"""Read-only release gate for actual source bytes and nonauthor review evidence."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_SHA = "9882211de6a6e133314811269fc91970ad4a4c95ff7c48598c9c1e48e2b2233f"
INDEX_DEPENDENCIES = (
    "book/data/general-index-zh.txt",
    "book/data/symbol-index-zh.txt",
    "book/data/index-translation-notes.json",
    "scripts/generate_indices.py",
    "qa/original-general-index-B.json",
    "qa/original-symbol-index-B.json",
    "qa/printed-page-map-A.json",
)
INDEX_DEPENDENCY_OWNERS = {
    name: ("Source-B" if name in ("qa/original-general-index-B.json", "qa/original-symbol-index-B.json")
           else "Source-A" if name == "qa/printed-page-map-A.json" else "root")
    for name in INDEX_DEPENDENCIES
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def book_path(value: str) -> str:
    value = value.replace("\\", "/")
    return value[5:] if value.startswith("book/") else value


def expected_units() -> dict[str, dict]:
    plan = json.loads((ROOT / "qa/unit-plan-root.json").read_text(encoding="utf-8"))
    result = {book_path(x["file"]): dict(x) for x in plan["units"]}

    def add(file: str, owner: str, reviewer: str) -> None:
        if file in result:
            raise ValueError(f"Duplicate expected unit: {file}")
        result[file] = {"file": file, "owner": owner, "reviewer": reviewer}

    for name in ["series-half-title", "series-list", "original-title", "copyright", "preface", "using-this-book"]:
        add(f"matter/{name}.tex", "TA", "TB")
    for name, reviewer in [("part-I", "TB"), ("part-II", "TB"), ("part-III", "TC"), ("part-IV", "TA"), ("appendices-intro", "TC")]:
        add(f"matter/{name}.tex", "root", reviewer)
    add("matter/hints.tex", "root", "TB")
    for n in range(1, 27):
        if n in (12, 18):
            continue  # The source Hints has no heading or entries for these lectures.
        reviewer = "TB" if n <= 9 else "TC" if n <= 18 else "TA"
        add(f"hints/ch{n:02d}.tex", "root", reviewer)
    for letter in "ACDEF":
        add(f"hints/app{letter}.tex", "root", "TC" if letter in "AC" else "TA")
    add("matter/bibliography.tex", "root", "TB")
    for n in range(545, 551):
        add(f"bibliography/page{n}.tex", "root", "TB")
    for name in ["main.tex", "preamble.tex", "textbook-template.sty", "matter/new-cover.tex", "matter/symbol-index.tex", "matter/general-index.tex"]:
        add(name, "root", "D")
    for path in sorted((ROOT / "book/figures").rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT / "book").as_posix()
        owner = path.relative_to(ROOT / "book/figures").parts[0]
        reviewer = {"TA": "TB", "TB": "TC", "TC": "TA", "root-ch18": "TC", "root-appF": "TA", "root-appC": "TC"}.get(owner, "D")
        add(relative, owner if owner in ("TA", "TB", "TC") else "root", reviewer)
    return result


def inspect() -> dict:
    expected = expected_units()
    errors: list[dict] = []
    ledgers = {}
    for reviewer in ("TA", "TB", "TC", "D"):
        path = ROOT / f"qa/review-ledger-{reviewer}.json"
        if not path.is_file():
            ledgers[reviewer] = {}
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("reviewer") != reviewer or data.get("source_sha256") != SOURCE_SHA:
            errors.append({"file": str(path.relative_to(ROOT)), "issue": "ledger_identity_mismatch"})
        last = {}
        for record in data.get("records", []):
            last[book_path(record["file"])] = record
        ledgers[reviewer] = last
    approved = []
    present = 0
    for name, unit in expected.items():
        path = ROOT / "book" / name
        if not path.is_file():
            errors.append({"file": name, "issue": "missing_source"})
            continue
        present += 1
        reviewer = unit["reviewer"]
        rec = ledgers.get(reviewer, {}).get(name)
        if rec is None:
            errors.append({"file": name, "issue": "missing_nonauthor_review", "required_reviewer": reviewer})
            continue
        issues = []
        if rec.get("status") != "approved":
            issues.append("not_approved")
        if rec.get("reviewer") != reviewer or rec.get("translator") != unit["owner"] or reviewer == unit["owner"]:
            issues.append("authorship_or_independence_mismatch")
        current_sha = digest(path)
        if rec.get("sha256") != current_sha:
            issues.append("current_bytes_not_approved")
        for field in ["report", "approved_bytes_snapshot"]:
            value = rec.get(field)
            target = ROOT / value if value else None
            if target is None or not target.is_file():
                issues.append("missing_" + field)
            elif field == "approved_bytes_snapshot" and target.read_bytes() != path.read_bytes():
                issues.append("snapshot_bytes_differ")
        if not rec.get("source_physical_pages") and name not in ("main.tex", "preamble.tex", "textbook-template.sty", "matter/new-cover.tex"):
            issues.append("missing_actual_source_range")
        if issues:
            errors.append({"file": name, "issues": issues})
        else:
            approved.append({"file": name, "sha256": current_sha, "reviewer": reviewer})
    unplanned = [p.relative_to(ROOT / "book").as_posix() for p in (ROOT / "book").rglob("*.tex")
                 if p.relative_to(ROOT / "book").as_posix() not in expected]
    if unplanned:
        errors.append({"issue": "unexpected_TeX_inputs_require_explicit_plan", "files": unplanned})
    # Generated index TeX alone cannot bind its Chinese data, frozen source
    # transcription, page map, and the generator that a portable rebuild uses.
    dependency_path = ROOT / "qa/independent-D-input-dependencies.json"
    dependencies = {}
    if dependency_path.is_file():
        data = json.loads(dependency_path.read_text(encoding="utf-8"))
        if data.get("reviewer") != "D" or data.get("source_sha256") != SOURCE_SHA:
            errors.append({"file": str(dependency_path.relative_to(ROOT)), "issue": "dependency_review_identity_mismatch"})
        for rec in data.get("records", []):
            dependencies[rec["file"].replace("\\", "/")] = rec
    dependency_approved = []
    for name in INDEX_DEPENDENCIES:
        path = ROOT / name
        rec = dependencies.get(name)
        issues = []
        if not path.is_file():
            issues.append("missing_dependency")
        if rec is None:
            issues.append("missing_independent_dependency_review")
        else:
            if (rec.get("status") != "approved" or rec.get("reviewer") != "D"
                    or rec.get("translator") != INDEX_DEPENDENCY_OWNERS[name]):
                issues.append("dependency_not_independently_approved")
            if path.is_file() and rec.get("sha256") != digest(path):
                issues.append("dependency_current_bytes_not_approved")
            for field in ("report", "approved_bytes_snapshot"):
                target = ROOT / rec[field] if rec.get(field) else None
                if target is None or not target.is_file():
                    issues.append("missing_dependency_" + field)
                elif field == "approved_bytes_snapshot" and path.is_file() and target.read_bytes() != path.read_bytes():
                    issues.append("dependency_snapshot_bytes_differ")
        if issues:
            errors.append({"file": name, "issues": issues})
        else:
            dependency_approved.append({"file": name, "sha256": digest(path), "reviewer": "D"})
    return {"schema": "current-review-gate-v1", "source_sha256": SOURCE_SHA,
            "expected_units_including_actual_graphics": len(expected), "present_units": present,
            "current_independently_approved_units": len(approved), "approved": approved,
            "expected_index_dependencies": len(INDEX_DEPENDENCIES),
            "current_independently_approved_index_dependencies": len(dependency_approved),
            "index_dependencies": dependency_approved,
            "errors": errors, "pass": not errors}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = inspect()
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k not in ("approved", "errors")}, ensure_ascii=False))
    print(f"Unclosed findings: {len(report['errors'])}")
    raise SystemExit(0 if report["pass"] else 1)
