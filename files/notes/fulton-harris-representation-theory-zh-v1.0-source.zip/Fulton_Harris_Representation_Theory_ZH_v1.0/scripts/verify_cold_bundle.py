"""Cold-rebuild an actual textbook source ZIP and audit all compiler inputs/pages."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, subprocess, sys, zipfile
import fitz
from audit_book_pdf import embedded_font


def sha(data):
    return hashlib.sha256(data).hexdigest()


def within(path, parent):
    try:
        return path.relative_to(parent)
    except ValueError:
        return None


def interactions(doc):
    links = []
    for number, page in enumerate(doc, 1):
        for item in page.get_links():
            row = {'source': number, 'kind': item['kind'],
                   'from': [round(x, 5) for x in item['from']]}
            for key in ['page', 'uri', 'nameddest', 'name', 'file']:
                if key in item:
                    row[key] = item[key]
            if item.get('to') is not None:
                row['to'] = [round(x, 5) for x in item['to']]
            links.append(row)
    return {'links': links, 'outline': doc.get_toc(),
            'page_labels': doc.get_page_labels(), 'destinations': doc.resolve_names(),
            'metadata': {k: doc.metadata.get(k) for k in
                         ['title', 'author', 'subject', 'keywords', 'creator', 'producer']}}


def canonical_font_program(data, extension, base_name):
    """Normalize only a verified six-letter subset tag in CFF Name INDEX.

    dvipdfmx varies that metadata tag between independent runs. The complete
    remaining binary, including glyph charstrings and dictionaries, stays in
    the comparison. Other font formats are compared as raw bytes.
    """
    if extension != 'cff':
        return data
    assert len(data) >= 9 and data[0] == 1, 'Expected CFF1 font program'
    header_size = data[2]
    assert 4 <= header_size <= len(data) - 5
    count = int.from_bytes(data[header_size:header_size + 2], 'big')
    assert count == 1, 'Only a single-font CFF Name INDEX is permitted'
    offset_size = data[header_size + 2]
    assert offset_size in (1, 2, 3, 4)
    offsets_start = header_size + 3
    offsets = [int.from_bytes(data[offsets_start + i * offset_size:
                                   offsets_start + (i + 1) * offset_size], 'big') for i in range(2)]
    assert offsets[0] == 1 and offsets[1] > offsets[0]
    names_start = offsets_start + 2 * offset_size
    start, end = names_start, names_start + offsets[1] - 1
    assert end <= len(data)
    name = data[start:end]
    assert len(name) >= 8 and all(65 <= value <= 90 for value in name[:6]) and name[6:7] == b'+'
    assert name[7:].decode('ascii') == base_name
    assert data.count(name) == 1, 'Unexpected repeated internal subset full name'
    return data[:start] + b'AAAAAA' + data[start + 6:]


def font_programs(doc):
    """Compare actual embedded programs independently of PDF object numbers."""
    result, seen = [], set()
    for page in doc:
        for row in page.get_fonts(full=True):
            if row[0] in seen:
                continue
            seen.add(row[0])
            ok, evidence = embedded_font(doc, row)
            assert ok, (row[3], evidence)
            if row[2] == 'Type3':
                kind, value = doc.xref_get_key(row[0], 'CharProcs')
                assert kind == 'xref'
                charprocs = int(value.split()[0])
                program = []
                for glyph in sorted(doc.xref_get_keys(charprocs)):
                    glyph_kind, glyph_value = doc.xref_get_key(charprocs, glyph)
                    assert glyph_kind == 'xref'
                    program.append([glyph, sha(doc.xref_stream(int(glyph_value.split()[0])))])
            else:
                program = sha(canonical_font_program(doc.extract_font(row[0])[3], row[1], row[3].split('+', 1)[-1]))
            result.append({'name_without_subset_prefix': row[3].split('+', 1)[-1],
                           'kind': row[2], 'extension': row[1], 'program': program})
    return sorted(result, key=lambda value: json.dumps(value, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('archive', type=Path)
    parser.add_argument('baseline_pdf', type=Path)
    parser.add_argument('fresh_directory', type=Path)
    parser.add_argument('report', type=Path)
    args = parser.parse_args()
    archive = args.archive.resolve()
    baseline = args.baseline_pdf.resolve()
    target = args.fresh_directory.resolve()
    assert not target.exists(), 'Cold directory must be new'
    target.mkdir(parents=True)
    with zipfile.ZipFile(archive) as bundle:
        names = bundle.namelist()
        assert len(names) == len(set(names)), 'Duplicate archive paths'
        assert bundle.testzip() is None, 'ZIP CRC failure'
        prefixes = set()
        for name in names:
            parts = PurePosixPath(name).parts
            assert parts and not PurePosixPath(name).is_absolute() and '..' not in parts
            assert ':' not in name and '\\' not in name
            prefixes.add(parts[0])
            assert within((target / name).resolve(), target) is not None
        assert len(prefixes) == 1, 'Expected exactly one package root'
        assert not any(PurePosixPath(n).suffix in
                       {'.aux', '.toc', '.out', '.xdv', '.fls', '.fdb_latexmk', '.log'}
                       for n in names), 'Build cache in archive'
        bundle.extractall(target)
    package = target / next(iter(prefixes))
    book = package / 'book'
    manifest = json.loads((package / 'qa/compile-input-manifest.json').read_text('utf-8'))
    for relative, digest in manifest['compile_inputs'].items():
        assert sha((package / relative).read_bytes()) == digest, relative
    compile_log = target / 'cold-command.log'
    with compile_log.open('w', encoding='utf-8') as out:
        process = subprocess.run(
            ['latexmk', '-xelatex', '-interaction=nonstopmode', '-halt-on-error',
             '-file-line-error', '-outdir=build-cold', 'main.tex'],
            cwd=book, stdout=out, stderr=subprocess.STDOUT)
    assert process.returncode == 0, 'Cold compilation failed; inspect cold-command.log'
    log = (book / 'build-cold/main.log').read_text('utf-8', errors='replace')
    bad = [word for word in ['Overfull \\hbox', 'Overfull \\vbox', 'Missing character:',
                            'Undefined control sequence', 'There were undefined references',
                            'Label(s) may have changed', 'Fatal error', 'Package fancyhdr Warning',
                            'Token not allowed in a PDF string'] if word in log]
    assert not bad, bad
    declared, generated, runtime, unexpected = set(), set(), set(), set()
    runtime_prefixes = manifest['runtime_prefixes']
    for line in (book / 'build-cold/main.fls').read_text('utf-8', errors='replace').splitlines():
        if not line.startswith('INPUT '):
            continue
        path = Path(line[6:].strip().strip('"'))
        path = (path if path.is_absolute() else book / path).resolve()
        relative = within(path, package)
        if relative is not None:
            key = relative.as_posix()
            if key in manifest['compile_inputs']:
                declared.add(key)
            elif within(path, book / 'build-cold') is not None and path.suffix in {
                    '.aux', '.toc', '.out', '.xdv', '.lof', '.lot'}:
                generated.add(key)
            else:
                unexpected.add(str(path))
        elif any(path.as_posix().lower().startswith(p.lower()) for p in runtime_prefixes):
            runtime.add(str(path))
        else:
            unexpected.add(str(path))
    assert not unexpected, sorted(unexpected)
    missing = set(manifest['compile_inputs']) - declared - {'book/.latexmkrc'}
    assert not missing, sorted(missing)
    for relative, digest in manifest['compile_inputs'].items():
        assert sha((package / relative).read_bytes()) == digest, relative
    assert sha(baseline.read_bytes()) == manifest['verified_pdf_sha256']
    cold_pdf = book / 'build-cold/main.pdf'
    before, after = fitz.open(baseline), fitz.open(cold_pdf)
    assert len(before) == len(after), 'Page-count difference'
    pages = []
    for number, (old, new) in enumerate(zip(before, after), 1):
        geometry = (tuple(old.mediabox) == tuple(new.mediabox)
                    and tuple(old.cropbox) == tuple(new.cropbox) and old.rotation == new.rotation)
        text = old.get_text() == new.get_text()
        rawtext_geometry = old.get_text('rawdict') == new.get_text('rawdict')
        a = old.get_pixmap(matrix=fitz.Matrix(1.6, 1.6), alpha=False)
        b = new.get_pixmap(matrix=fitz.Matrix(1.6, 1.6), alpha=False)
        pixels = a.samples == b.samples and a.width == b.width and a.height == b.height
        pages.append({'physical_page': number, 'same_geometry': geometry,
                      'same_text': text, 'same_rawtext_geometry': rawtext_geometry, 'same_pixels_1_6x': pixels,
                      'baseline_pixel_sha256': sha(a.samples), 'cold_pixel_sha256': sha(b.samples)})
    assert all(p['same_geometry'] and p['same_text'] and p['same_rawtext_geometry'] and p['same_pixels_1_6x'] for p in pages)
    assert interactions(before) == interactions(after), 'Navigation/metadata differences'
    baseline_fonts, cold_fonts = font_programs(before), font_programs(after)
    assert baseline_fonts == cold_fonts, 'Embedded font programs differ beyond the verified CFF Name INDEX subset tag'
    report = {
        'status': 'passed', 'actual_archive': str(archive),
        'actual_archive_sha256': sha(archive.read_bytes()), 'archive_file_count': len(names),
        'fresh_package': str(package), 'started_without_auxiliary_files': True,
        'compile_input_count': len(manifest['compile_inputs']),
        'compile_inputs': manifest['compile_inputs'], 'observed_declared_inputs': sorted(declared),
        'generated_inputs': sorted(generated), 'runtime_inputs': sorted(runtime),
        'unexpected_inputs': sorted(unexpected), 'baseline_pdf_sha256': sha(baseline.read_bytes()),
        'cold_pdf_sha256': sha(cold_pdf.read_bytes()), 'page_count': len(before), 'pages': pages,
        'all_navigation_and_metadata_equal': True,
        'all_embedded_font_programs_equal_after_exact_NameINDEX_tag_normalization': True,
        'font_comparison_rule': 'Only the six uppercase subset-name letters in a parsed, single-font, equal-base-name, uniquely occurring CFF Name INDEX are canonicalized. Every other binary byte is retained; non-CFF fonts use raw bytes.',
        'embedded_font_count': len(baseline_fonts), 'embedded_font_programs': baseline_fonts,
        'binary_hash_note': 'Creation dates, document IDs and the verified six-letter CFF Name INDEX subset-name tags may differ. Geometry, raw text coordinates, all rendered pixels, links, destinations, outlines, page labels, descriptive metadata and every other embedded-font byte were compared independently.'}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k not in
                      ['pages', 'compile_inputs', 'runtime_inputs', 'observed_declared_inputs', 'embedded_font_programs']},
                     ensure_ascii=False))


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()
