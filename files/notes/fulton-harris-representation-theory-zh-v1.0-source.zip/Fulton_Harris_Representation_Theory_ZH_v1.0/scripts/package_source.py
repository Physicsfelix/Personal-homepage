"""Package reviewed formal inputs and their real approval evidence; no cache or source scan."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile
import check_current_reviews
import check_source_coverage

ROOT = Path(__file__).resolve().parents[1]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", type=Path)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--candidate", action="store_true", help="Cold-test candidate; not a final release claim")
    args = parser.parse_args()
    reviews = check_current_reviews.inspect()
    assert reviews["pass"] and check_source_coverage.inspect()["pass"]
    manifest = json.loads((ROOT / "qa/compile-input-manifest.json").read_text("utf-8"))
    if not args.candidate:
        readiness = json.loads((ROOT / "qa/final-readiness-root.json").read_text("utf-8"))
        assert readiness["pass"] and readiness["pdf_sha256"] == manifest["verified_pdf_sha256"]
    assert not args.stage.exists() and not args.archive.exists(), "New immutable candidate paths are required"
    package = args.stage / "Fulton_Harris_Representation_Theory_ZH_v1.0"
    package.mkdir(parents=True)
    selected = set(manifest["compile_inputs"]) | set(manifest["index_generation_inputs"])
    selected.update(["README.md", "build.ps1", "source/identity.json", "qa/compile-input-manifest.json",
                     "qa/unit-plan-root.json", "qa/AUTHORING-CONTRACT.md", "qa/NOTATION-AND-TERMS-PREPARATION.md",
                     "qa/source-structure-A.json", "qa/source-structure-A.md", "qa/OCR-stage-acceptance-root.json",
                     "qa/OCR-quality-independent-B.json", "qa/OCR-quality-independent-B.md"])
    selected.update("scripts/" + name for name in (
        "generate_indices.py", "check_current_reviews.py", "check_source_coverage.py",
        "freeze_compile_inputs.py", "package_source.py", "verify_cold_bundle.py", "audit_book_pdf.py"))
    for reviewer in ("TA", "TB", "TC", "D"):
        rel = f"qa/review-ledger-{reviewer}.json"
        selected.add(rel)
        ledger = json.loads((ROOT / rel).read_text("utf-8"))
        for rec in ledger["records"]:
            for field in ("report", "approved_bytes_snapshot"):
                if rec.get(field):
                    selected.add(rec[field].replace("\\", "/"))
    dependencies_path = "qa/independent-D-input-dependencies.json"
    selected.add(dependencies_path)
    for rec in json.loads((ROOT / dependencies_path).read_text("utf-8"))["records"]:
        selected.update(rec[field].replace("\\", "/") for field in ("report", "approved_bytes_snapshot"))
    # Include textual current final evidence explicitly named here, not a broad
    # crawl that could accidentally sweep working preview TeX into the package.
    for name in ("current-review-gate-final.json", "source-coverage-final.json", "final-readiness-root.json",
                 "final-pdf-audit-root.json", "independent-D-final-navigation.json", "final-visual-coverage.json",
                 "cold-source-current-report.json", "final-source-input-carry.json"):
        if (ROOT / "qa" / name).is_file():
            selected.add("qa/" + name)
    visual_path = ROOT / "qa/final-visual-coverage.json"
    if visual_path.is_file():
        for rec in json.loads(visual_path.read_text("utf-8")).get("records", []):
            for field in ("report", "markdown_report"):
                if rec.get(field):
                    selected.add(rec[field].replace("\\", "/"))
            # Preserve the textual evidence behind an explicitly proved visual
            # carry. Working rendered PNGs remain excluded as documented above.
            if rec.get("report"):
                visual = json.loads((ROOT / rec["report"]).read_text("utf-8"))
                for field in ("prior_visual_report", "compile_manifest"):
                    if visual.get(field):
                        selected.add(visual[field].replace("\\", "/"))
                prior = visual.get("prior_visual_report")
                if prior and (ROOT / Path(prior).with_suffix(".md")).is_file():
                    selected.add(Path(prior).with_suffix(".md").as_posix())
    for name in ("qa/reviews/D/final-navigation.md", "qa/reviews/D/final-navigation.json",
                 "qa/reviews/D/cold-font-diagnostic.json",
                 "qa/reviews/TC/cold-source-package-independent.json",
                 "qa/reviews/TC/cold-source-package-independent.md"):
        if (ROOT / name).is_file():
            selected.add(name)
    for rel in sorted(selected):
        relative = Path(rel)
        assert not relative.is_absolute() and ".." not in relative.parts and ":" not in rel
        path = ROOT / relative
        assert path.is_file() and not path.is_symlink(), rel
        target = package / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    for rel, digest in {**manifest["compile_inputs"], **manifest["index_generation_inputs"]}.items():
        assert sha((package / rel).read_bytes()) == digest, rel
    info = {"status": "cold-test-candidate-not-final" if args.candidate else "reviewed-source-package",
            "paired_pdf_sha256": manifest["verified_pdf_sha256"],
            "compile_input_count": len(manifest["compile_inputs"]),
            "original_scan_or_OCR_runtime_included": False,
            "visual_image_evidence": "Original page renders and working preview renders stay outside this portable source package."}
    (package / "qa/package-candidate-info.json").write_text(json.dumps(info, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with zipfile.ZipFile(args.archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(package.rglob("*")):
            if path.is_file():
                z.write(path, path.relative_to(args.stage).as_posix())
    with zipfile.ZipFile(args.archive) as z:
        assert z.testzip() is None
        for rel, digest in manifest["compile_inputs"].items():
            assert sha(z.read(package.name + "/" + rel)) == digest
        count = len(z.namelist())
    print(json.dumps({"archive": str(args.archive.resolve()), "sha256": sha(args.archive.read_bytes()),
                      "bytes": args.archive.stat().st_size, "members": count, "candidate": args.candidate}, ensure_ascii=False))


if __name__ == "__main__":
    main()
