"""Read-only complete-input and physical-source-page anchor audit."""
from pathlib import Path
from collections import Counter, defaultdict
import argparse
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
BOOK = ROOT / "book"


def without_comments(text):
    return "\n".join(re.split(r"(?<!\\)%", line, maxsplit=1)[0] for line in text.splitlines())


def inspect():
    missing, cycles, visits, texts = [], [], [], {}

    def walk(relative, stack=()):
        path = BOOK / relative
        if path.suffix == "":
            path = path.with_suffix(".tex")
        path = path.resolve()
        try:
            name = path.relative_to(BOOK.resolve()).as_posix()
        except ValueError:
            raise ValueError("Input escapes formal book: " + str(path))
        if name in stack:
            cycles.append(list(stack) + [name])
            return
        if not path.is_file():
            missing.append(name)
            return
        visits.append(name)
        text = without_comments(path.read_text(encoding="utf-8"))
        texts[name] = text
        for match in re.finditer(r"\\input\{([^{}]+)\}", text):
            walk(match[1], stack + (name,))

    walk("main.tex")
    starts, ends = defaultdict(list), defaultdict(list)
    for name, text in texts.items():
        if name == "preamble.tex":
            continue  # Definitions contain formal parameters, not page content.
        for kind, dest in [("Start", starts), ("End", ends)]:
            for match in re.finditer(r"\\SourcePage" + kind + r"\{(\d+)\}", text):
                dest[int(match[1])].append(name)
        for match in re.finditer(r"\\OriginalPart\{[^{}]*\}\{(\d+)\}", text):
            starts[int(match[1])].append(name)
        for match in re.finditer(r"\\TOCSourceBoundary\{(\d+)\}\{(\d+)\}", text):
            ends[int(match[1])].append(name)
            starts[int(match[2])].append(name)
    expected = set(range(1, 560))
    start_bad = {n: starts[n] for n in sorted(expected | set(starts)) if len(starts[n]) != 1 or n not in expected}
    end_bad = {n: ends[n] for n in sorted(expected | set(ends)) if len(ends[n]) != 1 or n not in expected}
    repeated_inputs = {n: c for n, c in Counter(visits).items() if c != 1}
    lectures, appendices, sections = [], [], []
    for text in texts.values():
        lectures += re.findall(r"\\OriginalLecture\{(\d+)\}", text)
        appendices += re.findall(r"\\OriginalAppendix\{([A-F])\}", text)
        sections += re.findall(r"\\OriginalSection\{([\dA-F]+\.\d+)\}", text)
    content_counts_pass = (Counter(lectures) == Counter(str(i) for i in range(1, 27))
                           and Counter(appendices) == Counter("ABCDEF")
                           and len(sections) == 99 and len(set(sections)) == 99)
    return {
        "schema": "physical-page-source-coverage-v1",
        "source_sha256": "9882211de6a6e133314811269fc91970ad4a4c95ff7c48598c9c1e48e2b2233f",
        "missing_inputs": missing, "cycles": cycles, "repeated_inputs": repeated_inputs,
        "physical_pages_expected": 559, "start_count": sum(map(len, starts.values())),
        "end_count": sum(map(len, ends.values())), "start_errors": start_bad, "end_errors": end_bad,
        "lecture_numbers": lectures, "appendices": appendices, "numbered_section_count": len(sections),
        "numbered_sections": sections, "content_counts_pass": content_counts_pass,
        "inputs": [{"file": "book/" + n, "sha256": hashlib.sha256((BOOK / n).read_bytes()).hexdigest()}
                   for n in visits],
        "anchors": [{"physical_page": n, "start_files": starts[n], "end_files": ends[n]}
                    for n in sorted(expected)],
        "scope_limit": "Mechanical completeness only; nonauthor semantic review and actual compiled anchor positions remain separate gates.",
        "pass": not (missing or cycles or repeated_inputs or start_bad or end_bad) and content_counts_pass,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = inspect()
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k not in ("inputs", "anchors", "numbered_sections")}, ensure_ascii=False))
    raise SystemExit(0 if report["pass"] else 1)
