"""Inspect actual PDF structure/fonts/links; this is not a semantic review."""
from pathlib import Path
import argparse, hashlib, json, re
import fitz


def sha(data):
    return hashlib.sha256(data).hexdigest()


def embedded_font(doc, row):
    xref, extension, kind = row[:3]
    if kind != 'Type3':
        return bool(doc.extract_font(xref)[3]), 'embedded font program'
    # Type 3 fonts embed their glyph programs in CharProcs, not FontFile streams.
    key_kind, value = doc.xref_get_key(xref, 'CharProcs')
    if key_kind != 'xref':
        return False, 'Type3 without indirect CharProcs; inspect manually'
    charprocs = int(value.split()[0])
    programs = []
    for glyph in doc.xref_get_keys(charprocs):
        glyph_kind, glyph_value = doc.xref_get_key(charprocs, glyph)
        if glyph_kind != 'xref':
            return False, 'Type3 CharProc is not an indirect stream'
        glyph_xref = int(glyph_value.split()[0])
        programs.append(doc.xref_is_stream(glyph_xref) and bool(doc.xref_stream(glyph_xref)))
    return bool(programs) and all(programs), 'embedded Type3 CharProcs glyph programs'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('pdf', type=Path)
    parser.add_argument('report', type=Path)
    parser.add_argument('--log', type=Path)
    args = parser.parse_args()
    doc = fitz.open(args.pdf)
    names = doc.resolve_names()
    font_rows, outside, broken, link_count = {}, [], [], 0
    boxes = []
    for number, page in enumerate(doc, 1):
        boxes.append({'page': number, 'rect': list(page.rect), 'rotation': page.rotation})
        for row in page.get_fonts(full=True):
            if row[0] in font_rows:
                continue
            ok, evidence = embedded_font(doc, row)
            font_rows[row[0]] = {'xref': row[0], 'name': row[3], 'kind': row[2],
                                 'embedded': ok, 'evidence': evidence}
        for block in page.get_text('blocks'):
            if block[0] < -1 or block[1] < -1 or block[2] > page.rect.width + 1 or block[3] > page.rect.height + 1:
                outside.append({'page': number, 'bbox': list(block[:4]), 'text': block[4]})
        for link in page.get_links():
            link_count += 1
            if link['kind'] == fitz.LINK_GOTO:
                valid = 0 <= link.get('page', -1) < len(doc)
            elif link['kind'] == fitz.LINK_NAMED:
                name = link.get('nameddest') or link.get('name')
                destination = names.get(name)
                valid = isinstance(destination, dict) and 0 <= destination.get('page', -1) < len(doc)
            elif link['kind'] == fitz.LINK_URI:
                valid = bool(link.get('uri'))
            else:
                valid = False
            if not valid:
                broken.append({'source_page': number, 'link': repr(link)})
    log_issues = []
    if args.log:
        log = args.log.read_text('utf-8', errors='replace')
        patterns = ['Overfull', 'Missing character:', 'There were undefined references',
                    'There were multiply-defined labels', 'destination with the same identifier',
                    'Package fancyhdr Warning', 'Token not allowed in a PDF string']
        log_issues = [p for p in patterns if p in log]
    outline = doc.get_toc()
    bad_outline = [row for row in outline if not 1 <= row[2] <= len(doc)]
    report = {'pdf': str(args.pdf.resolve()), 'sha256': sha(args.pdf.read_bytes()),
              'bytes': args.pdf.stat().st_size, 'pages': len(doc), 'page_geometry': boxes,
              'font_count_unique_xrefs': len(font_rows), 'fonts': list(font_rows.values()),
              'unembedded_fonts': [r for r in font_rows.values() if not r['embedded']],
              'outside_page_text_blocks': outside, 'link_count': link_count,
              'named_destination_count': len(names), 'broken_internal_or_empty_external_links': broken,
              'outline_count': len(outline), 'outline': outline, 'bad_outline_pages': bad_outline,
              'log_issues': log_issues,
              'limits': 'Structural audit only; source semantic completeness, actual all-page visual reading, TOC title landing and external URL liveness require separate evidence.'}
    report['structural_passed'] = not any([report['unembedded_fonts'], outside, broken, bad_outline, log_issues])
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: report[k] for k in ['pages', 'bytes', 'font_count_unique_xrefs', 'outline_count', 'link_count', 'structural_passed']}))


if __name__ == '__main__':
    main()
