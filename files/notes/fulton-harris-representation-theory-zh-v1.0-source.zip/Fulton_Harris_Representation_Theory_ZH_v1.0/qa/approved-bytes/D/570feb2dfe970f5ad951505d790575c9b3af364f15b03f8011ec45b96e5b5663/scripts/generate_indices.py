"""Deterministically render the full original indices; XeLaTeX binds current pages.

Default is read-only. --write replaces only the two generated index TeX files.
The original index records, their hierarchy and original page tokens remain inputs.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_SHA = "9882211de6a6e133314811269fc91970ad4a4c95ff7c48598c9c1e48e2b2233f"


def read_json(relative):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def read_terms(relative):
    result = {}
    for line in (ROOT / relative).read_text(encoding="utf-8").splitlines():
        key, value = line.split("|", 1)
        if key in result or not value:
            raise ValueError(f"Duplicate/empty translation: {key}")
        result[key] = value
    return result


def escape(text):
    replacements = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$",
                    "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}",
                    "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
    return "".join(replacements.get(c, c) for c in text)


def breakable_math(text):
    # Permit ordinary line breaking at separators without changing mathematics.
    result = []; depth = 0
    for i, character in enumerate(text):
        escaped = i > 0 and text[i - 1] == "\\"
        if character in "({[" and not escaped:
            depth += 1
        elif character in ")}]" and not escaped:
            depth -= 1
        result.append(character)
        if character in ",=" and depth == 0:
            result.append(r"\allowbreak ")
    return "".join(result)


def english_general(entry):
    ident, math = entry["id"], entry.get("math_latex")
    if ident == "GI-171":
        return r"$\lambda$-ring"
    if ident == "GI-189":
        return r"module ($G$-module, $\mathfrak g$-module)"
    if math:
        prefix = "of " if entry["english_display"].startswith("of ") else ""
        return prefix + "$" + breakable_math(math) + "$"
    return escape(entry["english_display"])


def make_outputs():
    source_map = read_json("qa/printed-page-map-A.json")
    folios = {int(x["logical_folio"]): x["physical"] for x in source_map["rows"]
              if x["numbering"] == "arabic"}
    absent = {int(x["logical_folio"]) for x in source_map["not_present_in_pdf"]
              if str(x["logical_folio"]).isdigit()}
    notes = read_json("book/data/index-translation-notes.json")
    if notes["source_sha256"] != SOURCE_SHA:
        raise ValueError("Translation notes refer to a different source PDF")
    references = []
    source_issues = []

    def one_reference(entry_id, token):
        record = {"entry": entry_id, "original_token": token}
        if token == "4⟦?⟧8" and entry_id == "GI-025":
            record.update(kind="physically_damaged_original_digit", source_physicals=[])
            references.append(record); source_issues.append(record)
            return "（原页字形不清）"
        match = re.fullmatch(r"(\d+)(?:\s*[–−-]\s*(\d+))?", token)
        if not match:
            raise ValueError(f"Unsupported original page token {entry_id}: {token!r}")
        first = int(match[1]); last = int(match[2]) if match[2] else first
        if match[2] and len(match[2]) < len(match[1]):
            power = 10 ** len(match[2])
            last += first // power * power
            if last < first:
                last += power
        if last < first:
            physicals = [folios[first], folios[last]]
            record.update(kind="original_reversed_range", source_physicals=physicals,
                          original_endpoint_folios=[first, last])
            references.append(record); source_issues.append(record)
            return (rf"\IndexTranslatedSpan{{{physicals[0]}}}{{{physicals[0]}}}、"
                    rf"\IndexTranslatedSpan{{{physicals[1]}}}{{{physicals[1]}}}（原列两端）")
        missing = [i for i in range(first, last + 1) if i not in folios]
        if set(missing) - absent:
            raise ValueError(f"Unexplained missing source folios: {entry_id}, {missing}")
        physicals = [folios[i] for i in range(first, last + 1) if i in folios]
        record.update(kind="source_page_or_range", expanded_folios=[first, last],
                      source_physicals=physicals, absent_original_folios=missing)
        references.append(record)
        result = (rf"\IndexTranslatedSpan{{{physicals[0]}}}{{{physicals[-1]}}}"
                  if physicals else "（无对应原页）")
        if missing:
            source_issues.append(record)
            result += "（原" + "、".join(map(str, missing)) + "页缺于所给PDF）"
        return result

    outputs = {}; counts = {}
    for kind, title, first_source in [("symbol", "符号索引", 551), ("general", "总索引", 555)]:
        source_path = f"qa/original-{kind}-index-B.json"
        data = read_json(source_path)
        if data["source_sha256"] != SOURCE_SHA:
            raise ValueError("Wrong original index source identity")
        entries = data["entries"]
        terms = read_terms(f"book/data/{kind}-index-zh.txt")
        required = {x["id"] for x in entries if kind == "general" or x["english_description"]}
        if set(terms) != required:
            raise ValueError(f"Translation coverage mismatch: {kind}, missing={required-set(terms)}, extra={set(terms)-required}")
        lines = ["% Generated from frozen original index records and complete Chinese translations.",
                 "% Current translated pages are read from actual zref shipout labels.",
                 rf"\chapter*{{{title}}}\addcontentsline{{toc}}{{chapter}}{{{title}}}",
                 rf"\markboth{{{title}}}{{}}\SourcePageStart{{{first_source}}}"]
        if kind == "symbol":
            lines += [r"本索引保留原书的符号与原序。原页指英文原书的印刷页码；译页指本译本的对应页或页段。",
                      r"\SourceError{原索引把$\operatorname{Aut}(V)$写为$\mathrm{SL}_n\mathbb R$，下文照录；通常向量空间的自同构群应为$\mathrm{GL}(V)$。}"]
        else:
            lines += [r"本索引按原书英文条目的顺序排列，并列中文译名。原页与译页分别保留原书参照及本译本的对应位置。原书倒置的页段照录并分别定位两端；原件字形不清或所给PDF缺少的原页均明确标注。"]
        lines += [r"\setlength{\columnsep}{7mm}\setlength{\emergencystretch}{1em}",
                  r"\begin{multicols}{2}\small\raggedright\raggedcolumns"]
        for index, entry in enumerate(entries):
            ident = entry["id"]; physical = entry["original_physical_page"]
            prefix = ""
            if index and physical != entries[index - 1]["original_physical_page"]:
                prefix = rf"\SourcePageStart{{{physical}}}"
            end = ""
            if index == len(entries) - 1 or physical != entries[index + 1]["original_physical_page"]:
                end = rf"\SourcePageEnd{{{physical}}}"
            if kind == "symbol":
                math = notes.get("math_overrides", {}).get(ident, {}).get("math_latex", entry["math_latex"])
                if not math:
                    raise ValueError(f"Unresolved mathematical symbol: {ident}")
                term = prefix + "$" + breakable_math(math) + "$"
                if ident in terms:
                    term += "（" + terms[ident] + "）"
                english = ""; level = 0
            else:
                term = prefix + terms[ident]
                english = english_general(entry); level = entry["indent_level"]
            if not entry["page_reference_tokens"]:
                lines.append(rf"\IndexHeading{{{level}}}{{{ident}}}{{{term}{end}}}{{{english}}}")
            else:
                original = ", ".join(escape(t.replace("⟦?⟧", "?")) for t in entry["page_reference_tokens"])
                translated = "、".join(one_reference(ident, t) for t in entry["page_reference_tokens"]) + end
                lines.append(rf"\IndexTerm{{{level}}}{{{ident}}}{{{term}}}{{{english}}}{{{original}}}{{{translated}}}")
        lines += [r"\end{multicols}", ""]
        outputs[f"book/matter/{kind}-index.tex"] = "\n".join(lines).encode("utf-8")
        counts[kind] = {"records": len(entries), "target_entries": sum(bool(e["page_reference_tokens"]) for e in entries),
                        "explicit_Chinese_descriptions_or_terms": len(terms)}
    return outputs, {"schema": "complete-index-generation-v1", "source_sha256": SOURCE_SHA,
                     "counts": counts, "original_reference_tokens": len(references),
                     "references": references, "annotated_original_source_issues": source_issues,
                     "page_binding": "Native XeLaTeX zref shipout page/abspage labels, not a guessed pagination offset"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    outputs, report = make_outputs()
    report["changed_from_current"] = {name: not (ROOT / name).is_file() or (ROOT / name).read_bytes() != content
                                     for name, content in outputs.items()}
    if args.write:
        for name, content in outputs.items():
            (ROOT / name).write_bytes(content)
    report["outputs"] = {name: {"sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content)} for name, content in outputs.items()}
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k not in ("references", "annotated_original_source_issues")}, ensure_ascii=False))
    raise SystemExit(0 if args.write or not any(report["changed_from_current"].values()) else 1)
