# 全书翻译、分工与独立审校接口

## 已完成的第一阶段

必须先读PROJECT.md、source/identity.json、qa/OCR-stage-acceptance-root.json、qa/printed-page-map-A.json、qa/source-structure-A.json及qa/NOTATION-AND-TERMS-PREPARATION.md。

OCR559页的机器执行和原图映射已经独立核验；**不等于数学转写或逐字英文正确**。正文作者和审者均必须实际看自己源范围的全部原页，不能照抄ocr/text公式，也不能拿全页小图概览冒充逐段/逐式审读。所有图、矩阵、表、脚注和习题子问都核原图。

## 角色与独立性

source阶段的A/B/C与正式译稿的TA/TB/TC是不同职责标签，不得混签。

|正式作者|归属|非作者独审|
|---|---|---|
|TA|原前置物1–10、第1–9讲物18–146；原目录文字标题对照|TB|
|TB|第10–18讲物147–293、附录A–C物462–495|TC|
|TC|第19–26讲物294–460、附录D–F物496–524|TA|
|root|新封面、4部分原导语、附录分隔、原Hints、Bibliography与双索引、主入口与集成|按下列单元交叉审或最终新独审D|

root部分导语：PartI物16–17、PartII物104–106由TB审；PartIII物208由TC审；PartIV物328–329由TA审。root原Hints物525–544分原Lecture/Appendix小组：对应1–9讲的由TB审、10–18讲/附录A–C由TC审、19–26讲/附录D–F由TA审。root书目物545–550由TB审；双索引由未撰写中文索引的新独审者D终审（英文源转录另有来源审查，不代替中文/导航）。

每位作者写完一节或章就向指定审者发内部collaboration消息（不是send_message_to_thread），告知实际源范围与文件。每位作者在推进自己下一章前，优先处理已经到达的同行审阅单元，避免全部写完才排队审校。审者不得改被审作者文件；给问题让作者修，再读实际新文件和差分复查。

## 文件所有权

- TA：book/chapters/ch01*.tex .. ch09*.tex；book/matter/series-half-title.tex、series-list.tex、original-title.tex、copyright.tex、preface.tex、using-this-book.tex；其qa/author-TA/、qa/previews-TA/；审TB归属的独审者是TC，TA自身审TC归属时仅写qa/reviews/TA/、qa/review-ledger-TA.json、qa/approved-bytes/TA/。
- TB：book/chapters/ch10*.tex .. ch18*.tex；book/appendices/appA*.tex .. appC*.tex；其qa/author-TB/、qa/previews-TB/；审TA/root指定部分时仅写qa/reviews/TB/、qa/review-ledger-TB.json、qa/approved-bytes/TB/。
- TC：book/chapters/ch19*.tex .. ch26*.tex；book/appendices/appD*.tex .. appF*.tex；其qa/author-TC/、qa/previews-TC/；审TB/root指定部分时仅写qa/reviews/TC/、qa/review-ledger-TC.json、qa/approved-bytes/TC/。
- 每位作者可写book/figures/TA/或TB/TC/自己的图形/TeX资产，不能覆盖其他作者或source参考图。引用原裁图前须实际看完整原页和裁片并检查所有标签，不能据源候选总表直接称图形通过。
- root拥有book/main.tex、preamble.tex、textbook-template.sty、其余matter、hints及索引生成器；不要擅改共同接口。需要新全局宏向root提出，或用明确命名的局部宏，不得重复定义通用短宏污染其他章节。

## 正式源文件结构

每讲：chNN.tex只放原讲标题和无条件input链；chNN-intro.tex保存全部无节号章导语；chNN-secMM.tex保存对应原编号小节全部内容。第12讲没有原编号节，使用ch12-body.tex，不补造12.1。原文若无导语则记录“实际无导语”而非编造。附录同理appA.tex/appA-intro.tex/appA-sec01.tex等。跨页段及证明以实际下节第一句核边界，不能按整页机械分割漏/重。

## 共享排版API

正式编译工作目录为book；\input{preamble}。公共样式是用户泛函I样张视觉复原，A4/24mm/11ptFandol+LatinModern，已用真实技术样编检查中文、公式、Young表、交换图、脚注及源锚点。

- \OriginalLecture{1}{中文讲名}；数学标题使用\texorpdfstring{TeX标题}{清楚的纯文本书签}。
- \OriginalSection{1.1}{中文节名}；会写原号及目录行。不要再用section自动编号或重复addcontentsline。
- \OriginalAppendix{A}{中文附录名}，正式主入口会先设置appendix及字母章号；独立附录预览需自行设置对应计数，但不得把预览逻辑写进正式单元。
- 原陈述：originaldefinition/originalnotation/originalconvention/originalproposition/originallemma/originalcorollary/originaltheorem/originalclaim；参数为原号，可选原名。例/注/习题：originalexample/originalremark/originalexercise/originalproblem/originalquestion/originalconjecture/originalobservation。原证明：originalproof。
- 原公式用原\tag{2.11}和单个\label{eq:2.11}。声明/习题等的label可用thm:/prop:/lem:/cor:/claim:/ex:/example:等；原节label由接口创建sec:1.1，原讲ch:1。不得生成新号代替原号，未编号的内容也完整保留。
- \OrigRef{ex}{1.2}等显示原号并链接；源书错引用原样保留并独立审查译校注，不偷偷改可见数学。
- \SourceError{...}只用于原书问题/实际来源字形不明等有学习意义的译校注；不要把OCR引擎故障、后台实现或工作进度写入教材正文。
- \SourceFootnote{1}{完整原脚注}保留原呼号。所有脚注核锚点、正文语句、注体及跨页续文。
- 共享宏和operators见book/preamble.tex。Young可用ytableau；图用TikZ/tikz-cd；必要时保留清晰原数学裁片，并完整翻译自然语言标签/图例，不允许藏进整页英文正文冒作图。
- 图表/图式有原号则显式保留，无原号不添加。不要让figure/table默认编号覆盖原式号；使用图片时检查是否已含源号码，避免重复显示。

## 每个原物理页的可追溯跨度

\SourcePageStart{18}与\SourcePageEnd{18}的18均指**原PDF物理18**，不是印刷18。每个归属物理页只注册一对，跨相邻节时不要重复。真正译页由zref在shipout时记录，hyperlink目标为src:18:start/end；不用原印刷页偏移猜译页。

标记应紧贴实际原页对应的第一/最后内容；在分页章标题/陈述框时放入实际对象内，不能留在前一页。接口在数学环境内也使用zref独立标签，不占用amsmath公式label。原页跨多页译文时必须保存起止跨度。一个原页与两段长公式/图跨越时，译者记录实际原段边界，审者核其对应。

前置物1–10由TA登记；原目录物11–15由root在正式目录行分组中登记，TA不重复插这些标签。Part导语原页归root；作者勿把Part导语再译进第一个Lecture。附录分隔物461归root；Hints/书目/双索引原页归root。

## 译者清单与独审证据

每单元作者先保存原页范围、起止段锚、陈述/公式/习题全子问/提示/脚注/图表及无编号内容盘点；机器编号统计只是辅助。作者自己保存的文件SHA不是审校批准。

每位审者单独维护qa/review-ledger-TA/TB/TC.json，顶层source_sha256和reviewer，records内每项至少：unit、translator（TA/TB/TC/root）、reviewer、source_physical_pages、file、sha256、status、report、approved_bytes_snapshot。报告明确实际看过哪些源图、逐段/逐式结果、问题与修订闭环。approved时从真实已审文件复制原字节至qa/approved-bytes/<审者>/<SHA>/<book相对路径>，不得从译者陈述伪造。

旧批准与旧快照保留；源文件变后独立差分审查受影响语义/布局再签新SHA。每章wrapper、intro和各节均要有对应记录；图资产与正文一起核，不把其他章节作者自己写的字句算独立审查。root不替任何审者写批准。

## 预览与交付门槛

作者的单章预览放qa/previews-TA/TB/TC，不进正式input链/源码包。可从book目录用latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=../qa/previews-TA/build ../qa/previews-TA/preview.tex验证自己的当前内容；不要编条件式缺章main再称全书。

PDF authoring marker已成功一次，所有子Agent**不得重复**。正式main将无条件包含全范围，缺文件直接失败。全范围译稿及逐节当前独审后，另做当前全PDF实际看图、目录书签/脚注/双索引目标、字体嵌入、冷编与实际最终ZIP审计；未通过前只称候选或阶段稿。


## 作者分工补充：root接手尚未开始的第18讲

为了平衡剩余量，root接手第18讲原279–293，独占book/chapters/ch18*.tex与book/figures/root-ch18/。TB负责第10–17讲及AppA–C；TC仍独审第18讲，记录translator=root。原有批准与其余分工不变。qa/unit-plan-root.json对应owner已更新。


## 作者分工补充：root接手尚未开始的附录F

root接手附录F原513–524（三节），独占book/appendices/appF*.tex及book/figures/root-appF/。TC保留第19–26讲与AppD–E；TA仍为附录F的非作者审者，记录translator=root。此前已批准的root Hints AppF与正文附录F是不同单元，不混签。


## 作者分工补充：root接手尚未开始的附录C

root接手附录C原487–495（三节），独占book/appendices/appC*.tex与book/figures/root-appC/。TB保留第10–17讲与AppA–B；TC仍为附录C非作者审者，translator=root。此前Hints AppC批准是另一个独立单元，不能代替正文附录C审校。


Root takeover: Appendix B physical480-486 now belongs to root (TB explicitly confirmed no writing). Reviewer remains TC. Main chain unchanged.

Root takeover: Appendix E physical508-512 now belongs to root (TC explicitly confirmed no writing). Reviewer remains TA. Main chain unchanged.

Root takeover: Appendix D physical496-507 now belongs to root (TC explicitly confirmed no writing). Reviewer remains TA. Main chain unchanged.

Root takeover: Lecture26 section26.3 physical455-460 belongs to root, with TC explicit no-draft/no-write handoff. Reviewer TA. TC owns26 wrapper/intro/26.1/26.2.
