# 来源结构与页码盘点 A

本报告仅盘点来源；不表示 OCR 或翻译审校完成。原件共559个物理页面。前置15页，正文及后置544页，对应阿拉伯逻辑页1–551，其中7页缺失。完整逐页记录见 `printed-page-map-A.json`。

## 证据与边界

实际查看目录物11–15、前置1–18、各缺页边界及正文异常页。页码映射中 `printed_folio=null` 表示本次没有取得顶端页码证据，`logical_folio` 是通过目录与相邻序列确立的对应关系；未独立查看的开篇页不能据文字层缺失断言其一定没有印刷页码。并未肉眼检查全书每张页面；499页的顶端文字层数字与分段映射一致，另4页经原图确认；41个正文开篇页没有顶端文字层页码候选，以目录、结构和邻接关系推定；其中是否省略印刷数字，只对实际查看的开篇页作肉眼确认。

版权页物4显示©2004与printing9，编目含1991；不据此声称2004新版。

缺失逻辑页：xvi、92、194、196、316、450、452、542。相邻原页已实际查看；可确认它们不在PDF中，不能从缺页推论其内容必定为空白。

## 分段页码映射

|物理页|书内逻辑页|
|---|---|
|16–106|1–91|
|107–207|93–193|
|208–208|195–195|
|209–327|197–315|
|328–460|317–449|
|461–461|451–451|
|462–550|453–541|
|551–559|543–551|

前置物1–4没有可见页码，不强行赋i–iv；物5–8为序言v–viii，物9–10为Using This Book ix–x，物11–15为目录xi–xv。开篇v、ix、xi页码省略，由目录及相邻罗马页码推定。

## 全结构

以下起始页由已实际查看的目录确认。结束界取下一结构起点前；并不表示每讲开篇原图均已独立查看。规范化数学符号仅为可检索元数据。

|类别|编号|标题|逻辑页|物理页|
|---|---|---|---|---|
|part|I|Finite Groups|1–88|16–103|
|part|II|Lie Groups and Lie Algebras|89–193|104–207|
|part|III|The Classical Lie Algebras and Their Representations|195–315|208–327|
|part|IV|Lie Theory|317–449|328–460|
|lecture|1|Representations of Finite Groups|3–11|18–26|
|lecture|2|Characters|12–25|27–40|
|lecture|3|Examples; Induced Representations; Group Algebras; Real Representations|26–43|41–58|
|lecture|4|Representations of S_d: Young Diagrams and Frobenius's Character Formula|44–62|59–77|
|lecture|5|Representations of A_d and GL_2(F_q)|63–74|78–89|
|lecture|6|Weyl's Construction|75–88|90–103|
|lecture|7|Lie Groups|93–103|107–117|
|lecture|8|Lie Algebras and Lie Groups|104–120|118–134|
|lecture|9|Initial Classification of Lie Algebras|121–132|135–146|
|lecture|10|Lie Algebras in Dimensions One, Two, and Three|133–145|147–159|
|lecture|11|Representations of sl_2 C|146–160|160–174|
|lecture|12|Representations of sl_3 C, Part I|161–174|175–188|
|lecture|13|Representations of sl_3 C, Part II: Mainly Lots of Examples|175–193|189–207|
|lecture|14|The General Set-up: Analyzing the Structure and Representations of an Arbitrary Semisimple Lie Algebra|197–210|209–222|
|lecture|15|sl_4 C and sl_n C|211–237|223–249|
|lecture|16|Symplectic Lie Algebras|238–252|250–264|
|lecture|17|sp_6 C and sp_2n C|253–266|265–278|
|lecture|18|Orthogonal Lie Algebras|267–281|279–293|
|lecture|19|so_6 C, so_7 C, and so_m C|282–298|294–310|
|lecture|20|Spin Representations of so_m C|299–315|311–327|
|lecture|21|The Classification of Complex Simple Lie Algebras|319–338|330–349|
|lecture|22|g_2 and Other Exceptional Lie Algebras|339–365|350–376|
|lecture|23|Complex Lie Groups; Characters|366–398|377–409|
|lecture|24|Weyl Character Formula|399–414|410–425|
|lecture|25|More Character Formulas|415–429|426–440|
|lecture|26|Real Lie Algebras and Lie Groups|430–449|441–460|
|appendix|A|On Symmetric Functions|453–470|462–479|
|appendix|B|On Multilinear Algebra|471–477|480–486|
|appendix|C|On Semisimplicity|478–486|487–495|
|appendix|D|Cartan Subalgebras|487–498|496–507|
|appendix|E|Ado's and Levi's Theorems|499–503|508–512|
|appendix|F|Invariant Theory for the Classical Groups|504–515|513–524|
|back_matter||Hints, Answers, and References|516–535|525–544|
|back_matter||Bibliography|536–541|545–550|
|back_matter||Index of Symbols|543–546|551–554|
|back_matter||Index|547–551|555–559|

Appendices分隔页为逻辑451/物461；附录A从逻辑453/物462开始。

## 全部目录节条目

各节下表保留未校文字层标题，含已有OCR符号错误；页码已对目录图复核。数学符号、准确英文标题仍应从原图转写。本表不是合格翻译源文。

|节|未校文字层标题|逻辑起始|物理起始|目录物理页|
|---|---|---|---|---|
|1.1|Definitions|3|18|11|
|1.2|Complete Reducibility; Schur's Lemma|5|20|11|
|1.3|Examples: Abelian Groups; 6 3|8|23|11|
|2.1|Characters|12|27|11|
|2.2|The First Projection Formula and Its Consequences|15|30|11|
|2.3|Examples: 6 4 and 214|18|33|11|
|2.4|More Projection Formulas; More Consequences|21|36|11|
|3.1|Examples: 6 s and 21s|26|41|11|
|3.2|Exterior Powers of the Standard Representation of 6 d|31|46|11|
|3.3|Induced Representations|32|47|11|
|3.4|The Group Algebra|36|51|11|
|3.5|Real Representations and Representations over Subfields of C|39|54|11|
|4.1|Statements of the Results|44|59|12|
|4.2|Irreducible Representations of 6 d|52|67|12|
|4.3|Proof of Frobenius's Fonnula|54|69|12|
|5.1|Representations of ~d|63|78|12|
|5.2|Representations of GL2{lFq) and SL2{lFq)|67|82|12|
|6.1|Schur Functors and Their Characters|75|90|12|
|6.2|The Proofs|84|99|12|
|7.1|Lie Groups: Definitions|93|107|12|
|7.2|Examples of Lie Groups|95|109|12|
|7.3|Two Constructions|101|115|12|
|8.1|Lie Algebras: Motivation and Definition|104|118|12|
|8.2|Examples of Lie Algebras|111|125|12|
|8.3|The Exponential Map|114|128|12|
|9.1|Rough Classification of Lie Algebras|121|135|12|
|9.2|Engel's Theorem and Lie's Theorem|125|139|12|
|9.3|Semisimple Lie Algebras|128|142|12|
|9.4|Simple Lie Algebras|131|145|12|
|10.1|Dimensions One and Two|133|147|12|
|10.2|Dimension Three, Rank 1|136|150|12|
|10.3|Dimension Three, Rank 2|139|153|12|
|10.4|Dimension Three, Rank 3|141|155|12|
|11.1|The Irreducible Representations|146|160|12|
|11.2|A Little Plethysm|151|165|12|
|11.3|A Little Geometric Plethysm|153|167|12|
|13.1|Examples|175|189|13|
|13.2|Description of the Irreducible Representations|182|196|13|
|13.3|A Little More Plethysm|185|199|13|
|13.4|A Little More Geometric Plethysm|189|203|13|
|14.1|Analyzing Simple Lie Algebras in General|197|209|13|
|14.2|About the Killing Form|206|218|13|
|15.1|Analyzing slnC|211|223|13|
|15.2|Representations of sl4C and slnC|217|229|13|
|15.3|Weyt's Construction and Tensor Products|222|234|13|
|15.4|Some More Geometry|227|239|13|
|15.5|Representations of GLnC|231|243|13|
|16.1|The Structure of SP2nC and SP2nC|238|250|13|
|16.2|Representations of SP4 C|244|256|13|
|17.1|Representations of SP6C|253|265|13|
|17.2|Representations of SP2nC in General|259|271|13|
|17.3|Weyl's Construction for Symplectic Groups|262|274|13|
|18.1|SOmC and SO.,C|267|279|13|
|18.2|Representations of 503C, 504C, and 50s C|273|285|13|
|19.1|Representations ofs06C|282|294|13|
|19.2|Representations ofthe Even Orthogonal Algebras|286|298|13|
|19.3|Representations of S07C|292|304|13|
|19.4|Representations of the Odd Orthogonal Algebras|294|306|13|
|19.5|Weyt's Construction for Orthogonal Groups|296|308|13|
|20.1|Clifford Algebras and Spin Representations of so .. C|299|311|14|
|20.2|The Spin Groups Spin",C and Spin .. 1R|307|319|14|
|20.3|SpinsC and Triality|312|324|14|
|21.1|Dynkin Diagrams Associated to Semisimple Lie Algebras|319|330|14|
|21.2|Classifying Dynkin Diagrams|325|336|14|
|21.3|Recovering a Lie Algebra from Its Dynkin Diagram|330|341|14|
|22.1|Construction of g2 from Its Dynkin Diagram|339|350|14|
|22.2|Verifying That g2 is a Lie Algebra|346|357|14|
|22.3|Representations of g2|350|361|14|
|22.4|Algebraic Constructions of the Exceptional Lie Algebras|359|370|14|
|23.1|Representations of Complex Simple Groups|366|377|14|
|23.2|Representation Rings and Characters|375|386|14|
|23.3|Homogeneous Spaces|382|393|14|
|23.4|Bruhat Decompositions|395|406|14|
|24.1|The Weyl Character Formula|399|410|14|
|24.2|Applications to Classical Lie Algebras and Groups|403|414|14|
|25.1|Freudenthal's Multiplicity Formula|415|426|14|
|25.2|Proof of (WCF); the Kostant Multiplicity Formula|419|430|14|
|25.3|Tensor Products and Restrictions to Subgroups|424|435|14|
|26.1|Classification of Real Simple Lie Algebras and Groups|430|441|14|
|26.2|Second Proof of Weyl's Character Formula|440|451|14|
|26.3|Real, Complex, and Quatemionic Representations|444|455|14|
|A.1|Basic Symmetric Polynomials and Relations among Them|453|462|14|
|A.2|Proofs of the Determinantal Identities|462|471|14|
|A.3|Other Determinantal Identities|465|474|14|
|B.1|Tensor Products|471|480|15|
|B.2|Exterior and Symmetric Powers|472|481|15|
|B.3|Duals and Contractions|475|484|15|
|C.1|The Killing Form and Cartan's Criterion|478|487|15|
|C.2|Complete Reducibility and the Jordan Decomposition|481|490|15|
|C.3|On Derivations|483|492|15|
|D.1|The Existence of Cartan Subalgebras|487|496|15|
|D.2|On the Structure of Semisimple Lie Algebras|489|498|15|
|D.3|The Conjugacy of Cartan Subalgebras|491|500|15|
|D.4|On the Weyl Group|493|502|15|
|E.1|Levi's Theorem|499|508|15|
|E.2|Ado's Theorem|500|509|15|
|F.1|The Polynomial Invariants|504|513|15|
|F.2|Applications to Symplectic and Orthogonal Groups|511|520|15|
|F.3|Proof of Capelli's Identity|514|523|15|

合计26讲、6附录、99个目录列出的小节。Lecture12在目录中没有列出小节，不能据此补造。

原图异常复核：物300的页码为288；物405为394（原候选只提取出3）；物528为519；物529为520。末物559为书内551。

未运行OCR，未翻译，未修改任何书源。
