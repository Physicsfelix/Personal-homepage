# Source-anchor binding delta independent review

Reviewer TA. Source PDF SHA256: 9882211de6a6e133314811269fc91970ad4a4c95ff7c48598c9c1e48e2b2233f.

Prior complete semantic approvals are reused. This review concerns only exact source-marker relocation and added leavevmode commands. The seven original source-page images325,362,364,365,405,422,434 were actually opened again to verify the first/last source content. Current changed TeX lines were read independently.

TC files:
- ch20-sec03:325start is adjacent to the first Dynkin diagram includegraphics inside center, after leavevmode; this diagram is the first actual content on original325.
- ch22-sec03:362start is adjacent to the first shaded root-grid figure;362end is adjacent to the final seven-weight diagram inside center. Original362 actually starts/ends with these two diagrams.364start similarly binds the first wedge-square multiplicity figure.365start binds the first actual paragraph beginning Clearly,this contains a copy, in the same horizontal paragraph.
- ch23-sec03:405start binds the resizebox containing the entire translated Diagram23.58. Original405 is the full sideways diagram page. No node,text,arrow,size,or drawing byte changed.
- ch24-sec02:422start binds the first actual paragraph about changing lambda_n to -lambda_n.
- ch25-sec02:434start binds the first partition-function ray diagram inside center.

Root appD-sec04:502start is after the D.4 heading and adjacent to its first actual paragraph, after leavevmode. It is not placed in a title argument and therefore does not replay in TOC. The first paragraph agrees with the previously reviewed original502 material.

All six current files were independently inversed to their saved real before bytes. Every before hash and every before byte matches the corresponding prior TA-approved snapshot. For TC all original CR/LF counts and all bytes after stripping only source markers/leavevmode are identical. Root D4 was independently reconstructed by restoring its original leading marker line and removing only the new paragraph binding. No mathematics,Chinese text,punctuation,diagram content,or other shared interface changed. Current actual byte snapshots and hashes are approved.

This is source-binding approval only. The actual new candidate04 AUX positions,named PDF destinations,source last/first page ownership,and GoTo actions remain subject to D's independent audit after complete compilation; no final navigation success is asserted here.
