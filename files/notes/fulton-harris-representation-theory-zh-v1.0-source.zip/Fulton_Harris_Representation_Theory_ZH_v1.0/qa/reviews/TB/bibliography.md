# 全参考书目独立审校（TB）

审者TB，非译者root。已逐幅实际打开原物545–550六页，对照matter/bibliography.tex及六个page单元的全部条目。这里审的是原书著录的忠实转写、篇名/书名中文语义与顺序；没有联网改写版本、补现代DOI或纠正原著录。原件SHA同账本。

每一条均核了可见作者/编辑姓名和次序、题名（数学符号及法德变音字母）、刊名或出版社/城市、卷/期/系列/年份/页码、再版或并列版本等原有字段；并独立核中文题名与原义对应。下面列出逐原页实际覆盖键值：

- 物545（15条）：A-B, A-B-S, A-B-W, Ad, Ahl, A-J-K, And, Ar, A-T, B-G-G, Boe, Bor1, Bor2, Bot, Bour。

- 物546（27条）：Br, B-tD, Bu, Ca1, Ca2, Cart, Ch1, Ch2, Ch3, Ch-S, Co, C-R, D-C, DC-P, Dem, D'H, Di1, Di2, Dia, Don, Dor, Dr, Dy-O, ES-K, Foa, Fr1, Fr2。

- 物547（27条）：Fr-dV, Fro1, Fro2, Fu, G-H, Gil, G-N-W, Gr, Gre, Grie, Ha, Ham, Har, Hel, Her, Hi, Ho1, Ho2, Ho3, H-P, H-S, Hu1, Hu2, Hu3, Hur, Hus, In。

- 物548（26条）：Iv, Jac1, Jac2, Jac3, Jac4, Ja-Ke, Jam, J-L, Ke, Kem, Ki1, Ki2, Kir, Kl, K-N, Kn, Kos, Ko-Te, Ku, Kum1, Kum2, Le, Li, LIE, Lit1, Lit2。

- 物549（28条）：Lit3, Liu, L-M, L-M-S, Lo, L-S, L-T, L-VdV, L-V, Mac, Mack, M-S, Mur1, Mur2, No, N-S, Pe1, Pe2, Por, Pos, Pr, P-S, P-W, Qu, Ra, Sc, Sch, Se1。

- 物550（21条）：Se2, Se3, S-K, Sp, Sta, Ste1, Ste2, S-W, Ti1, Ti2, To, Tow1, Tow2, Va, vdW, Vu, Wa, We1, We2, Ze, Žel。

## 特别逐项核验与问题闭环

545：A-B原刊卷确写9；A-J-K作者确Abramsky且群符号S_s，未代作者修正；Bor1两个出版版本；Bour四并列著作及章节1–3/4,5,6/7,8/Algebra1Chapter3/全部年城完整。546：Ca1 Hermann+Dover、Ch3讨论班1956–1958/1958、Ch-S两例外类型、Dem777及页221–227、D'H基本表示、Di2论文集及87–88、Dy-O第二系列21、Fr1双年1951/1960均原样。547：Fro1/2原论文年页及论文全集III双重引文；Gre两卷年页；Ha原to appear译待出版；Ho1附后卷页；H-P三年；全部变音姓名与Hur德题名逐字。548：Jac3题名原为type G无下标；Jac4 D4；J-L Toruń及法文Astérisque；Ki1/2全部群类型/卷页；PRV三姓与Kum两论文；LIE讨论班日期/双题名；Lit2三版年份与出版者。549：Lo原只Loos无首名不增补；L-T两期卷页；Mack导言与该书Biedenharn/Louck作者关系/系列9；M-S原G.Musili不默改；Qu模2/超特殊/旋量；Se1原年完整。550：Sp原键没有数字1（原其他章如引用Sp1属于来源错引，不擅改书目键）；Sta原卷1；Ste1四GL/PGL对象；vdW原德文quarternären/Giebiet拼法保留；We1第二版1946；Ze与Žel区分及后者变音显示。

独审提出547原键最后字形是小写l，初稿误作数字1的Gi1。已保存放大裁片qa/reviews/TB/gil-key.png，root将显示和内部键均改为Gil；TB重新读取当前文件确认。其余未发现待修问题。wrapper六无条件input顺序完整；六物页起止锚各一对。7单元通过，批准绑定账本实际SHA与真实已读字节快照。
