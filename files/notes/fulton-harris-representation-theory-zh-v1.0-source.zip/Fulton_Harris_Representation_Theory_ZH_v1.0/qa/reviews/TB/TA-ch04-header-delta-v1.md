# TA lecture 4: local running-header delta review

Author: TA. Independent reviewer: TB.

The final change retains the complete mathematical chapter title, its existing explicit title line break, the Frobenius mbox, and the plain-text PDF bookmark. It adds exactly one markboth command immediately after the chapter title, setting a short, single-line running header. This is the local fallback authorized by root.

The author's actual before snapshot (qa/author-TA/layout-ch04-header-before.tex) is byte-for-byte identical to TB's previous approved snapshot. Removing the unique added markboth line, including its line ending, exactly restores those previously approved bytes. No other bytes changed.

TB independently compiled the whole lecture from the book working directory. The preview has 15 pages; TB actually inspected current pages 1, 2, and 3 at 1.5x. The title remains complete on two clear lines, Frobenius remains intact, and the next two pages have a single-line lecture-number header without collision or clipping. The current log has no Overfull, Underfull, Missing character, Token not allowed, or Package fancyhdr Warning. Headheight remains 14pt. Neither the shared preamble nor the global header height was changed.

This approves only the current local source delta. Final whole-book PDF visual acceptance remains a separate gate. The new exact-byte snapshot and ledger record are saved, and all previous evidence is retained. The companion JSON records the old and current source hashes, exact added line, preview PDF hash, and actually inspected pages.
