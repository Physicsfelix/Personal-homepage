# Frozen candidate02: TB final visual review

PDF SHA-256: 1538220641ed481fef119308e90f96c31e044c35da9571df6e3bf909f4aecfa7
PDF total: 473 physical pages. TB reviewed physical pages 1-118 inclusive (118 pages).

Frozen 386-input manifest: qa/visual-frozen/candidate-02-compile-input-manifest.json (40fda0d0db60a5df7d5cb6470d545decdbf488df894ce600ceb72aa98abd9ea9).
All 386 current hashes matched this manifest when the candidate02 review started. The later approved exercise8.44 layout change intentionally supersedes that source identity; no claim that current sources still equal candidate02 is made.
The source semantic reviews remain recorded separately. This report concerns the actual rendered full-book candidate02.

Render packet manifest SHA-256: aaae3bd9dd60f461f66994c137f0a677c580c9b3e1db6df565fc353173ba08cf.
All 118 image hashes and all raw pixel buffers were independently verified against a fresh 1.5x render of the frozen PDF. Every one of these images was actually displayed and visually inspected; image creation or hashing was not counted as viewing. Thirty four-page overview sheets were also actually viewed. The final overview sheet includes pages119-120, which are outside this report scope.

Result: all text, figures, character tables, Young diagrams, footnotes, dense formulas, contents entries, chapter transitions and continued boxes in scope are legible and within margins. Copyright columns, lecture4 whole-word two-line title and short running headers, and lecture6 footnotes were rechecked in this full-book PDF.

TB-V01: physical104 contains only exercise8.44(c), a single-line chapter tail. Root accepted repair. The one-line source layout delta was independently compiled and visually approved in TA-ch08-tail-delta-v1.md/json; immutable candidate02 still contains the old defect. Candidate03 full-PDF affected-page review remains necessary. No other visual defect was found in physical1-118.

## Per-page actual observations

- Physical 1 (label 1): full 1.5x page and four-page overview actually viewed. Cover title and author block; intentional whitespace.
- Physical 2 (label i): full 1.5x page and four-page overview actually viewed. Series half-title, volume and editors; intentional whitespace.
- Physical 3 (label ii): full 1.5x page and four-page overview actually viewed. Series lists: all bullets and wrapped Latin titles fit.
- Physical 4 (label iii): full 1.5x page and four-page overview actually viewed. Original title: authors, 144 illustrations, publisher block fit.
- Physical 5 (label iv): full 1.5x page and four-page overview actually viewed. Copyright: two author columns, three editor columns, CIP, links and copyright paragraphs fit; corrected noindent layout verified.
- Physical 6 (label v): full 1.5x page and four-page overview actually viewed. Preface opening: dense Chinese paragraphs legible.
- Physical 7 (label vi): full 1.5x page and four-page overview actually viewed. Preface continuation and acknowledgments: long names wrap within margin.
- Physical 8 (label vii): full 1.5x page and four-page overview actually viewed. Preface tail and fifth-printing note: intentional chapter-tail whitespace.
- Physical 9 (label viii): full 1.5x page and four-page overview actually viewed. Using this book: skip-list and star explanation fit.
- Physical 10 (label ix): full 1.5x page and four-page overview actually viewed. TOC first page: ch4 two-line title and page number aligned.
- Physical 11 (label x): full 1.5x page and four-page overview actually viewed. TOC second page: parts II/ch6-13/math titles legible.
- Physical 12 (label xi): full 1.5x page and four-page overview actually viewed. TOC third page: parts III/ch14-20/math titles fit.
- Physical 13 (label xii): full 1.5x page and four-page overview actually viewed. TOC fourth page: part IV/ch21-26/AppA entries aligned.
- Physical 14 (label xiii): full 1.5x page and four-page overview actually viewed. TOC final page: AppB-F, hints, references and both indices aligned.
- Physical 15 (label 1): full 1.5x page and four-page overview actually viewed. Part I title and all introductory paragraphs fit.
- Physical 16 (label 2): full 1.5x page and four-page overview actually viewed. Lecture1 opening: navigation, square diagram and bottom footnote legible.
- Physical 17 (label 3): full 1.5x page and four-page overview actually viewed. Hom diagram, tensor/exterior powers and starred exercises fit.
- Physical 18 (label 4): full 1.5x page and four-page overview actually viewed. Section1.2: proposition/corollary boxes, averaging sums and matrix legible.
- Physical 19 (label 5): full 1.5x page and four-page overview actually viewed. Schur lemma and decomposition boxes; display numbers fit.
- Physical 20 (label 6): full 1.5x page and four-page overview actually viewed. Section1.3: exterior-power formula and S3 model legible.
- Physical 21 (label 7): full 1.5x page and four-page overview actually viewed. S3 eigenvector derivation, ex1.10 and tensor decomposition fit.
- Physical 22 (label 8): full 1.5x page and four-page overview actually viewed. Lecture1 exercises1.11-14 with stars and subquestions fit.
- Physical 23 (label 9): full 1.5x page and four-page overview actually viewed. Lecture2 opening and proposition2.1 box legible.
- Physical 24 (label 10): full 1.5x page and four-page overview actually viewed. First S3 character table, formula derivation and exercises fit.
- Physical 25 (label 11): full 1.5x page and four-page overview actually viewed. Section2.2 projection proposition and trace formula fit.
- Physical 26 (label 12): full 1.5x page and four-page overview actually viewed. Orthogonality equations2.10/11 and four theorem/corollary boxes legible.
- Physical 27 (label 13): full 1.5x page and four-page overview actually viewed. Regular-character piecewise expression and orthogonality sums fit; section2.3 starts with context.
- Physical 28 (label 14): full 1.5x page and four-page overview actually viewed. Two S4 character tables and bottom footnote complete.
- Physical 29 (label 15): full 1.5x page and four-page overview actually viewed. A4 character table complete; proposition2.28 starts at bottom.
- Physical 30 (label 16): full 1.5x page and four-page overview actually viewed. Proposition2.28 continuation box at top aligns cleanly with preceding page; proof and proposition2.30 legible.
- Physical 31 (label 17): full 1.5x page and four-page overview actually viewed. Representation-ring maps and projection formulas2.31/32 fit; ex2.33(a-c) legible.
- Physical 32 (label 18): full 1.5x page and four-page overview actually viewed. Lecture2 final starred exercises and problems complete.
- Physical 33 (label 19): full 1.5x page and four-page overview actually viewed. Lecture3 opening/nav, source note and partial S5 table legible.
- Physical 34 (label 20): full 1.5x page and four-page overview actually viewed. Complete S5 table, exterior-product map and footnote legible.
- Physical 35 (label 21): full 1.5x page and four-page overview actually viewed. A5 table includes both radical fractions; no row or column collisions.
- Physical 36 (label 22): full 1.5x page and four-page overview actually viewed. Clifford/Heisenberg exercises, two matrices and section3.2 opening fit.
- Physical 37 (label 23): full 1.5x page and four-page overview actually viewed. Dense exterior-power proof with nested sums and factorials fully within margins.
- Physical 38 (label 24): full 1.5x page and four-page overview actually viewed. Section3.3 induced-representation construction: all long equations fit.
- Physical 39 (label 25): full 1.5x page and four-page overview actually viewed. Proposition3.17, three-arrow map and character formula fit.
- Physical 40 (label 26): full 1.5x page and four-page overview actually viewed. Frobenius reciprocity and Artin theorem boxes fit; exercises complete.
- Physical 41 (label 27): full 1.5x page and four-page overview actually viewed. Brauer theorem and section3.4 group-algebra proposition legible.
- Physical 42 (label 28): full 1.5x page and four-page overview actually viewed. Fourier inversion/Plancherel displays and ex3.32(a-c) legible.
- Physical 43 (label 29): full 1.5x page and four-page overview actually viewed. Section3.5 opening, real-representation criterion and linear/conjugate map fit.
- Physical 44 (label 30): full 1.5x page and four-page overview actually viewed. Real/quaternionic classification box, rotation matrix and footnote fit.
- Physical 45 (label 31): full 1.5x page and four-page overview actually viewed. Lecture3 final exercises with stars and all subquestions fit.
- Physical 46 (label 32): full 1.5x page and four-page overview actually viewed. Lecture4 two-line title, intact Frobenius, Young diagram and footnote fit.
- Physical 47 (label 33): full 1.5x page and four-page overview actually viewed. Short lecture4 running header normal; numbered Young tableau, equations4.1/2, theorem4.3 and footnote legible.
- Physical 48 (label 34): full 1.5x page and four-page overview actually viewed. Small-group Young diagram array S2-S4 and ex4.4 subquestions legible.
- Physical 49 (label 35): full 1.5x page and four-page overview actually viewed. S5 diagram array and hook shape, formulas4.7-10 all fit.
- Physical 50 (label 36): full 1.5x page and four-page overview actually viewed. Dense dimension derivation, Vandermonde determinants and hook arrows legible.
- Physical 51 (label 37): full 1.5x page and four-page overview actually viewed. Hook-length numbered tableau and long ex4.17(a) formulas legible.
- Physical 52 (label 38): full 1.5x page and four-page overview actually viewed. Frobenius characteristic diagram with four hooks and labels fit; section4.2 opens cleanly.
- Physical 53 (label 39): full 1.5x page and four-page overview actually viewed. Four lemma boxes4.21-26 and dense proofs fit.
- Physical 54 (label 40): full 1.5x page and four-page overview actually viewed. Section4.3 opening, induced maps and long factorial products fit.
- Physical 55 (label 41): full 1.5x page and four-page overview actually viewed. Coefficient extraction4.31-36 and Kostka definitions legible.
- Physical 56 (label 42): full 1.5x page and four-page overview actually viewed. Proposition4.37 and Young-rule box4.39; summation limits legible.
- Physical 57 (label 43): full 1.5x page and four-page overview actually viewed. Determinant/outer-product and Pieri exercises fit.
- Physical 58 (label 44): full 1.5x page and four-page overview actually viewed. Skew-hook shaded Young figure and Murnaghan-Nakayama expressions clear.
- Physical 59 (label 45): full 1.5x page and four-page overview actually viewed. Ex4.48-52, paired piecewise expressions and map fit.
- Physical 60 (label 46): full 1.5x page and four-page overview actually viewed. Ex4.52 continuation(a-f) and Hopf algebra expressions legible; intentional tail whitespace.
- Physical 61 (label 47): full 1.5x page and four-page overview actually viewed. Lecture5 title/navigation and Clifford-theory proposition fit.
- Physical 62 (label 48): full 1.5x page and four-page overview actually viewed. Symmetric Young figure with three thick hooks clear; proposition5.3 begins cleanly.
- Physical 63 (label 49): full 1.5x page and four-page overview actually viewed. Proposition5.3 continuation, ex5.4 steps and source notes fit.
- Physical 64 (label 50): full 1.5x page and four-page overview actually viewed. GL2 subgroups/matrices and four conjugacy-class rows legible.
- Physical 65 (label 51): full 1.5x page and four-page overview actually viewed. Character rows U/V/W/Ind and source note fit within margins.
- Physical 66 (label 52): full 1.5x page and four-page overview actually viewed. Full GL2 character table with four matrix headers legible.
- Physical 67 (label 53): full 1.5x page and four-page overview actually viewed. Eight SL2 conjugacy-class matrix rows and sizes fit; dense text below clear.
- Physical 68 (label 54): full 1.5x page and four-page overview actually viewed. Four exceptional character rows and matrix headers, ex5.8-10 fit.
- Physical 69 (label 55): full 1.5x page and four-page overview actually viewed. Lecture5 final exercise/source note and closing paragraphs fit; intentional tail whitespace.
- Physical 70 (label 56): full 1.5x page and four-page overview actually viewed. Lecture6 opening and tensor symmetrizer definition fit.
- Physical 71 (label 57): full 1.5x page and four-page overview actually viewed. Two bottom footnotes, equations6.1/2 and footer separated; corrected local page height verified.
- Physical 72 (label 58): full 1.5x page and four-page overview actually viewed. Theorem6.3 four parts and corollary6.6 boxes clear.
- Physical 73 (label 59): full 1.5x page and four-page overview actually viewed. Tensor/Pieri decompositions and source note fit.
- Physical 74 (label 60): full 1.5x page and four-page overview actually viewed. Ex6.11(a,b), restrictions and ex6.13 clear; subscript products legible.
- Physical 75 (label 61): full 1.5x page and four-page overview actually viewed. Two long composite maps and ex6.14-17 fit.
- Physical 76 (label 62): full 1.5x page and four-page overview actually viewed. Shaded skew tableau and seven skew Schur formulas legible.
- Physical 77 (label 63): full 1.5x page and four-page overview actually viewed. Skew Schur formulas(viii,ix), contraction maps and Koszul sequence fit.
- Physical 78 (label 64): full 1.5x page and four-page overview actually viewed. Section6.2 lemma6.22 box and six-object commutative diagram fit.
- Physical 79 (label 65): full 1.5x page and four-page overview actually viewed. Double-commutant lemma and equations6.24-26 fit.
- Physical 80 (label 66): full 1.5x page and four-page overview actually viewed. Equation6.27 and ex6.28-31 legible.
- Physical 81 (label 67): full 1.5x page and four-page overview actually viewed. Exercise6.32 plus source note complete; chapter-tail whitespace intentional.
- Physical 82 (label 68): full 1.5x page and four-page overview actually viewed. PartII title and introductory paragraphs with footnote fit.
- Physical 83 (label 69): full 1.5x page and four-page overview actually viewed. PartII four-stage diagram, continuation and footnote fit.
- Physical 84 (label 70): full 1.5x page and four-page overview actually viewed. Lecture7 opening/nav and immersion discussion fit.
- Physical 85 (label 71): full 1.5x page and four-page overview actually viewed. Two original figure crops (immersion and irrational torus line) are clear; section7.2 begins cleanly.
- Physical 86 (label 72): full 1.5x page and four-page overview actually viewed. Two block matrices with side block-size labels and bottom footnote legible.
- Physical 87 (label 73): full 1.5x page and four-page overview actually viewed. Hermite equations and first-slot convention footnote fit.
- Physical 88 (label 74): full 1.5x page and four-page overview actually viewed. Quaternionic scalar-action matrices and ex7.4 opening clear.
- Physical 89 (label 75): full 1.5x page and four-page overview actually viewed. Complex-group discussion and notation list fit.
- Physical 90 (label 76): full 1.5x page and four-page overview actually viewed. Section7.3 two proposition boxes; embedded covering-map footnote clear.
- Physical 91 (label 77): full 1.5x page and four-page overview actually viewed. Lecture7 final double-cover exercises and source note fit.
- Physical 92 (label 78): full 1.5x page and four-page overview actually viewed. Lecture8 opening/nav and first group-action square fit.
- Physical 93 (label 79): full 1.5x page and four-page overview actually viewed. Conjugation and tangent squares, ad definitions and footnote fit.
- Physical 94 (label 80): full 1.5x page and four-page overview actually viewed. Bracket square and derivative calculation legible.
- Physical 95 (label 81): full 1.5x page and four-page overview actually viewed. Jacobi equation and Lie-algebra definition box clear.
- Physical 96 (label 82): full 1.5x page and four-page overview actually viewed. Representation definition and long tensor derivative calculation fit.
- Physical 97 (label 83): full 1.5x page and four-page overview actually viewed. Dual/invariant forms and section8.2 boundary clear.
- Physical 98 (label 84): full 1.5x page and four-page overview actually viewed. Orthogonal/symplectic Lie-algebra equations8.18-23 fit.
- Physical 99 (label 85): full 1.5x page and four-page overview actually viewed. Derivation/vector-field exercises and section8.3 beginning fit.
- Physical 100 (label 86): full 1.5x page and four-page overview actually viewed. One-parameter subgroup construction and product-rule equation fit.
- Physical 101 (label 87): full 1.5x page and four-page overview actually viewed. Exponential proposition and naturality square clear; series products fit.
- Physical 102 (label 88): full 1.5x page and four-page overview actually viewed. Campbell-Hausdorff expansion and ex8.35-40 legible.
- Physical 103 (label 89): full 1.5x page and four-page overview actually viewed. Full 1.5x view: proof/8.42/Second Principle/8.43 and8.44(a,b) all complete;8.44(c) continues next page. [TB-V01]
- Physical 104 (label 90): full 1.5x page and four-page overview actually viewed. Full1.5x view: only8.44(c) top line; no clipping, but isolated tail. [TB-V01]
- Physical 105 (label 91): full 1.5x page and four-page overview actually viewed. Lecture9 title/nav, definitions and source note fit.
- Physical 106 (label 92): full 1.5x page and four-page overview actually viewed. Descending/derived series formulas and classification definitions fit.
- Physical 107 (label 93): full 1.5x page and four-page overview actually viewed. Radical exact sequence, semidirect-product exercise and source note clear.
- Physical 108 (label 94): full 1.5x page and four-page overview actually viewed. Engel/Lie theorem boxes and long proof fit.
- Physical 109 (label 95): full 1.5x page and four-page overview actually viewed. Lie lemma9.13 proof and proposition9.17 fit.
- Physical 110 (label 96): full 1.5x page and four-page overview actually viewed. Section9.3 complete-reducibility box and three representation matrices fit.
- Physical 111 (label 97): full 1.5x page and four-page overview actually viewed. Jordan-decomposition theorem/source note and unitary-trick chain fit.
- Physical 112 (label 98): full 1.5x page and four-page overview actually viewed. Unitary-trick tail, source notes, section9.4 and classification box fit.
- Physical 113 (label 99): full 1.5x page and four-page overview actually viewed. Lecture9 closing roadmap and paragraphs fit; intentional tail whitespace.
- Physical 114 (label 100): full 1.5x page and four-page overview actually viewed. Lecture10 title/nav and low-dimensional classification fit.
- Physical 115 (label 101): full 1.5x page and four-page overview actually viewed. Four-object quotient diagram and adjoint matrices fit.
- Physical 116 (label 102): full 1.5x page and four-page overview actually viewed. Group multiplication matrices and central-cover tower clear; section10.2 begins cleanly.
- Physical 117 (label 103): full 1.5x page and four-page overview actually viewed. Heisenberg group/center matrices, commutator derivation and exercise10.3 fit.
- Physical 118 (label 104): full 1.5x page and four-page overview actually viewed. Real Heisenberg representation, source note and section10.3 opening fit.

No author source was edited during this visual review. Only TB QA records were written. This report does not approve the full 473-page book or the subsequent candidate03.
