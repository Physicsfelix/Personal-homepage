# Candidate04 final visual review: TB

Current PDF SHA-256: 66e411da4c3bc450cf843b677ffd68660bec74a8c7ba8a253672d56962b7cd0d
Current complete PDF: 472 physical pages. TB scope: physical1-117 inclusive, 117 pages.

Frozen compile manifest SHA-256: afc2b6730f1d3ab8d710964278acf4245bcd5b461fa19494360535bb1f9516a1
All 386 compile input files and seven index-generation dependencies were independently hashed and match the frozen current manifest. This hash check does not replace the separate semantic reviews.

PASS for TB visual scope: 22 changed pages were displayed and actually inspected at 1.5x from candidate04. The other95 pages carry their existing actual candidate02 visual evidence only after independent equality of complete page geometry, complete raw text character/coordinate dictionaries, and complete rendered pixel buffers. All117 pages have explicit per-page records. No candidate03 approval is claimed.

The copyright columns, lecture4 title/running headers, lecture6 footnotes, character tables, Young diagrams and continued boxes retain their actual-view evidence through all three exact equality checks. Changed TOC pages, anchor-binding content pages, exercise8.44 and the repaginated lecture9/10 pages were actually re-viewed.

TB-V01 CLOSED: current physical103 contains all parts(a,b,c) of exercise8.44 with clear footer separation. Physical104 opens lecture9. No open layout finding remains in physical1-117.

## Per-page evidence

- Physical1 (label 1), old physical1: strict carry of actual candidate02 full-page view after all three independent equality checks. Cover title and author block; intentional whitespace.
- Physical2 (label i), old physical2: strict carry of actual candidate02 full-page view after all three independent equality checks. Series half-title, volume and editors; intentional whitespace.
- Physical3 (label ii), old physical3: strict carry of actual candidate02 full-page view after all three independent equality checks. Series lists: all bullets and wrapped Latin titles fit.
- Physical4 (label iii), old physical4: strict carry of actual candidate02 full-page view after all three independent equality checks. Original title: authors, 144 illustrations, publisher block fit.
- Physical5 (label iv), old physical5: strict carry of actual candidate02 full-page view after all three independent equality checks. Copyright: two author columns, three editor columns, CIP, links and copyright paragraphs fit; corrected noindent layout verified.
- Physical6 (label v), old physical6: strict carry of actual candidate02 full-page view after all three independent equality checks. Preface opening: dense Chinese paragraphs legible.
- Physical7 (label vi), old physical7: strict carry of actual candidate02 full-page view after all three independent equality checks. Preface continuation and acknowledgments: long names wrap within margin.
- Physical8 (label vii), old physical8: strict carry of actual candidate02 full-page view after all three independent equality checks. Preface tail and fifth-printing note: intentional chapter-tail whitespace.
- Physical9 (label viii), old physical9: strict carry of actual candidate02 full-page view after all three independent equality checks. Using this book: skip-list and star explanation fit.
- Physical10 (label ix), old physical10: strict carry of actual candidate02 full-page view after all three independent equality checks. TOC first page: ch4 two-line title and page number aligned.
- Physical11 (label x), old physical11: actual candidate04 full-page 1.5x image displayed and inspected. Updated TOC ch6-13: all titles, leaders and current page numbers clear.
- Physical12 (label xi), old physical12: actual candidate04 full-page 1.5x image displayed and inspected. Updated TOC ch14-20 and partIII: math titles and current page numbers clear.
- Physical13 (label xii), old physical13: actual candidate04 full-page 1.5x image displayed and inspected. Updated TOC partIV/ch21-26/AppA: titles and current page numbers clear.
- Physical14 (label xiii), old physical14: actual candidate04 full-page 1.5x image displayed and inspected. Updated TOC AppB-F/hints/bibliography/both indices aligned and readable.
- Physical15 (label 1), old physical15: strict carry of actual candidate02 full-page view after all three independent equality checks. Part I title and all introductory paragraphs fit.
- Physical16 (label 2), old physical16: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture1 opening: navigation, square diagram and bottom footnote legible.
- Physical17 (label 3), old physical17: strict carry of actual candidate02 full-page view after all three independent equality checks. Hom diagram, tensor/exterior powers and starred exercises fit.
- Physical18 (label 4), old physical18: strict carry of actual candidate02 full-page view after all three independent equality checks. Section1.2: proposition/corollary boxes, averaging sums and matrix legible.
- Physical19 (label 5), old physical19: strict carry of actual candidate02 full-page view after all three independent equality checks. Schur lemma and decomposition boxes; display numbers fit.
- Physical20 (label 6), old physical20: strict carry of actual candidate02 full-page view after all three independent equality checks. Section1.3: exterior-power formula and S3 model legible.
- Physical21 (label 7), old physical21: strict carry of actual candidate02 full-page view after all three independent equality checks. S3 eigenvector derivation, ex1.10 and tensor decomposition fit.
- Physical22 (label 8), old physical22: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture1 exercises1.11-14 with stars and subquestions fit.
- Physical23 (label 9), old physical23: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture2 opening and proposition2.1 box legible.
- Physical24 (label 10), old physical24: strict carry of actual candidate02 full-page view after all three independent equality checks. First S3 character table, formula derivation and exercises fit.
- Physical25 (label 11), old physical25: strict carry of actual candidate02 full-page view after all three independent equality checks. Section2.2 projection proposition and trace formula fit.
- Physical26 (label 12), old physical26: strict carry of actual candidate02 full-page view after all three independent equality checks. Orthogonality equations2.10/11 and four theorem/corollary boxes legible.
- Physical27 (label 13), old physical27: strict carry of actual candidate02 full-page view after all three independent equality checks. Regular-character piecewise expression and orthogonality sums fit; section2.3 starts with context.
- Physical28 (label 14), old physical28: strict carry of actual candidate02 full-page view after all three independent equality checks. Two S4 character tables and bottom footnote complete.
- Physical29 (label 15), old physical29: strict carry of actual candidate02 full-page view after all three independent equality checks. A4 character table complete; proposition2.28 starts at bottom.
- Physical30 (label 16), old physical30: strict carry of actual candidate02 full-page view after all three independent equality checks. Proposition2.28 continuation box at top aligns cleanly with preceding page; proof and proposition2.30 legible.
- Physical31 (label 17), old physical31: strict carry of actual candidate02 full-page view after all three independent equality checks. Representation-ring maps and projection formulas2.31/32 fit; ex2.33(a-c) legible.
- Physical32 (label 18), old physical32: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture2 final starred exercises and problems complete.
- Physical33 (label 19), old physical33: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture3 opening/nav, source note and partial S5 table legible.
- Physical34 (label 20), old physical34: strict carry of actual candidate02 full-page view after all three independent equality checks. Complete S5 table, exterior-product map and footnote legible.
- Physical35 (label 21), old physical35: strict carry of actual candidate02 full-page view after all three independent equality checks. A5 table includes both radical fractions; no row or column collisions.
- Physical36 (label 22), old physical36: strict carry of actual candidate02 full-page view after all three independent equality checks. Clifford/Heisenberg exercises, two matrices and section3.2 opening fit.
- Physical37 (label 23), old physical37: strict carry of actual candidate02 full-page view after all three independent equality checks. Dense exterior-power proof with nested sums and factorials fully within margins.
- Physical38 (label 24), old physical38: strict carry of actual candidate02 full-page view after all three independent equality checks. Section3.3 induced-representation construction: all long equations fit.
- Physical39 (label 25), old physical39: actual candidate04 full-page 1.5x image displayed and inspected. Exercise3.16 start after binding repair; full page, formula3.18 and subquestions remain legible.
- Physical40 (label 26), old physical40: actual candidate04 full-page 1.5x image displayed and inspected. Corollary3.20 start after binding repair; box, proof and Artin theorem fit.
- Physical41 (label 27), old physical41: strict carry of actual candidate02 full-page view after all three independent equality checks. Brauer theorem and section3.4 group-algebra proposition legible.
- Physical42 (label 28), old physical42: strict carry of actual candidate02 full-page view after all three independent equality checks. Fourier inversion/Plancherel displays and ex3.32(a-c) legible.
- Physical43 (label 29), old physical43: strict carry of actual candidate02 full-page view after all three independent equality checks. Section3.5 opening, real-representation criterion and linear/conjugate map fit.
- Physical44 (label 30), old physical44: strict carry of actual candidate02 full-page view after all three independent equality checks. Real/quaternionic classification box, rotation matrix and footnote fit.
- Physical45 (label 31), old physical45: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture3 final exercises with stars and all subquestions fit.
- Physical46 (label 32), old physical46: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture4 two-line title, intact Frobenius, Young diagram and footnote fit.
- Physical47 (label 33), old physical47: strict carry of actual candidate02 full-page view after all three independent equality checks. Short lecture4 running header normal; numbered Young tableau, equations4.1/2, theorem4.3 and footnote legible.
- Physical48 (label 34), old physical48: strict carry of actual candidate02 full-page view after all three independent equality checks. Small-group Young diagram array S2-S4 and ex4.4 subquestions legible.
- Physical49 (label 35), old physical49: strict carry of actual candidate02 full-page view after all three independent equality checks. S5 diagram array and hook shape, formulas4.7-10 all fit.
- Physical50 (label 36), old physical50: strict carry of actual candidate02 full-page view after all three independent equality checks. Dense dimension derivation, Vandermonde determinants and hook arrows legible.
- Physical51 (label 37), old physical51: strict carry of actual candidate02 full-page view after all three independent equality checks. Hook-length numbered tableau and long ex4.17(a) formulas legible.
- Physical52 (label 38), old physical52: strict carry of actual candidate02 full-page view after all three independent equality checks. Frobenius characteristic diagram with four hooks and labels fit; section4.2 opens cleanly.
- Physical53 (label 39), old physical53: strict carry of actual candidate02 full-page view after all three independent equality checks. Four lemma boxes4.21-26 and dense proofs fit.
- Physical54 (label 40), old physical54: strict carry of actual candidate02 full-page view after all three independent equality checks. Section4.3 opening, induced maps and long factorial products fit.
- Physical55 (label 41), old physical55: strict carry of actual candidate02 full-page view after all three independent equality checks. Coefficient extraction4.31-36 and Kostka definitions legible.
- Physical56 (label 42), old physical56: strict carry of actual candidate02 full-page view after all three independent equality checks. Proposition4.37 and Young-rule box4.39; summation limits legible.
- Physical57 (label 43), old physical57: strict carry of actual candidate02 full-page view after all three independent equality checks. Determinant/outer-product and Pieri exercises fit.
- Physical58 (label 44), old physical58: strict carry of actual candidate02 full-page view after all three independent equality checks. Skew-hook shaded Young figure and Murnaghan-Nakayama expressions clear.
- Physical59 (label 45), old physical59: strict carry of actual candidate02 full-page view after all three independent equality checks. Ex4.48-52, paired piecewise expressions and map fit.
- Physical60 (label 46), old physical60: strict carry of actual candidate02 full-page view after all three independent equality checks. Ex4.52 continuation(a-f) and Hopf algebra expressions legible; intentional tail whitespace.
- Physical61 (label 47), old physical61: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture5 title/navigation and Clifford-theory proposition fit.
- Physical62 (label 48), old physical62: strict carry of actual candidate02 full-page view after all three independent equality checks. Symmetric Young figure with three thick hooks clear; proposition5.3 begins cleanly.
- Physical63 (label 49), old physical63: strict carry of actual candidate02 full-page view after all three independent equality checks. Proposition5.3 continuation, ex5.4 steps and source notes fit.
- Physical64 (label 50), old physical64: strict carry of actual candidate02 full-page view after all three independent equality checks. GL2 subgroups/matrices and four conjugacy-class rows legible.
- Physical65 (label 51), old physical65: strict carry of actual candidate02 full-page view after all three independent equality checks. Character rows U/V/W/Ind and source note fit within margins.
- Physical66 (label 52), old physical66: strict carry of actual candidate02 full-page view after all three independent equality checks. Full GL2 character table with four matrix headers legible.
- Physical67 (label 53), old physical67: strict carry of actual candidate02 full-page view after all three independent equality checks. Eight SL2 conjugacy-class matrix rows and sizes fit; dense text below clear.
- Physical68 (label 54), old physical68: strict carry of actual candidate02 full-page view after all three independent equality checks. Four exceptional character rows and matrix headers, ex5.8-10 fit.
- Physical69 (label 55), old physical69: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture5 final exercise/source note and closing paragraphs fit; intentional tail whitespace.
- Physical70 (label 56), old physical70: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture6 opening and tensor symmetrizer definition fit.
- Physical71 (label 57), old physical71: strict carry of actual candidate02 full-page view after all three independent equality checks. Two bottom footnotes, equations6.1/2 and footer separated; corrected local page height verified.
- Physical72 (label 58), old physical72: strict carry of actual candidate02 full-page view after all three independent equality checks. Theorem6.3 four parts and corollary6.6 boxes clear.
- Physical73 (label 59), old physical73: strict carry of actual candidate02 full-page view after all three independent equality checks. Tensor/Pieri decompositions and source note fit.
- Physical74 (label 60), old physical74: strict carry of actual candidate02 full-page view after all three independent equality checks. Ex6.11(a,b), restrictions and ex6.13 clear; subscript products legible.
- Physical75 (label 61), old physical75: strict carry of actual candidate02 full-page view after all three independent equality checks. Two long composite maps and ex6.14-17 fit.
- Physical76 (label 62), old physical76: strict carry of actual candidate02 full-page view after all three independent equality checks. Shaded skew tableau and seven skew Schur formulas legible.
- Physical77 (label 63), old physical77: strict carry of actual candidate02 full-page view after all three independent equality checks. Skew Schur formulas(viii,ix), contraction maps and Koszul sequence fit.
- Physical78 (label 64), old physical78: strict carry of actual candidate02 full-page view after all three independent equality checks. Section6.2 lemma6.22 box and six-object commutative diagram fit.
- Physical79 (label 65), old physical79: strict carry of actual candidate02 full-page view after all three independent equality checks. Double-commutant lemma and equations6.24-26 fit.
- Physical80 (label 66), old physical80: strict carry of actual candidate02 full-page view after all three independent equality checks. Equation6.27 and ex6.28-31 legible.
- Physical81 (label 67), old physical81: actual candidate04 full-page 1.5x image displayed and inspected. Exercise6.32 after binding repair: text, formula, source note and footer intact.
- Physical82 (label 68), old physical82: strict carry of actual candidate02 full-page view after all three independent equality checks. PartII title and introductory paragraphs with footnote fit.
- Physical83 (label 69), old physical83: strict carry of actual candidate02 full-page view after all three independent equality checks. PartII four-stage diagram, continuation and footnote fit.
- Physical84 (label 70), old physical84: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture7 opening/nav and immersion discussion fit.
- Physical85 (label 71), old physical85: strict carry of actual candidate02 full-page view after all three independent equality checks. Two original figure crops (immersion and irrational torus line) are clear; section7.2 begins cleanly.
- Physical86 (label 72), old physical86: strict carry of actual candidate02 full-page view after all three independent equality checks. Two block matrices with side block-size labels and bottom footnote legible.
- Physical87 (label 73), old physical87: strict carry of actual candidate02 full-page view after all three independent equality checks. Hermite equations and first-slot convention footnote fit.
- Physical88 (label 74), old physical88: strict carry of actual candidate02 full-page view after all three independent equality checks. Quaternionic scalar-action matrices and ex7.4 opening clear.
- Physical89 (label 75), old physical89: strict carry of actual candidate02 full-page view after all three independent equality checks. Complex-group discussion and notation list fit.
- Physical90 (label 76), old physical90: strict carry of actual candidate02 full-page view after all three independent equality checks. Section7.3 two proposition boxes; embedded covering-map footnote clear.
- Physical91 (label 77), old physical91: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture7 final double-cover exercises and source note fit.
- Physical92 (label 78), old physical92: strict carry of actual candidate02 full-page view after all three independent equality checks. Lecture8 opening/nav and first group-action square fit.
- Physical93 (label 79), old physical93: strict carry of actual candidate02 full-page view after all three independent equality checks. Conjugation and tangent squares, ad definitions and footnote fit.
- Physical94 (label 80), old physical94: strict carry of actual candidate02 full-page view after all three independent equality checks. Bracket square and derivative calculation legible.
- Physical95 (label 81), old physical95: strict carry of actual candidate02 full-page view after all three independent equality checks. Jacobi equation and Lie-algebra definition box clear.
- Physical96 (label 82), old physical96: strict carry of actual candidate02 full-page view after all three independent equality checks. Representation definition and long tensor derivative calculation fit.
- Physical97 (label 83), old physical97: strict carry of actual candidate02 full-page view after all three independent equality checks. Dual/invariant forms and section8.2 boundary clear.
- Physical98 (label 84), old physical98: strict carry of actual candidate02 full-page view after all three independent equality checks. Orthogonal/symplectic Lie-algebra equations8.18-23 fit.
- Physical99 (label 85), old physical99: strict carry of actual candidate02 full-page view after all three independent equality checks. Derivation/vector-field exercises and section8.3 beginning fit.
- Physical100 (label 86), old physical100: strict carry of actual candidate02 full-page view after all three independent equality checks. One-parameter subgroup construction and product-rule equation fit.
- Physical101 (label 87), old physical101: strict carry of actual candidate02 full-page view after all three independent equality checks. Exponential proposition and naturality square clear; series products fit.
- Physical102 (label 88), old physical102: strict carry of actual candidate02 full-page view after all three independent equality checks. Campbell-Hausdorff expansion and ex8.35-40 legible.
- Physical103 (label 89), old physical103: actual candidate04 full-page 1.5x image displayed and inspected. Full-book current exercise8.44(a,b,c) all on one page; c has visible clear separation from footer89; previous TB-V01 isolated tail resolved.
- Physical104 (label 90), old physical105: actual candidate04 full-page 1.5x image displayed and inspected. Lecture9 opens directly after lecture8, footer90 and navigation list fit.
- Physical105 (label 91), old physical106: actual candidate04 full-page 1.5x image displayed and inspected. Descending/derived series and definitions clear, footer91 normal.
- Physical106 (label 92), old physical107: actual candidate04 full-page 1.5x image displayed and inspected. Radical exact sequence and starred exercises/source note fit, footer92 normal.
- Physical107 (label 93), old physical108: actual candidate04 full-page 1.5x image displayed and inspected. Engel/Lie theorem boxes and proofs fit, footer93 normal.
- Physical108 (label 94), old physical109: actual candidate04 full-page 1.5x image displayed and inspected. Lemma9.13 proof and proposition9.17 clear, footer94 normal.
- Physical109 (label 95), old physical110: actual candidate04 full-page 1.5x image displayed and inspected. Section9.3 box and three representation matrices clear, footer95 normal.
- Physical110 (label 96), old physical111: actual candidate04 full-page 1.5x image displayed and inspected. Jordan-decomposition theorem and unitary trick clear, footer96 normal.
- Physical111 (label 97), old physical112: actual candidate04 full-page 1.5x image displayed and inspected. Unitary-trick continuation, source notes and section9.4 clear, footer97 normal.
- Physical112 (label 98), old physical113: actual candidate04 full-page 1.5x image displayed and inspected. Lecture9 closing roadmap/paragraphs clear, footer98 normal.
- Physical113 (label 99), old physical114: actual candidate04 full-page 1.5x image displayed and inspected. Lecture10 title/navigation and section10.1 clear, footer99 normal.
- Physical114 (label 100), old physical115: actual candidate04 full-page 1.5x image displayed and inspected. Quotient square and adjoint matrices clear, footer100 normal.
- Physical115 (label 101), old physical116: actual candidate04 full-page 1.5x image displayed and inspected. Central-cover tower and section10.2 clear, footer101 normal.
- Physical116 (label 102), old physical117: actual candidate04 full-page 1.5x image displayed and inspected. Heisenberg matrices and exercise10.3 clear, footer102 normal.
- Physical117 (label 103), old physical118: actual candidate04 full-page 1.5x image displayed and inspected. Real Heisenberg source note and section10.3 opening clear, footer103 normal.

No source was modified in this batch. Source-target and index-link correctness are D separate actual AUX/PDF checks; this report approves only the stated visual range, not the entire book.
