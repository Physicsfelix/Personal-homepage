# 前置物1–10独立审校（TB）

审者TB，非作者TA。已实际逐幅打开source/pages/page-001.png至page-010.png并对照六单元全稿。以下批准为逐段内容核验，不等于最终排版验收。

- series-half-title，物1：GTM129、Readings in Mathematics、三编委姓名与Springer Study Edition全部信息均在译文。品牌图样以中文文字重排，不改变其文字内容。
- series-list，物2：GTM及UTM两栏标题、副标题；GTM的5条、UTM的10条，逐项核作者全名单（含Ebbinghaus八姓、Hämmerlin变音字符）、原书名及中文并列，没有漏条或误配。
- original-title，物3：两作者、Representation Theory / A First Course、144幅插图及Springer，逐项对应。
- copyright，物4：Fulton及Harris的院系、大学、地址邮编、两邮箱逐字；编委三人的院系/大学/East Hall/完整邮编；MSC2000四代码20G05/17B10/17B20/22E46；CIP的作者出生年、书名、系列、含书目索引说明、四主题、I/II/III附加款目、QA171.F85、1991、512.2-dc20、90-24926；两个ISBN、DOI、无酸纸；2004版权主体、233 Spring Street地址、全部翻译/复制/存储/电子与未来方法限制、商标说明、印次9及网站均保留。没有将2004误称修订新版。
- preface，物5：有限维李表示教学目标段；学科定义、群作用与非专业读者段；各类群Sn/GLnFq/SLnZ/SLnC、局部域、系数域C/R/Q/正特征、有限/无限维、范数/内积及跨页续句，逐项对应。
- preface，物6：研究方向与Harish–Chandra/ S4/SL3C例；最简单情形；例子优先、推迟一般概念；1984/1987课程、多个证明与三种理论入口；经典三族和五例外；有限群至低维例及半单性跨页句。全部六自然段及跨页连续性核对。
- preface，物7：经典系列最高权存在与几何/巧合；末六讲、五例外与一个详细例、Weyl公式；讲座抛物子群引语；Weyl和前人、Young构造、不变量与对称/外幂公式、D’Hoker/Koike/Terada、新行列式证明；其他导言；被省内容至Verma跨页词。全部原段与括号说明核对。
- preface，物8：Verma续文、Stiefel图、李代数上同调、对称空间/群上分析、算术/自守形式、p>0、其他域代数群、泛包络/Bruhat及专家意见括号；历史归功及Serre[Se2]/[Se3]、Adams[Ad]、Humphreys[Hu1]、Bourbaki[Bour]、Weyl[We1]、Littlewood[Lit1]；20位致谢姓名和Mumford；NSF/Chicago/Harvard/Macintosh及Chan Fulton；署名；修订第五次印刷注10位姓名与排印错误致谢。全名、顺序及引文代码均核。
- using-this-book，物9：先修与附录B；最少阅读跳读清单逐号核4,5,6,11.3,13.4,15.3–15.5,17.3,19.5,20,22.1,22.3,23.3–23.4,25.3,26.2；半年/全年课程与附录；例子教学理由及跨页句。原skip作为正文译出，并未当作工程范围指令。
- using-this-book，物10：烧书玩笑；几类习题、特例动机、回看旧题、进一步方向、旧文献与理论/例子分布；不按难度分级、problem/exercise区别；星号的含义与Hints/Answers/References中提示/答案/完整解/参考/组合，全段对应。

结论：六文件内容通过，无待修语义问题。物1–10起止锚各一对，源跨页续文保持。绑定账本列明的实际SHA及已读原字节快照。版权等原文内容仅忠实译出。
