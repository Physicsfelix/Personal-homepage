# D：候选04最终导航独立审计通过

实际PDF472页，SHA256 `66e411da4c3bc450cf843b677ffd68660bec74a8c7ba8a253672d56962b7cd0d`。
当前/冻结386输入清单SHA256 `afc2b6730f1d3ab8d710964278acf4245bcd5b461fa19494360535bb1f9516a1`；386项当前字节与批准字节相同，7项索引依赖亦逐项相同。详表在JSON。

1118个原页起止标签逐项解析实际AUX属性（允许非空default），与实际PDF命名目标的绝对页、逻辑页及坐标对应。559个区间起止均有序：395个跨页区间的790端点按原字形origin及图片矩形重扫空落点；164个同页区间的328端点逐一确认区间有原字形或图片、坐标顺序正常。新增空挂0。原21项逐项实际大图回查首末段、公式或图，全部关闭；182end保留合法回归。

|原物理页|端点|候选04实际物理页|实际对象|
|---|---|---|---|
|49|start|39|exercise3.16|
|50|start|40|corollary3.20|
|103|start|81|exercise6.32|
|172|start|132|exercise11.24|
|262|start|207|exercise16.11|
|285|start|225|first source paragraph|
|325|start|258|first Dynkin graphic|
|362|start|289|first weight diagram / final weight diagram|
|364|start|291|first exterior-power weight diagram|
|365|start|292|first source paragraph|
|405|start|325|figure23.58|
|422|start|339|first source paragraph|
|434|start|350|first partition diagram|
|492|start|401|corollaryC.18|
|502|start|410|D.4 heading and first paragraph|
|546|start|453|first bibitem Brauer|
|62|end|48|final S4 Young table|
|205|end|160|final displayed map|
|268|end|211|final displayed weight expression and trailing plus|
|362|end|289|first weight diagram / final weight diagram|
|477|end|387|final displayed fraction inA.60|

233符号条目+355总索引条目=588记录，583有定位条目+5父项；901原索引页码token独立从原页码表展开，再由实际AUX计算译页及动作。全部1622个实际索引链接矩形逐个核目标、实际绝对页及可见译页数字，全部一致。此数是候选04实测；修锚后同页冗余端点消失，不能复用02的1636。原顺序、缩进层级及特殊损坏/倒置/缺页处理均保留。

142原目录可见项逐项核可见页码、动作、目标逻辑页；实际143书签含额外目录项，标题及目标与实际编译bookmark逐项一致。实际目录10–14及双索引460–472全部重新大图查看。

37个脚注逐一核源呼号、当前PDF呼号、同页注体目的地；37组当前呼号/注体裁图全部实际查看。46种实际字体全部有嵌入字形程序。实际2074个内部命名动作全部解析到当前目的地，4个外链均位于物理5页：两作者mailto、DOI的HTTPS、springeronline的HTTPS；未见其他动作种类。外部网站可达性不在本地导航审计范围。

D本轮视觉117页已另存`final-visual-candidate04.json/md`。候选02/03、技术fixture及旧冷编均不作为当前页码依据。结论：最终导航PASS、原21项关闭、新开放项0。本报告不签源码ZIP，实际ZIP由TC独立审。
