# 独立审校 D：主入口、共享宏、样式及新封面

审者D，作者root；本轮未改作者文件。当前批准身份逐项写入 qa/review-ledger-D.json，快照从实际当前文件读取原字节生成。

## 主入口与来源目录

D实际打开原物11–15全部五页目录，逐组核 book/main.tex：四部分按原位置顺序出现；26讲和A–F六附录全部无条件input；没有IfFileExists、includeonly或缺章跳过。第12讲没有补造12.1。前置出版材料、前言、使用说明、附录导语、原Hints、书目、双索引均列入正式链。追加的新封面不替代原书题名/版权材料。

TOC源页组正确：物11至ch03末；物12为ch04–ch11；物13为ch12–ch19（含PartIII）；物14为ch20–appA（含PartIV和附录导语）；物15为appB至末项。目录内容通过正式章/节命令写入toc，SourcePage边界也写进toc后在目录实际排版位置执行，而不是错误地放在章正文位置。这里审的是分组与机制；跨实际目录分页的锚点位置仍待合编实测。

独立递归解析当前输入链的明细见 qa/independent-D-index-and-input-audit.json 的input_graph。审查时仍有未写齐的实际输入，因此未运行或宣称全书main编译通过。无条件包含链会如实暴露缺失，当前严格gate仍应失败。

## 共享接口与数学记号

完整读取 book/preamble.tex、book/textbook-template.sty。OriginalLecture显式设置原讲号；OriginalSection使用原节号与独立label/目录行；OriginalAppendix由主入口的appendix及字母计数配合生成。OrigRef的可见内容采用传入原号而非重排自动号码。定理/命题/习题等显式编号环境及原公式tag不改源号。

SourcePageStart/End使用独立zlabel，不经过amsmath equation label，目标命名src:物理:start/end。IndexTranslatedSpan从实际shipout提取page/abspage：同一实际页只显示一页，跨页显示起止译页并分别链接；绝对页次反向报错；未绑定时显示??。不用固定偏移猜译本页。字体、颜色、A4/24mm/11pt、Fandol/Latin Modern、原脚注呼号与注体、框内脚注环境和水平中文标点钩子的定义均已审读。

D独立建立 native-fixture.tex，真实XeLaTeX/latexmk编译4页：目录为实际第1页，甲/乙章为实际2/3页；单页显示2，跨页显示2–3，公式环境内源标记显示2；原定理1.7、公式1.9、节1.1的label与链接均保留；目录两组起止zref均真实位于目录第1页。解析实际PDF内部动作得到预期2、2、3、2页等落点。没有未定义引用、缺字、Overfull/Underfull或编译Warning。D实际查看native样例第2与第4页；该技术fixture是synthetic，不是任何原正文单元批准。

## 新封面

D实看原物3，核英文题名、副题名、William Fulton和Joe Harris。新封面是新增重排封面，不声称原书出版封面或出版社认证译本。独立cover-fixture编译1页并实际看图：标题/作者/系列字号清楚，无遮挡、裁切或重叠。封面“完整翻译”是正式全范围版的设计文字；候选/阶段稿的交付状态仍由全书验收门槛控制，不据此文字宣称当前全书完成。

## 审校门槛脚本与发现闭环

完整读取 scripts/check_current_reviews.py 初版和本轮新增七依赖版。正文单元按照最新unit-plan原作者—非作者审者对应，root接手18、AppB/C/F仍保留原非作者审者；实际图形按作者目录分配审者。每个当前文件要求approved、正确作者/审者、当前SHA、存在的独审报告和与当前字节完全相同的真实快照。未计划TeX输入报错。

新增的七项依赖包括三个中文数据、生成器、两个冻结英文索引和页映射，也核当前SHA和真实快照。D发现初版仅拒绝translator=D，遗漏/任意作者字符串可能通过，已发root；root修复为INDEX_DEPENDENCY_OWNERS精确映射。D重新读取实际修订脚本：root的三data+generator、Source-B的两索引、Source-A的map要求精确匹配，缺失/任意身份均拒绝，问题闭环。脚本本轮实际SHA另记本目录的签署清单。

D另在自身目录的隔离synthetic fixture实测七个正确owner均通过；逐项移除translator、改为D、改为无关作者，共21个错误身份情形均被正确拒绝。明细见qa/independent-D-gate-owner-fixture.json。回到实际项目运行gate，本轮六个D归属源单元和七项索引依赖均获识别，D项无错误；全书因其他范围仍缺失/未审而继续严格失败。此结果不依赖模拟fixture替代实际书稿。

## 本轮批准范围

通过共享源实现、无条件全范围结构、新封面和技术fixture的当前身份。未批准实际全书PDF、全页图、最终目录/书签、脚注落点、901真实索引译页/链接、冷重建或最终ZIP；这些须在全部正文及独审闭合后单独完成。当前gate存在剩余缺口是正确的阶段状态。
