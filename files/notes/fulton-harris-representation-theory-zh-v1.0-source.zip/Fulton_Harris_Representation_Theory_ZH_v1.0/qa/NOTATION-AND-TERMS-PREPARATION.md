# OCR后翻译阶段的记号与术语准备

本表是原文对照约束与术语准备，不是已完成的正文翻译，也不构成数学OCR通过。

## 已从原图确认的关键约定

原物理31／印刷16的式(2.11)为

\[
(\alpha,\beta)=\frac{1}{|G|}\sum_{g\in G}\overline{\alpha(g)}\,\beta(g).
\]

因此此处第一槽共轭线性、第二槽线性。不能沿用本会话先前朱克和一书的另一线性槽约定。首个源公式已由root及独立审者B看图确认；各后续语境仍须按本书原文，不根据这一处擅改作者别处定义。

原书群、李代数、Schur函子、表示、权与根的字体必须按原图分别转写。旧OCR常把对称群/交错群字形当数字，把sl、sp、so误当5、S等；禁止全局文本替换后直接定稿。\(\mathbb C\)、\(\mathbb R\)、\(\mathbb H\)、有限域及数字下标同样逐式回查。

原页60的Young图与数字表是两个不同示例；原页110的矩阵块I不是标量1。Dynkin图实际边数、箭头、根长短与角度必须共同核对；不能从OCR箭头字符串推断图。

## 暂定统一译名

|原词|译名|
|---|---|
|representation / irreducible representation|表示／不可约表示|
|complete reducibility|完全可约性|
|character / character table|特征标／特征标表|
|eigenvalue / characteristic of a field|特征值／域的特征；与character区分|
|group algebra / representation ring|群代数／表示环|
|induced representation / restriction|诱导表示／限制|
|equivariant / invariant|等变／不变|
|dual representation|对偶表示|
|tensor product / exterior power / symmetric power|张量积／外幂／对称幂|
|partition / conjugate partition|分拆／共轭分拆|
|Young diagram / Young tableau|Young图／Young表|
|standard tableau / semistandard tableau|标准Young表／半标准Young表|
|Young symmetrizer / Schur functor|Young对称化算子／Schur函子|
|hook length / skew Young diagram|钩长／斜Young图|
|plethysm|复合运算（plethysm）；保留原词以便检索|
|Lie group / Lie algebra|李群／李代数|
|semisimple / reductive|半单／约化；不得互换|
|solvable / nilpotent|可解／幂零|
|root / coroot / weight / coweight|根／余根／权／余权|
|positive root / simple root / fundamental weight|正根／单根／基本权|
|highest weight / dominant weight|最高权／占优权|
|root system / root lattice / weight lattice|根系／根格／权格|
|Weyl group / Weyl character formula|Weyl群／Weyl特征标公式；保留原缩写WCF|
|Cartan subalgebra / Killing form|Cartan子代数／Killing形式|
|centralizer / normalizer / center|中心化子／正规化子／中心|
|Borel subgroup / parabolic subgroup|Borel子群／抛物子群|
|complexification / real form|复化／实形式|
|compact form / split form|紧实形式／分裂实形式；按原语境保留base field|
|real, complex, quaternionic type|实型、复型、四元数型；与在实/复/四元数域上的表示语境区分|
|Clifford algebra / spin representation|Clifford代数／旋量表示|
|triality|三重性|
|homogeneous space / Grassmannian|齐性空间／Grassmann流形|
|symmetric function / symmetric polynomial|对称函数／对称多项式；不得混成同一概念|

译名是便于一致性的默认选项；若原文语境不同，先核定义而非机械统一。源书中的commutator algebra/commutant等历史用语须按具体定义区分，不能误译成李代数导出代数，也不能静默更改作者原词；必要时另列独立审校的译校注。

## 完整性与审者约束

- 所有原文证明中间行、例子、无编号公式、习题子问及星号、作者脚注均保留。
- Using This Book中的跳读建议照译，但不会据此删章；习题星号表示后置Hints中有相关材料，不是难度标签。
- 原Hints、Answers and References属于完整范围，不能换成新写答案；参考书目保留原著录，双索引保留原层级和出处并重建实际译页。
- 原页551确实缺印G的索引描述保持可追溯，不能把原误当OCR误并偷偷补齐。
- 每个章导语、每节、无编号整段和前后置均由未翻译该单元的子Agent实际对原图逐段逐式审校；机器OCR和编号统计均不能代替。
- 批准绑定当前文件SHA、原件SHA、实际源范围及真实已审字节副本。任何改动必须做受影响范围独立复核。
