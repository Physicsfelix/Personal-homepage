# 代数拓扑中的微分形式：中文翻译重排版源码

原著：Raoul Bott、Loring W. Tu，*Differential Forms in Algebraic Topology*，GTM 82。
本项目对应用户提供的342页原件，原件身份见 `qa/source-identity.json`。完整收录原书前后置材料、引言、四章正文、全部证明、习题与提示、图表、参考文献、记号表、索引及丛书书目；正文采用所提供《泛函分析I》v0.2样张的视觉复原样式。

## 编译

建议使用 TeX Live 2026、XeLaTeX、latexmk。中文使用 TeX Live 自带 Fandol 字体，西文字体使用 Latin Modern；源码和路径均使用 UTF-8。

在本目录打开终端，执行：

```text
latexmk -norc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
```

Windows PowerShell 也可执行 `./build.ps1`。生成文件为 `build/main.pdf`。目录、页码链接和索引依赖多轮编译，latexmk 会自动运行至稳定。仅运行一次 XeLaTeX 时可能出现尚未确定的页码。

## 文件与回查

- `main.tex` 为全书入口；`chapters/` 为正文；`matter/` 为前后置材料。
- `figures/` 包含正式编译用图和原数学图形的局部图像，`style/` 为中文教材样式。
- 原书编号和自身记号约定均保留。可确定的原文疑点另列“译校注”，不静默改写原式，也不添加原书未给的习题解答。
- 源码中的 `SourcePageStart` / `SourcePageEnd` 对应原件物理页；`qa/source-page-map.json` 和 CSV 给出与此版译稿PDF页及显示页码的对应。
- `qa/reviews/` 保存独立审校记录，`qa/compile-inputs.json` 记录实际编译输入身份，`qa/release-status.json` 记录交付验收状态。详细报告保留修订经过，当前文件身份以 `qa/current-A-accepted-inputs.json` 为准。审校记录中的本机目录已改为相对引用；原件及译稿的 SHA256 身份保持原值。

压缩包中的 TeX、图片和样式构成完整编译输入。无需原扫描整书、OCR工具、作者工作目录或旧辅助文件。封面、目录与页码随正式源码共同生成。
