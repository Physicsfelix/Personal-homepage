# Bott–Tu batch46 独审A

状态approved。完整ConeConstruction物195–196至Prop15.1原短proof/同伦段/HqRn全cases末、MV前。双原/双译/完整Fig15.2及中文P3原点重排全实看。

独核apex连续延拓：紧像有界，||Ks||≤(1−tlast)M→0；图P3原点表示domain顶点的像而非标准基向量自身零。独立逐face核原∂K−K∂=(-1)^(q+1)Id(q≥1)正确；标准plus同伦取h_q=(-1)^(q+1)K_q，q0为Id−oε而H0已前节处理。不机械改原负号、未补原留读者proof。

两独编两页文字几何像素同7880aca0，clean全嵌，nativecrop重裁同像素；两合法共享锚/6实际批准快照齐。旧317同，新2后319。非全节/全书/最终ZIP验收。
