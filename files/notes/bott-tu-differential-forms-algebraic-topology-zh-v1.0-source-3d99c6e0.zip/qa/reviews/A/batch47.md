# Bott–Tu batch47 独审A

状态approved。完整SingularChainsMV物196–199至15.6末，四原/三译/源198双完整序列交换图及重排Fig15.3实际全看。15.2/3及两个全部printedproof、15.4/5/6、finite/countable论证/所有符号和引用齐，无新注或补解。

独核自由形式链基下quotient与kerβ、三集短正合复形/15.3、有限归纳与直和有限支撑；f=(-a,a)、g=a+b、任意AbelianG都正确。图15.3按实际坐标独立核小三角全在U0∩U2且离U1，大三角全在U2但非全在U0/U1，双箭头确指各自内部，中文β零/非零对应源。

两独编三页文字几何像素同1cb088ba，clean全嵌，双nativecrop再裁全同；六合法锚/11实际批准快照齐。旧319同，新7后326。非全节/全书/最终ZIP验收。
