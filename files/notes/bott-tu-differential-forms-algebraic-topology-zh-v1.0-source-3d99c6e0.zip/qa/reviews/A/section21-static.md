# Bott–Tu §21新driver独立静态核A

TECHNICAL_INPUT_ONLY。五无条件直接项为导语+四原native；22递归TeX/4图各一次共26闭包，25旧输入逐字同A74/75/76r1/77真批准快照。24合法锚End284/full285–295/Start296；19原ID21.1–19原序一次，21.2只原图内数学号配单TeXanchor，无重复tag；(*)一次。原目录物12本次重看，1section+4native完整。

无新宏/条件输入/aux，四公共core当前真批准同；新driver真实快照/技术账本第21项落盘，语义账本不变。无整节新PDF/冷编/像素导航宣称，最终全书实际ZIP仍另验。
