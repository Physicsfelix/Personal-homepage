$ErrorActionPreference = 'Stop'
Push-Location -LiteralPath (Join-Path $PSScriptRoot 'book')
try {
    & latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error '-outdir=build' main.tex
    if ($LASTEXITCODE -ne 0) { throw 'XeLaTeX build failed. Inspect book/build/main.log.' }
} finally {
    Pop-Location
}
