# 李思《统计力学中的数学方法讲义》中文重排译本 v1.0

原著：Si Li, Lectures on Mathematical Methods in Statistical Mechanics，更新于2026年6月。依据用户提供的134页完整PDF翻译。固定原件身份见qa/source/identity.json。

本源码包含封面、完整作者摘要、全局及各章目录、全部六章39节、原文证明与习题、图表，以及全部46条参考文献。正文使用用户泛函分析I模板的视觉复原样式；封面重新制作。原著中明确的问题保留原文，并以独立的“译校注”说明。原文未给出的证明和习题解答不作增补。

## 编译

安装带XeLaTeX、latexmk、CTeX、Fandol、Latin Modern的TeX Live（本版使用TeX Live 2026）。依赖包均在book/preamble.tex中声明。字体由TeX运行时提供，无需私有字体。

Windows：在本目录打开PowerShell，运行`./build.ps1`。也可进入book目录运行：

```
latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
```

输出为book/build/main.pdf。正式入口book/main.tex无条件包含全部章节，不能跳过缺失文件。压缩包不含旧辅助文件、预览入口或完整原书PDF。

## 审校记录

全部49个内容单元分别由非译者审校。当前源码哈希与审校记录的映射见qa/source-unit-map.json；逐单元报告位于qa/reviews。主作者为root，第一至三章及前后置由A审校，第四至六章由B审校。大字体图形的精简另经C逐像素独立复核。源页物理页码锚点保留在TeX注释中。

qa/compile-input-manifest.json列出全部111个编译输入的SHA-256，作为实际源码包冷重建的版本依据。完整PDF的目录、书签与引用均可点击。
