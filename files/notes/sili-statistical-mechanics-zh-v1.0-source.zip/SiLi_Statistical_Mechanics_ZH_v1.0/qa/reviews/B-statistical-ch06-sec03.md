# B独立源审：统计ch06-sec03

当前SHA `3d5dde4bc7dc6e3e8ed6d89b0ba00d760242b809752cf730ef0af13fa1649a51` 批准。原页121,122,123,124逐2x实际看，完整段式/原证明/表格/所有当前资产另2.5x实看，非只核root列点。

Original121: entirestrongcoupling/lowenergy/holes/virtualexchangeintro, globalGutzwillerP/projectedlocalbasis/bothprojectedfermionoperators, doubleoccupancyprose andHub=T+HU.

Original122: completeT/HU/PTP/half-filling-versus-holes/PHUP0, Qdefinition/invertHU/high-lowenergydecompositiondiagram; bothblockHamiltonian2x2matrices, Heffsource/target/spectrummatching andcompressedresolvent; everydiagramarrowandlabelretained.

Original123-124: entirez-dependentSchurcomplementtwoforms/inverseexpansion/O(t/U²)/fullsecondorderandone-doublonreduction; Proposition6.5wholeTi_jandidentity/fullproofemptysite/allfourtwoelectronstates/triplets/Pauliandcancellation/singlet4t²/Sdotcases; sourceeffectivepure-tJwithO(t³/U²)andJ4t²/U retainedwithaccuratethree-sitequalificationnote; entirehalf-fillingHeisenbergdiscussion/regiontable/holes-singletfigure. Source124tableactuallysaysfinitehopping, retainedas有限跃迁, notsilentlyreinterpretedasdoping.

译校注独核：Bfreshsix-orbitalCAR/Fockcomputation(notauthorcode): on3-sitechain withorder1up,1down,2up,2down,3up,3down, initialbit9=|up,down,0>,finalbit36=|0,up,down>. Onlyvirtualdoublonpathvia2up2down contributesPTQTP=t², whereaspuredisplayedtJdirectmatrixelementzero. Henceeffectivecrossbondterm -t²/U existsatsecondorderoffhalf-filling, notO(t³/U²); atstricthalf-fillingnoholeacceptorandthesehoppingsvanish. Existingreader-noteaccurate.

数学独核：Analytictriplet/singleteigenvaluesplusfreshcomplete16D2-siteFockmatrix: P T Q T P +4t²P(Sdot-¼ninj)P identicallyzero(maxerror0att1).

没有添加作者未给的证明或练习答案。当前无待改点；整书PDF排版/导航另验。
