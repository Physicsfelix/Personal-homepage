# B独立源审：统计5.6

当前SHA `4a533157c999cd86e086aaa765c1f0ccddf23aff16f68bba36b2906d4212909b` 通过，原108–109实际2x读，全部段式与原位置态图（当前asset另独立2x渲染）均核。

Original108: sectiontitle/referenceallplusstate, exactpositionketgraphicwithminusatx/arrow/positiontranslated, fulloneparticleNsum/translationplanewave/periodicitycondition, crossingpageoneparticleBetheequationconclusion.

Original109: orderedm-spinpositions, fulltwo-permutationamplitudes/exponentsandproseexplainingeachterm/exchangedmomenta, wholestateandSrelation, completeSratioandk-lambdaratio/Delta; generalMfullorderedstatesum/M!permutationwavefunction/everyj-product, adjacentexchangeamplitudes/factorizationYBE, periodiconce-aroundargument/scattereverymagnon/product/wholefinalBetheequation.

原a(u)/b(u)与λ式的记号混用短注独立正确；按定义配对应在此取u=λ。原式与所有散射/周期条件不改。未发现漏项或待修点，正式PDF另验。
