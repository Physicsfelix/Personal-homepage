# B独立源审：统计ch05-sec02

当前SHA `9220eb03fdd0b9127687b72729cb6416f7498c8a1b1e37f0b8a35ced42bf550a` 批准；原件 `cedf2aff4f1cbfdf150302aad21e72d5aa23ed22f2ba3b44abb7e76f1ec77209`。实际原页94,95,96逐2x读，全文/每式/全证明与所有当前资产另独立渲染后实看。

Allverticalarrowrow/spinvaluesandsixarrowexample, transferTindex/up/downRcomponentsandcyclichN+1h1diagram; entirelocalweightandRinput-outputindexdiagram.

OriginalZ=TrT^M/freeenergywithmissing1Npreservedplusaccuratenote; allRendomorphism/bra-ketcomponents/orderedbasis/plusminussymbolarrows, full4x4R andspectralparameterR(u)matrix.

原95遗漏1/N注独立核成立：logTrT_N^M除以MN后给N^{-1}logLambda_N；把每顶点权重乘κ，T_N乘κ^N亦独立证实归一化必须存在。作者原式保留。

当前无待改项。局部目录页值/全PDF导航及排版另验。
