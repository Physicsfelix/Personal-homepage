# B独立源审：统计ch04-sec06

状态：content_approved_source_anchor_correction_pending。当前SHA `3d49472d1b3379fc6da1c1a1935d9008340d1f95f45c072f55f78d804b860423`，原件SHA `cedf2aff4f1cbfdf150302aad21e72d5aa23ed22f2ba3b44abb7e76f1ec77209`。

实际逐幅读原页 58,59,60,61；逐段、逐式及当前矢量图全部对照。完整检查项目、源锚和图片身份见同名JSON。未借作者的原页阅读记录替代本次独立阅读，未签最终PDF。

High-temperature expansion: spin pair identity, both lattice products, even-spin criterion, entire closed-bond example including |Gamma_h|=16 and |Gamma_v|=14, spin-sum prefactor2^(MN), all weights and counts compared against visible58.

Low-temperature expansion: dual-lattice black/white solid/dashed geometry and two-way dual arrow; two ordered-spin patterns; ground-state weight; D and D_h/D_v; every plus/minus vertex and red/blue bond; swapped primal/dual horizontal/vertical identities; all dual-wall colors and English translations; every energy and partition sum at59-60 compared.

ReducedZ definition, psi negative1/beta limit, relation with fullZ, full dual-coupling and symmetric-sinh equalities, both temperature bullets, unique-critical-point statement, anisotropic critical locus, isotropic Tc expression compared with pages60-61.

No original numbered objects, footnotes, exercise questions or further text omitted in these section boundaries.

原有限环面低温公式保留。独立核：D=δs是精确Z2一上链，域壁总同调零；连通晶格上同一D恰有整体翻转两解。因此既需零总同调限制，也需因子2。3×3环面18边9顶点的全部偶子图维数10而精确D维数8，亦独立证实此差别。现有短注正确。

唯一待修是0080–0094注释应定位原60，非59；正文与数学无须改。


定点注释差分已独立批准：实际旧稿SHA 3d49472d1b3379fc6da1c1a1935d9008340d1f95f45c072f55f78d804b860423；当前SHA dbe728a135aeb0da1c78dc9b64f28a439c2cc905813cddfaae8e94bdee0a8104。独立构造预期的15次59→60字节替换后与实际新稿严格全字节相同。没有正文/公式/图或空行变化。原先源审全部承接，待修关闭，当前身份approved。
