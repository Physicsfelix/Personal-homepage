# B独立源审：统计4.8

当前身份通过：`6341b3dfc03288e128e509fee8886b633cb14c8744b2ffca27a3a3e430dcbe6f`，原件 `cedf2aff4f1cbfdf150302aad21e72d5aa23ed22f2ba3b44abb7e76f1ec77209`。

实际原71–80共10页逐幅2x读，与当前全部译文、原510锚、原命题4.3全证/推论4.4及全部未编号计算逐式比较。磁化曲线asset另独立渲染2x实看。没有按root给出的三点清单代替全节阅读。

原71,72页：Everymagnetization definition/orderoflimits/boundary symmetry statement; originalOnsagerCornell1948/Florence1949 history; completepiecewisem1/8formula; originalvectorcurve; Yang1952 citation46/Montroll-Potts-Ward34 and equivalence citations4,25; exact distinction of twom definitions; originalentire transfermatrix/correlation sums, Phi factors, symmetrictilde conjugation andcommutation.

原73,74页：Spinchain telescoping andi^r trace; Proposition4.3 Wickforfermions with allGrassmann/Clifford indices, normalization andbothC cases; fullnormalform7rowmatrix andproof; Corollary4.4 allindexordering/Tr/Pf/A entries; A/B periodicidentifications, originalPhi ratherthantilde inp74trace preserved; bothsymmetryitems, transposition/Clifford calculations, Gdefinition, originalblock-G/extra sign, originalToeplitzindex; all3existingnotes independentlyproved.

原75,76页：LargestOmega eigenvector andMlimit; allFourierphase/mixedsourcecplus/cdagger signs;bothcanonicalrelations; completePhih/Phivquadraticmodefactorization; adjointmatrices andsix Mthetafactorizations; originalp75bottomtopright-i eachinstance confirmedvisually; Mtheta traceplus(a,ib;-ib,-a), all-a/-b/coshgamma, left-eigenvectornormalization withbars, eta definitions andHermitianadjoint/eigenspace identities, pairedtheta-conjugacycases, anticommutator anddominant-vacuumcondition.

原77,78页：Wholei<B0An>Fouriersum, gdefinition andintegral limit; bothprojection formulas andallbars on u/v; leftmatrixequation, xi ratio, fourmodulus/bilinear identities; everyphase-chain equality andz=-a-ib includingbarz; zfactorization/roots/twosalphadefinitions; bothg phasesquare-root formulas; originalk-jGintegral andphi symbol; T<Tc alpha bounds andToeplitz/logpsi intro.

原79,80页：AllFourierdefinitions/Szegoasymptotic/c0/cn/c-minusn signs; entirefour-stepinfinite-sumlogcalculation; rootdetG/m exponent1/8; allsubstitutionand4-stepmagnetizationidentity; finalformula andk/ascendingT asymptotic/criticalexponent through4.9titleboundary. Noomittedproofstep/unlabelledparagraph, originalfootnote,exerciseorgroupedsubquestion found.

三注独立核：Q块矩阵是系数阵而非Clifford算子；反对称块左下应为−G转置；交错→分块与块Pfaffian各给同一个(−1)^{r(r−1)/2}因子，故相消，自旋i^r并入det(iD)=detG，r=2直接Wick展开也证实。平移BkA_{j+1}得到B0A_{j−k+1}，原反方向约定给转置，行列式同。原公式均保留，现有注准确。

未发现待改项，批准当前精确身份。末轮PDF版式/链接另验。
