# B独立源审：统计ch06-sec02

当前SHA `499c12068afda98b7de927c0d6a5a35b2066e0192fd2771e40d4e948d2731425` 批准，原页120,121实际逐2x读，全部段/式/原对象/表和图逐源核。

EntireatomicHwithminusmu/t0; all3tablecolumns/3stateclasses/0,1,2countsand0,-mu,U-2muenergies fullytranslatedasactualtable.

Definition6.4Lsites/N=L/averageonespin; half-fillingmuU2with6.5reference/allthreeenergies/positiveUgroundmanifoldeveryonesite/electronschargefrozen/spinfree; wholeelementarydoublonchargeexcitation/orderU/bandtheorycontrast/Mottmechanism through6.3boundary.

未发现漏项/待修；最终PDF另验。
