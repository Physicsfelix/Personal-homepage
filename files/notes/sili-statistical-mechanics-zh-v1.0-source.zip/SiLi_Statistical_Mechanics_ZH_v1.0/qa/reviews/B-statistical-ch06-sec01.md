# B独立源审：统计ch06-sec01

当前SHA `7983f239f2447a78255df40b1e7dde13d6370437683fa25cd52755212c51a5bd` 批准，原页119,120实际逐2x读，全部段/式/原对象/表和图逐源核。

Wholecanonicalfermionanticommutators/deltas/sigmaprimes; allfourlocalbasisvectorsandcreationorderofdoubleoccupation, wholeHilberttensor/product/numberoperatorsandprose; Definition6.1allfinitegraph/unorderededges/t/U/muHamiltonianand2signcases.

TotalNformula/conservationandspinPauli-bilineardefinition; sourceincorrecti/2commutatorpreservedplusaccuratenote; totalspinandsamereations; Proposition6.2allthreeSU2commutatorsretainedwithoutinventingproof.

Example6.3fulltwo-sites/two-electrons/mu0/all3tripletsandnormalizedsinglet/Dplusmixing, whole2x2matrix/eigenvalue/asymptotic/signandantiferromagneticconclusion. Everyoriginalu lowercase kept, notsilentlychangedtoU.

自旋短注独算正确：CAR双线性括号等于矩阵括号，Pauli/2得iεS，并非源iεS/2。原式与u小写保留。

未发现漏项/待修；最终PDF另验。
