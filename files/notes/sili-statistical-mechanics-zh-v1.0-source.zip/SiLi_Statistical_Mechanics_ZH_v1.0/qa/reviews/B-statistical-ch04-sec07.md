# B独立源审：统计4.7

当前身份通过：`175508f2b6344e76968d60cd4a1043322e87af21bd12235388a59c58ae0e0c4f`。原件 `cedf2aff4f1cbfdf150302aad21e72d5aa23ed22f2ba3b44abb7e76f1ec77209`。

实际逐幅读原62–71共10页2x图，对全部1042行现稿逐段逐式核对，两矢量图独立渲染2x后实际比较。全部原499源锚、引理4.1及全证明、命题4.2及全证明、Fourier/伴随所有中间矩阵和椭圆积分/比热末段完整。没有只核作者列出的疑点。

原62,63页：Complete transfer-matrix Hilbert tensor basis, all original mu/T/Th/Tv matrix entries and exponent indices, partition trace, factorization, Pauli matrices, extension to sites, Av determinant and hyperbolic exponential; every paragraph and display compared.

原64页：DualKv relation, both exponentialT factors and prefactor, all JordanWigner products, Clifford relation, paired spin identities, cyclicGamma wording, complete BCH quadraticA and Phih/Phiv/Phi definitions; paritynote independentlyproved.

原65,66页：Lemma4.1 and Proposition4.2 with completeproofs: commutator-antibracket identity, Y/action/e^-C, whole skew-blockmatrix, tildeGammas, ladderoperators plus/minus signs and anticommutation, vacuum and allbinary basis states, half shifts, both vacuum maps, product eigenvalues and proof endings. No steps compressed away.

原67页：Alladjoint-action domains, original compositionorder, site2x2 matrices, Fourier definitions andphase signs, three2x2 modeactions, Bq underbrace including original reversed basis-matrixorder preserved exactly.

原68,69页：All gamma trace/cosh dispersion, original wrong spectrum sentenceplusaccurate note, largest-eigenvalue product, thermodynamiclimit, bothgamma integrals, arcosh formula, dual sinh/cosh, Ch/Sh/Cv/Sv definitions, double-integral transformations and cancellations, final Onsagerformula, positive-square criticalcondition, isotropic tau rewrite andvariable substitution compared.

原70,71页：Both original domain-diagram panels/hatchings/coordinates/pi/arrow, allintegral changes andbeta integration identity, twoellipticfreeenergyforms, complete internalenergy3-step display, criticaltau equivalence, asymptotic logarithm16 andnearTc powers, allpage71continuity/specificheat/logdivergence/secondorder conclusions through4.8headingboundary.

两原误注独立核准：由XZ=−iY直接得iΓ₂NΓ₁=−Q Z_N Z_1，故周期自旋链须分Q宇称扇区。Bq行列式1、迹2coshγ的特征方程给e^{±γ}，并非±γ；原文两处均保留且注准确。

当前正文无修订请求。最终排版与导航不由此报告批准。
