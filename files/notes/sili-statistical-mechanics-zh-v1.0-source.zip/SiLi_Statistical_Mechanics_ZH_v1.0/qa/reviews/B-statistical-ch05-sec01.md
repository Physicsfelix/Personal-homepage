# B独立源审：统计ch05-sec01

当前SHA `0a52f91ce8c7f3323fa06797325fc456e39c150f588d3f33511eea2f8382fd8b` 批准；原件 `cedf2aff4f1cbfdf150302aad21e72d5aa23ed22f2ba3b44abb7e76f1ec77209`。实际原页93,94逐2x读，全文/每式/全证明与所有当前资产另独立渲染后实看。

Originalsixvertexdefinition/edgearrows/entireboxedice2in2outrule, allsixlocalconfigurationsandweightsa/b/cwiththreepairs.

Allno-fieldarrowreversaldiscussionandgeneralsixweights, globalC/regionLambda/statisticalproductWandfullpartitionfunction, periodicMxN countsNa/Nb/Nc, persitefreeenergylimitandclosingachievementparagraph.

当前无待改项。局部目录页值/全PDF导航及排版另验。
