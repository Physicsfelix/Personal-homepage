# B独立源审：统计ch04-sec05

状态：approved。当前SHA `8d609414e160228e64073d5d0b2ba67ea8a251a7dd134e338801c7e290cb7a5b`，原件SHA `cedf2aff4f1cbfdf150302aad21e72d5aa23ed22f2ba3b44abb7e76f1ec77209`。

实际逐幅读原页 57；逐段、逐式及当前矢量图全部对照。完整检查项目、源锚和图片身份见同名JSON。未借作者的原页阅读记录替代本次独立阅读，未签最终PDF。

All anisotropic periodic2D model declarations, two periodic identifications, Hamiltonian horizontal/vertical summands, partition-function exponent, K definitions, free-energy limit, Onsager citation36 and entire double-integral formula independently compared with original visible page57.

Square-lattice asset all grid lines/dots and M horizontal,N vertical labels retained.
