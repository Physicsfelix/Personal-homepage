# B独立源审：统计ch06-intro

当前SHA `0aa5bfac531168e371f43dc4db83d0745c27e86672bd4038715bcc278a472a2f` 批准，原页118实际逐2x读，全部段/式/原对象/表和图逐源核。

All5originallocalContentsitemsandchapterheading; entireclassicalmodelscontrast/Hubbardhistorynamedthreeauthors/1960s, basicHamiltonianallfermiondaggersandnearest-neighborhopping, t/U/numberdefinitions/spinset; all4importancebullets, fullmechanismequalityanddelocalization/repulsionprose; original2-panelhopping/onsitediagramwithallEnglishtranslated/3t arrowsandspinupdownspring preserved.

未发现漏项/待修；最终PDF另验。
