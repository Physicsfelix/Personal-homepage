# Statistical ch04-intro independent source review

Approved by nonauthorB at exactcurrentSHA `3106b0d6d4ea5c85ba213bbaf693d04c49755e324948470c4f259ecfbea4e9ab`. Everyactualoriginalpage[50] was read individually at2x against all translated paragraphs, mathematicaldisplays, intermediate steps and any originaldiagram.

ExactUTF8snapshot, sourcescope, figurechecks and notes are bound inJSON. FulltranslatedPDF layout, localcontents pagevalues/navigation and coldcompilation are separate stages.
