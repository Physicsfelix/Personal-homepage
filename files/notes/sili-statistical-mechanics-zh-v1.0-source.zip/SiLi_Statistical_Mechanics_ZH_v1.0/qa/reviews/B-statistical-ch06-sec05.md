# B独立源审：统计ch06-sec05

当前SHA `64c70c6fbf6a87ccb5d7011401f339aba14a5de41ba1ed4cef00ae40b61ab7cc` 批准。原页126,127,128,129,130逐2x实际看，完整段式/原证明/表格/所有当前资产另2.5x实看，非只核root列点。

Original126-127: fullgeneralmeanfieldintro/A,Bfluctuationexpansion/all4terms/neglectquadratic/selfconsistencyrequirement, completeHubbardHamiltonian/number/quarticdensity/initialrho_up,down andHartreeapproximation/HMF; everycharge/magnetizationrelation/twostepdensityexpansion/Szformandsitefield; bipartiteintroanddiagram.

Original128: entirestaggeredm2cases/Qvector/particle-holebijection/holesmeaning/bipartitephase/numbertransform/interactionandmu/hoppingtransformations/muU2criterion; completeHMFtwoformswithallconstanttermsasprinted, correctsource-constantnote.

Original129: bothFouriercreatorandannihilatorfactors/dispersion/hoppingandstaggeredcoupling3equalities, fullHMF/Delta, bothBZbounds/RBZidentification/row-column2x2block/constants, epskQ=-epsk/eigenvalueformula andallgap/occupiedlower-emptyupperprose.

Original130: originalgapbandsfigure, orderparameterrealandmomentumsumwithoutsidesigma, 2x2matrix/crosscorrelator/Fermifunction/T0limit, originalremaining-sigmaequalitypreservedandnotecorrect; nonzeromcancellation/wholeRBZgap-equationandBCSparticle-hole-versus-particle-particleclosingcomparison. Allsourceformulasandproseincludedthroughlastmainpage130.

译校注独核：At rho_i1andmuU2 densitytermU/2*n_i cancelschemicalterm, leaving -U/2 sum m_i(nup-ndown) -NU/4+U/4sum m_i². Forstaggeredm±m thisisconst-NU/4+NUm²/4. Originalequalitydropsfirstm-independentconstant. Existingnoteexact.

译校注独核：Orderparametercontainsouterspinlabelsigma=±1. Crosscorrelatorfrom2x2h=[[eps,-sigmaDelta],[-sigmaDelta,-eps]] haslowerbandprojectoroffdiag+sigmaDelta/(2E). Aftermultiplyingouterσ,σ²=1; foldingfullBZtoRBZ gives m=N^-1sum_RBZ,sigma Delta/E=2Delta/Nsum1/E. PrintednumeratorsigmaDeltawouldsumzero. Existingnoteaccurateandpreservesoriginalformula.

数学独核：h²=(eps²+Delta²)I; occupiedlowerprojector(I-h/E)/2 givescrossentrysigmaDelta/(2E), finiteTtimesf(-E)-f(E). CombinedDelta=Um/2 yieldsdisplayednonzeromgap1=U/Nsum_RBZ1/E. Positiveparticle-holetransformationnumberandconstanttermsindependentlyexpanded.

没有添加作者未给的证明或练习答案。当前无待改点；整书PDF排版/导航另验。
