param(
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'build')
)
$ErrorActionPreference = 'Stop'
$OutputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
[void][System.IO.Directory]::CreateDirectory($OutputDirectory)
$bookDirectory = Join-Path $PSScriptRoot 'book'
$latexmkCommand = Get-Command latexmk -ErrorAction SilentlyContinue
$xelatexCommand = Get-Command xelatex -ErrorAction SilentlyContinue
if (-not $xelatexCommand) {
    throw 'XeLaTeX was not found. Install a TeX Live distribution with Chinese and mathematics packages, then run this script again.'
}
Push-Location -LiteralPath $bookDirectory
try {
    if ($latexmkCommand) {
        & $latexmkCommand.Source '-xelatex' '-interaction=nonstopmode' '-halt-on-error' '-file-line-error' '-recorder' "-outdir=$OutputDirectory" 'main.tex'
        if ($LASTEXITCODE -ne 0) { throw "LaTeX build failed with exit code $LASTEXITCODE." }
    } else {
        $previousState = ''
        $stable = $false
        for ($pass = 1; $pass -le 6; $pass++) {
            & $xelatexCommand.Source '-interaction=nonstopmode' '-halt-on-error' '-file-line-error' '-recorder' "-output-directory=$OutputDirectory" 'main.tex'
            if ($LASTEXITCODE -ne 0) { throw "XeLaTeX pass $pass failed with exit code $LASTEXITCODE." }
            $state = (@('main.aux','main.toc','main.out') | ForEach-Object {
                $stateFile = Join-Path $OutputDirectory $_
                if (Test-Path -LiteralPath $stateFile) { (Get-FileHash -LiteralPath $stateFile -Algorithm SHA256).Hash } else { '-' }
            }) -join ':'
            if (($pass -ge 2) -and ($state -eq $previousState)) { $stable = $true; break }
            $previousState = $state
        }
        if (-not $stable) { throw 'Auxiliary files did not stabilise in six passes. Inspect the log before accepting the PDF.' }
    }
    $pdfPath = Join-Path $OutputDirectory 'main.pdf'
    if (-not (Test-Path -LiteralPath $pdfPath)) { throw 'The build did not produce main.pdf.' }
    Write-Output "PDF: $pdfPath"
} finally {
    Pop-Location
}
