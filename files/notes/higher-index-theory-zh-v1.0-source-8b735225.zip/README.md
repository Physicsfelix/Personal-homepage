# 高阶指标理论：中文译排源码

原著：Rufus Willett、Guoliang Yu，*Higher Index Theory*，Cambridge University Press，2020。译排以用户提供的597页原始PDF为依据。原件SHA-256为 `7b901e5ee458369ccf89da63b5a0b0b5e8aeb210d70cbd28a71f9ed473c839de`。

本工程完整收录原书前置材料、十三章正文、五篇附录、证明、习题及原有提示、插图、参考文献、符号索引和正文索引，并保留原编号。正文依据用户提供的“泛函分析I”模板作视觉复原，使用中文字体、分色陈述框和原编号数学环境。原文中需要辨析的记号、条件或论证以单独的“译校注”说明。

## 编译

验收使用TeX Live 2026中的XeLaTeX及latexmk。中文采用TeX Live附带的Fandol字体，西文采用Latin Modern。需要安装ctex、TikZ/tikz-cd、tcolorbox、hyperref、zref及通常的数学宏包。

在源码包根目录用PowerShell运行：

```powershell
./build.ps1
```

也可以从其他目录通过脚本的完整路径调用。默认输出为源码包中的 `build/main.pdf`；脚本会按需要重复编译目录、页码和链接。使用 `-OutputDirectory` 可以指定其他输出目录。

手动编译时进入 `book` 目录运行：

```text
latexmk -norc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=../build main.tex
```

## 文件与页码

- `book/main.tex`：整书入口，按原书顺序明确载入所有章节和前后置材料。
- `book/chapters`、`book/appendices`、`book/matter`：正文、附录和前后置材料。
- `book/figures`：实际使用的全部原生数学插图。
- `book/style`：依照指定模板重建的版式。
- `qa/compile-inputs.json`：实际编译输入的文件身份清单。
- `qa/current-accepted-inputs.json`：各实际输入的独立审校或技术验收记录。
- `qa/source-page-map.json`：原始物理页与译本首末页及内部跳转位置的对应。
- `qa/reviews`：随包提供的可移植审校记录；原文语义、版面导航及源码包重建各有明确范围。

译本的分页不同于原书。目录显示实际译页；符号索引和正文索引中的原页引用会自动转换为相应的译页或译页区间，并附内部链接。前置材料采用罗马页码，从引言起采用阿拉伯页码。原书的空白叶和重复献词均有各自的来源对应。

所有编译输入及图片均在本包中，编译无需原始教材PDF或原工作目录。源码包内的审校记录保留原文件哈希、结论和数学内容，并将本机私人路径转换为相对路径或出处说明。最终ZIP的独立冷重建回执及发布信息另载于交付记录，避免在压缩包内部自引用其最终哈希。
