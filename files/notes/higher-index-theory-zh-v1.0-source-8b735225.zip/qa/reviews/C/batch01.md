# main03 当前身份继承（非新数学审校）

A实际整书导航/37marker正式批准已读并独立核所涉raw/EOL。当前单位/组件身份已更新；原whole-native数学批准承接。旧局部preview、FLS和正文图检仍是旧SHA历史证据，当前位置门由实际M3 `f8d7d351288340bd540ee91ca249d13c54b71db9516f10f9a15c6bce9a2a6398` 与A `main03-binding-review.json`承担。旧原报告/ledger/真实旧快照全部保留于 `[project]\qa\reviews\C\revisions\main02-before-C15-main03-identity-refresh`。

本报告当前变文件：

- book/matter/introduction.tex → `f63513d4006357c4dafefc017b9683962a02671175285af2687c575ca4599be3`
- book/chapters/ch01-sec01.tex → `fec19043658378d709a129a80994d0e6fd58da251566db627fea801a115cb773`

---

以下为原whole-native审校叙述；其中旧preview与旧检查列表均按其原审校时点读取。

# Higher Index Theory：batch01 独立审校 C

**批准当前字节版本：approved。作者B，独立审者C。**

来源SHA256：`7b901e5ee458369ccf89da63b5a0b0b5e8aeb210d70cbd28a71f9ed473c839de`，原件597物理页。本批实际独立逐页看原图：16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30。原页分别以1.8倍渲染并逐页查看；没有用OCR或作者摘要代替公式审读。

## 逐单元状态

|单元|来源物理页|状态|译稿SHA256|
|---|---|---|---|
|introduction|16,17,18|approved|`77931fa6182bbfd0cf188f2c3f5a71b2970535435f02ebb9c01151cd2f3b339b`|
|part01|19,20,21|approved|`8b6d0e14047456fd01aef74e3eba71b27807f8d085ef8da3fe7fafad2ca0ecf4`|
|ch01-intro|22,23|approved|`4dbad89f367acc71f453d901108543de7eb7c3ae12aab992ca196c4977549713`|
|ch01-sec01|23,24,25,26,27,28,29,30|approved|`ca2607dbdac34ab716cac05cb0ac9d6c1c5e0a7eab035c0e1e5a18391ef20364`|

每份译稿当前SHA、原件SHA、首末对象、作者/审者身份及真实批准字节快照均在同名JSON中绑定。批准字节已实际复制到qa/approved-bytes/C/<sha>/book/...并复算校验，不是仅登记一个approved字符串。

## 完整性与假设核验

引言所有段落、四部分结构、先修/读者说明及全部致谢姓名、资助说明均逐段对应；proofs在最后一句译为校样工作，符合出版语境。物19/21确为可见空白页，物20为PART ONE/Background，译稿以独立空白叶和完整部分标题保持对应。第1章导语完整止于1.1之前。

1.1的13个对象1.1.1–1.1.13齐全，21个无号显示组逐式核验；定义1.1.11的11子项、注1.1.2的3子项、两条部分等距等式、任意epsilon/有限F的量词、群代数卷积的g^{-1}k次序和原脚注1全部保留。引理1.1.10的完整证明已实际逐段检查，未以对象数量代替语义核验。

三符号宏Cstar、Bop、Kop只提供原记号的排印，未覆写原语或改变约定。

先检查原书全局约定：物24零代数在使陈述显然失败时不纳入；注1.1.2规定有单位元Banach代数的单位范数为1。非空谱定理未因此被误报“漏非零假设”。同时，原书明确允许一般复代数及更一般语境，不能把所有“复代数”自动当成Banach代数。非有单位元情形的逆元与谱按单位化理解；此为原定义的上下文，不是擅增全局有单位元假设。

## 译校注的独立数学核验

### hi-lemma-1.1.10-source-note

- **visible_source**：An extra right norm bar appears after||(a,0)||. The final upper expression visibly uses aa*+lambda+bar(lambda)+|lambda|^2, whereas the preceding x*x polynomial is a*a+lambda a*+bar(lambda)a+|lambda|^2. Both are retained exactly in the translation; the translator note accurately identifies the difference.
- **independent_counterexample**：Take the nonzero nonunital C*algebra A=c0(N), a=2e1 and lambda=1. In the unitization x=(a,1) is the convergent sequence(3,1,1,...), so||x||^2=9 and||x*x||=9. The printed upper polynomial is(7,3,3,...), whose left-multiplication norm on c0 is7, attained at b=e1. Thus the printed bound would require9<=7; the difference is mathematically material, not merely typography. This example meets the actual nonunital-C*assumptions.
- **correct_reasoning_for_check**：For q=x*x=(a*a+lambda a*+bar(lambda)a,|lambda|^2), the preceding correct expansion gives||x||^2=sup||b*q b||<=sup||q b||=||q||, using||b*||<=1 in A. Submultiplicativity then gives||x||^2<=||x*x||<=||x*||||x||. For nonzero x, divide by||x||; apply the same argument to x* to obtain star-isometry and hence the reverse bound. This verifies the underlying corrected argument without circularly assuming the C*identity on A+. The authored note does not silently install this correction.
- **other_proof_steps_checked**：For nondegeneracy, left identity u=-a/lambda and right identity v=-a*/bar(lambda) satisfy uv=v and uv=u, so u=v is a genuine identity, contradiction. Finite-codimension completeness applies after the norm and complete isometric A-subspace are established.

上述核验均在满足原书实际假设的模型中进行；没有仅凭“字形不同/源式有疑”就机械批准。原式按合同保留，译校注明确分层。批准忠实译稿与注释，不给原错公式的真值背书。

## 版面、重编与源页接口

作者预览11页全部实际逐页查看。独立在全新C输出目录两遍XeLaTeX成功；与已看作者PDF逐页几何、提取文本、1.5倍渲染像素全部相同，证据见independent-preview-rebuilds.json。字体均嵌入；未见裁切、重叠、缺字或脚注/子项丢失。源语义批准与这一预览版面检查分开记录。

脚注呼号1/2与注体原意及位置均核对；原件对应页和译稿均无脚注PDF链接动作，未把不存在的链接目标称作导航通过。

跨单元共享源页23、30的Start/End分别位于正确文件且各一次；全部已交文件合计Start16–35各一次、End16–34各一次。End35属于未来1.3的真实页尾，当前不算遗漏。

当前无未闭阻断项，各单元批准有效；若这些文件字节修改，需要受影响范围的独立差分复查。全书合编/最终导航/实际源码包冷重建与发布仍是独立后续门槛。
