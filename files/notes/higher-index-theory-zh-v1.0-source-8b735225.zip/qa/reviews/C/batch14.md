# main03 当前身份继承（非新数学审校）

A实际整书导航/37marker正式批准已读并独立核所涉raw/EOL。当前单位/组件身份已更新；原whole-native数学批准承接。旧局部preview、FLS和正文图检仍是旧SHA历史证据，当前位置门由实际M3 `f8d7d351288340bd540ee91ca249d13c54b71db9516f10f9a15c6bce9a2a6398` 与A `main03-binding-review.json`承担。旧原报告/ledger/真实旧快照全部保留于 `[project]\qa\reviews\C\revisions\main02-before-C15-main03-identity-refresh`。

本报告当前变文件：

- book/chapters/ch02-sec06.tex → `85646efdb39adfbea910242a815637450d804f02b08ad0a9460c85f80f677579`

---

以下为原whole-native审校叙述；其中旧preview与旧检查列表均按其原审校时点读取。

# Higher Index batch14 独立审校 C

状态：完整 §2.6 当前原字节 approved；作者 B，非作者审者 C。

实际逐页看原107题头至111完整注2.6.8及2.12引用、2.7前；112只核后文适用范围。八对象、式2.13、20无号显示组（含三完整正合图）、脚注10、两原陈述结束方框及全部普通段落齐。Bott定理保留本节黑箱身份，未补未印证明。

## 数学与三条译校注独核

- 2.6.1 cone extension and contraction：CA functions extend continuously by f(0)=0. Evaluation at1 is surjective by the lift x->xa; its kernel is precisely SA. ht f(x)=f(tx) preserves products and has norm<=1. Uniform continuity on the compact interval gives pointnorm continuity in t including0, where h0=0, while h1=Id. Homotopy invariance and the complete six-group sequence therefore give the isomorphism Ind:K1A->K0SA with the displayed orientation. Both supremum norms and Cstar statements retained.
- 2.6.2 higher groups, exactness and index-shift annotation：Applying previous2.5.8 to Sn gives K1(SnX)=K0(Sn+1X)=Kn+1X followed by K0(SnX)=KnX. Thus the printed fixed-n Sn instruction and Kn-to-Kn-1 diagram differ by one index. The separate note accurately permits Sn-1 or a relabelling, without declaring the resulting Puppe sequence false. S preserves quotient-surjectivity: use the open mapping uniform bound for pointwise lifts, continuous finite partition approximations to the quotient-valued function, and an iterative geometrically summable correction series, also vanishing at endpoints. No bounded linear right inverse is assumed. Entrywise application preserves homotopies and kernels. Full long sequence ends at K0Q on the right and extends left; no spurious terminal zero or extra proof added.
- 2.6.3 and transition with footnote10：Every arrow, Ind_n label, naturality phrase and statement-end square matches actual source109. The warning that formal need not mean easy is retained as footnote10. The source supplies no formal proof here and promises Bott proof9.3, so the translation correctly keeps these statements without inventing a proof.
- Bott loop matrix layer, letter and unitization：Source109 visibly prints beta(e) in scalar (SA)+ and zp+(1-e), with p undefined in this passage, then calls it an invertible matrix. For the given matrix idempotent e the intended loop ze+(I-e) multiplies z^-1e+(I-e) in either order to I, using e(I-e)=0=(I-e)e. Its value at1 is I, so it belongs to Mn((SA)+); it need not be scalar. Both printed discrepancies are retained, with a mathematically correct separate clarification. For unital maps loop/blocksum construction is natural; for general A use the unitization extension and scalar-kernel definition of K0. No unitality assumption is retroactively placed on general Banach algebras.
- 2.6.4-6 Bott theorem, six-term diagram and graded functor：The canonical K1(SA)=K2A identification has the correct direction. The theorem remains the source blackbox, with its promised9.3 proof. Periodicity and the long exact sequence yield top K0I->K0A->K0Q; right boundary Ind2 betaQ goes down to K1I; bottom arrows run K1I->K1A->K1Q; left Ind goes up to K0I. All six groups, three diagram layouts and labels, and both original statement-end squares are retained. GA morphisms preserve the two fixed graded summands, as printed; Kstar is covariant for continuous algebra homomorphisms.
- 2.6.7 contravariance context：The source explicitly invokes LC of B.1.1 and theorem1.3.14, whose pointed one-point-compactification morphism convention was already independently checked in approved1.3.14. Read this with that convention; do not silently replace it by arbitrary ordinary X->Y maps or use the zero algebra homomorphism as a purported counterexample. Upper indices and C0(X) are preserved.
- 2.6.8 quotient representative, general Banach scope and selfadjointness：The source111 literally prints e in Mn(A) representing K0(Q); the quotient representative being lifted must instead be in Mn(Q). This section remains general Banach algebras, and source112 only afterward restricts subsequent work typically to Cstar algebras; no earlier involution hypothesis covers the present paragraph. Even for Cstar algebras an arbitrary idempotent need not be selfadjoint: for the identity quotient of M2C, E=[[1,1],[0,0]] has E^2=E but E*=E is false, so it cannot be an image of a selfadjoint lift. Projection representatives can be chosen in the Cstar case, and for a projection q(b)=e, (b+b*)/2 lifts e selfadjointly. General Banach exponential construction itself needs no involution or selfadjointness. The note states these distinctions and does not deny the theorem.
- 2.6.8 exponential series, unitization, sign and nonunital counterexample：For idempotent e, e^k=e for k>=1, so the norm-convergent entire series yields exp(2pi i e)=I. Applying the bounded quotient to exp(2pi i a) therefore gives I; the lift lies in the appropriate unitized-kernel matrix layer and has inverse exp(-2pi i a). The printed negative K1-class sign is retained, with no change of boundary convention. In the nonunital identity quotient A=Q=C0((0,1)), scalar1 in Q+ has no lift from A: all images there have zero scalar component. It does lift in A+. Thus the separated unitization qualification is valid. The scalar idempotent1n in MmC means diag(In,0), all formal differences and the final2.12 reference are present. No exercise solutions or extra theorem proof were inserted.

四当前译页全实际看；独立两遍重编均0，四页几何/文字/1.5倍像素全等作者当前PDF，20字体全部嵌入，无缺字/溢出/underfull/未定义。三图箭头、方框、脚注与长末注可读；八本批源目标解析有效，共享107前首与111后末分别留相邻单元。

旧19语义单元及四part/两辅助共25真实批准快照递归冻结；旧章1技术输入全部真快照相同。审者未改作者正文；新真实批准字节快照已落盘。
译稿 SHA `a069b30f919c624f08edac3869da972b210504eca4d0e13a55c9bb3469638e62`；当前 PDF SHA `ef19244abe4b1739d2075097d6cb9ab6db18225c67a0adc248e73507bac3187f`。C账本现20语义单元。
