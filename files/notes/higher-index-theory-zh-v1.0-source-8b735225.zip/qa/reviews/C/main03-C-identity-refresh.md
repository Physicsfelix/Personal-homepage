# C main03 当前批准身份继承

实际读A正式批准报告后执行：`APPROVED_ACTUAL_MAIN03_NAVIGATION_AND_MARKER_BINDING_DELTA`。M3共514页，SHA `f8d7d351288340bd540ee91ca249d13c54b71db9516f10f9a15c6bce9a2a6398`。

C所辖15变文件（13个B作者文件、root章7两个文件）共19个marker均独立读取old/current原始字节，剥离仅授权marker/空text包装/新增leavevmode后raw及EOL完全相同；每项也逐字命中A真实marker快照。15份新C真实批准快照已建，完整旧ledger/相应原报告/15旧真快照已归档，旧快照不覆盖。

原whole-native数学/原文忠实性批准沿用，本次仅新增实际M3位置门。所有旧局部preview/FLS/看图字段保留原审校时点含义，没有冒充当前新preview。受影响unit/component当前身份和当前报告已有明确时间边界。

C账本仍66原生语义单位、149递归实际输入；全部149当前文件与当前真实C快照逐字相同。

ch02/ch03/ch04三个driver原字节不改，仅刷新受影响依赖身份及实际递归输入SHA；未重编章。A/B/root账本未改。

| 文件 | 新SHA | marker |
|---|---|---|
| book/matter/introduction.tex | f63513d4006357c4dafefc017b9683962a02671175285af2687c575ca4599be3 | src:18:start |
| book/chapters/ch01-sec01.tex | fec19043658378d709a129a80994d0e6fd58da251566db627fea801a115cb773 | src:30:start |
| book/chapters/ch01-sec03.tex | cfce69ac1aecf6780e6e8d0a16e830bc0b06b0ccc89a43eaac0d70c76209481b | src:36:start |
| book/chapters/ch01-sec08.tex | 11870a0be22309f9c79c919deb80db6b9841b933ed73961fa9c10aec49ac86f0 | src:62:start,src:63:start |
| book/chapters/ch01-notes.tex | d6aa3637dd315c1bfafdc09e1aaf05350342f25101c68219eaa9d6852549fd30 | src:74:start |
| book/chapters/ch02-sec06.tex | 85646efdb39adfbea910242a815637450d804f02b08ad0a9460c85f80f677579 | src:108:end,src:109:end |
| book/chapters/ch02-sec07-part04.tex | b1310acc64a90073a0b80da55c1c756492b0b91d149df8af916f735500385d12 | src:120:end |
| book/chapters/ch02-exercises-part02.tex | 72b96478ad7f92599c1acc1d23124b139c6eedcf8483dbb2c82bb5b44044bcde | src:149:end,src:151:end |
| book/chapters/ch03-sec03.tex | 890c614924b5d8afabe282f3bde9f4581c257f8c85ce9e788cbad95896b20750 | src:165:end |
| book/chapters/ch04-sec01.tex | c552e63d6658ab364106683dff0931748b0ae7de1437d79405dcf6501c0540dc | src:185:end |
| book/chapters/ch06-intro.tex | d07522d127148ae91b45b8fe9c530b9e1c9112a16e05212246aca124713798db | src:233:start |
| book/chapters/ch06-sec03-part02.tex | 1a94a743f41a9e5dd4bf43ffce605fe0c8dee8ca87b54c3422c458ad524ae058 | src:249:end |
| book/chapters/ch06-sec07.tex | 11c63a3312a876f7e91caaf46d76d7694fc69d82a2015717d2d980a36f6b53b5 | src:280:end |
| book/chapters/ch07-sec02-part02.tex | c96a9aaefd5163305ed124ecb9416c095316a58e2308fb519f467ba28a851d92 | src:301:end |
| book/chapters/ch07-sec02-part04.tex | 219a164f9f6c185c4b3cd55bad8d5cc3c19de49f7e66f273298c88ee65799939 | src:303:end,src:304:end |

历史保全目录：`[project]\qa\reviews\C\revisions\main02-before-C15-main03-identity-refresh`。本次没有新增整原证明复审、整章视觉/冷编、ZIP或发布批准。
