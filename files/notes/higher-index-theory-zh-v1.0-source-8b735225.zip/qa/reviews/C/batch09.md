# Higher Index batch09 独立审校 C

状态：两个完整单元均 approved，译者B／非作者审者C。

章2完整导语物75–76；完整2.1物76–81，82仅下一节边界。当前两稿与作者真实提交字节完全相同。八页原图（含82边界）和全部六页当前译图均实际查看，逐段逐式核对全部16对象、式2.1、16无编号显示（含6图）、原脚注1/2与所有普通说明。

## 独立数学核验

- Chapter2 introduction75-76：All four original paragraphs and continuation retained, including precise distinctions: 2.1 algebra only; 2.2 complete norm; 2.3 unbounded traces; 2.4 index obstruction; algebraic versus topological K1; 2.5-2.6 topological choice/Bott; final2.7-2.10 program. No unproved self-containedness claim introduced.
- 2.1.1-2.1.3 and transitivity76-77：Finite-support matrix algebra and direct system use nonunital morphisms explicitly. Under e=vw,f=wv and f=ts,g=st, (sw)(vt)=s(wv)t=sft=s(ts)t=(st)^2=g and (vt)(sw)=v(ts)w=vfw=v(wv)w=(vw)^2=e. The two and four curved-arrow diagrams retain w:e->f,v:f->e,s:f->g,t:g->f with no reversal.
- 2.1.4-2.1.8：Block sum is defined after finite sizes are chosen; size and representative independence are left to the specified exercise, not assumed canonical at the matrix level. Module is explicitly a right module e(R^n). Rank examples keep the nonnegative-integer monoid and absorbing infinity addition. Serre-Swan/Whitney interpretation and exercise2.11.4 retained; no new proof or replacement theorem added.
- 2.1.9 full proof / equation2.1：The easy direction gives vw=u^-1 f²u=e and wv=fu u^-1f=f; in the nonunital case these elements lie in the R ideal. After normalizing v,w via the cited exercise, U=[[w,1-f],[1-e,v]] and V=[[v,1-e],[1-f,w]] multiply both ways to I: diagonal terms wv+(1-f)^2=I and (1-e)^2+vw=I; all off-diagonals vanish by we=fw=w,ev=vf=v. U diag(e,0) V=diag(f,0). Both unit cases, inverse formula, conjugation and stable-last-sentence retained.
- 2.1.10 conceptual diagram：All8 module nodes,3 direct-sum signs per row, and4 arrows checked individually: w:eR->fR, v:fR->eR, identities:(1-e)R->(1-e)R and(1-f)R->(1-f)R. Crossings are not extra nodes. Both id labels and w/v are readable on translated page4.
- 2.1.11-2.1.13：Universal group target and uniqueness of dashed monoid/group map are retained. Grothendieck construction and Z example retain both exercise choices. Functoriality is initially for unit-preserving maps, followed by the kernel definition for arbitrary algebras; those hypotheses are not conflated.
- 80 / consistency and general functoriality：Under source Definition1.1.9, (r,lambda)->(r+lambda 1_R,lambda) identifies R+ with R directsum C when R is unital. The three stated facts give the kernel identification. For general phi, phi+(r,lambda)=(phi(r),lambda) preserves multiplication and unit and commutes with quotient maps. Quotient has a unital scalar splitting, so the displayed K0 rows are short exact. Kernel restriction gives the unique dashed map. Both full diagrams including zeros/equality edges retained.
- Remark2.1.14 source note：Independently checked in full: pi is entrywise and sends eprime in M2n(R+) to M2n(C). Stable class equality means rank(pi(eprime))=n by the preceding examples; an idempotent over C is similar to diag(I_n,0_n). Adding[1-f]-[1-f] gives eprime=diag(e,1-f), because diag(f,1-f) is stably equivalent to I_n. For n1 and e=f=0, eprime=diag(0,1), and the swap conjugates its quotient to diag(1,0), not a literal1x1 matrix. The note correctly distinguishes the visible size phrase from the intended stable convention, retaining all original equations and not declaring the stable conclusion false.
- Remark2.1.15 source note：For the literal entrywise map induced by r->diag(r,0), every n-by-n block has only entry(1,1) potentially nonzero. With R=C,n2, the finite matrix with one block E22 is outside its image. This verifies the conditional non-surjectivity claim. Independently, the bijection (k,a)->n(k-1)+a identifies finite-supported block matrices multiplicatively with finite-supported scalar-index matrices, giving an abstract algebra isomorphism. This reindexing is not the entrywise corner map. On idempotent classes finite permutations identify the corner image with the corresponding full stabilized matrix class, so no counterexample to K0 matrix stability is asserted. The note is correctly limited to two interpretations of induces.
- Remark2.1.16 trace argument：Finite support makes all diagonal sums finite, and tau_infty(ab)=sum_ij tau(a_ij b_ji)=sum_ij tau(b_ji a_ij)=tau_infty(ba). Thus vw and wv have equal trace and block sums add; the Grothendieck universal property gives a group homomorphism. For unitization, tau+(r,lambda)=tau(r)+lambda is a linear unital extension, and tau+ on the commutator equals tau(rs-sr)=0. Restricting to the K0 kernel is valid without requiring positivity or continuity. The original final phrase linear functionals remains in quotation marks.

两条译校注均独核成立：2.1.14是原尺寸措辞／稳定嵌入解释的区分；2.1.15是逐项角映射与重排指标抽象同构的区分。均保留原文，均不把预期稳定K0结论误报为错误。

## 编译、视图与身份

两遍独立冷编退出0，全部六页几何／文字／1.5倍像素与作者当前PDF逐页相等。六图节点/全部箭头/标签逐一对照，交叉不是新增节点；两脚注与呼号均在译页2/3，均无遮挡/缺字/溢出/未定义。14个源首末目标均有效；脚注末锚可能在同一译页下方，未虚称所有源目标按垂直坐标单调。

原C13单元与真实批准快照、B已批章1driver/技术入口以及core/宏/导航均保持。新两稿真实批准字节已复制保存；C账本现15已批语义单元。没有修改B正文，也没有全章2或全书批准。

- book/chapters/ch02-intro.tex：`8d43f3a8b967d9a09f9cc1fa1700396f29d850c4ab62fed80fbb317350c11720`。
- book/chapters/ch02-sec01.tex：`d6234db1b3e6ff1ac53746335d8ba42aa68a497f7d3c2aa23767707e5e05ae0f`。
