# Higher Index Theory §1.4：独立审校C

**approved；作者B，审者C。没有待修订阻断项。**

原件SHA256 `7b901e5ee458369ccf89da63b5a0b0b5e8aeb210d70cbd28a71f9ed473c839de`。物42的1.4标题至物46的最后说明句、1.5标题前，共5原页全部实际逐页看图。当前3页预览全部实际查看。

批准译稿SHA256 `827784568d9ac2f3add087365077a30b49a70d53a08074ccf45247c20b38899c`；预览SHA256 `9a18744ecf97a08ae55f519f6a565924d834bd43e3865b49d24cc69af44463ad`。真实批准快照、源范围与输入身份见同名JSON。

7个对象1.4.1–1.4.7、编号式1.6/1.7、9显示组、四条完整谱刻画、epsilon/3证明、例1.4.5两个独立论证、全纯函数演算定理及其连续性补充全部保留。没有将证明梗概补成原书没有的完整证明。

## 非有单位元校注的假设与数学核验

先读原前提：物42以A有单位元引入式1.6；物43随后明确推广至不必有单位元并给出式1.7；命题1.4.2重新量化“LetAbeaC*algebra”，没有保留有单位元限定。书前也明确允许非有单位元代数。因此该注是针对命题字面一般性的条件说明，不把有单位元情形误报为缺f(0)=0。

若A无单位元，A+→C的商映射将a送到0，因此0必在spec(a)；A_K非空便强制0∈K。由单位化函数演算的自然性，商映射将f(a)送到f(0)，故f(a)∈A当且仅当f(0)=0。空A_K与有单位元情形均不被擅加这一条件。

独立核c0反例：A=c0(N)、a=(1/n)、K={0}∪{1/n}。单位化为收敛序列：λ=1/m时某坐标零，λ=0时无穷远商值零且倒数n无界；其他非零λ的逐坐标倒数收敛到-1/λ并有界，因此spec(a)=K。f恒1的演算值为外加单位，不在c0；删去0后的常值1也不在C0。该例满足原不加单位条件的命题全部实际假设。

证明中“多项式”必须沿前文读作z与bar(z)的*多项式，不能误读为只含z的全纯多项式。若f(0)=0，可先以q近似到eta，再取p=q-q(0)，误差至多2eta且无常数项。正规元素谱在K中给出统一范数界R；按乘积差的望远镜展开和伴随等距性，固定*多项式在此有界球上统一连续，所以epsilon/3证明在修正目标/零点条件后有效。

## 其余逐段数学核验

- **section_opening_and_1.6_1.7**：Both canonical isomorphisms, character evaluation map and injectivity/homeomorphism explanation preserved. Functional calculus evaluatesz ata andbarz ata*; no-constant-term clause and vanishing-at-zero link kept. Original Definition1.4.1 commutative wording retained without silently broadening it.
- **1.4.2**：Complete epsilon/3 proof checked, including normal-element norm bound, uniform choice on the bounded spectral set and all three error terms. Moving the closing we-are-done phrase before the last display is a typographical regrouping only. The separated target-space note is verified in detail.
- **1.4.3**：All4normal-element iff criteria retain both directions and unital-as-needed qualification: selfadjoint/real spectrum, projection/{0,1}, unitary/unit circle, positive/nonnegative spectrum. The printed sketch uses functional calculus for the first3, constructsb=sqrt(a) for nonnegative spectrum, and intentionally sends the converse positivity proof to bibliography; no invented full proof substitutes for that omission.
- **1.4.4**：On the lineRe(z)=1/2, z=1/2+it gives|z^2-z|=1/4+t^2>=1/4. Functional calculus/norm bound exclude that line fromspec(a). Half-plane characteristicchi is continuous on the spectrum, haschi(0)=0 where relevant, and chi^2=chi=bar(chi), so its image is a projection inA even in the nonunital case.
- **1.4.5-first-argument**：Invertibility/positivity ofa*a and compact spectrum give a positive lower spectral bound, so inverse square root exists. u=a(a*a)^(-1/2) hasu*u=1 and is a product of invertibles; its left inverseu* must be its two-sided inverse. No normality ofa is assumed.
- **1.4.5-second-argument**：Inductively b(b*b)^n=(bb*)^n b, hencebp(b*b)=p(bb*)b for polynomials. Approximation on the union of the two compact nonnegative spectra passes the identity to continuous functions. Apply withb=a* and reciprocal function to justify a(a*a)^(-1)a*=aa*(aa*)^(-1)=1, with the multiplication order intact. Both original arguments retained.
- **1.4.6**：Source statement fully retained: unital BanachA, openOmega containing spectrum, compact-open topology onH(Omega), unique continuous unital algebra map taking the identity coordinate toa, nonunital zero-preserving qualification, and norm-continuity addendum. It promises continuity, not uniform continuity for nonnormal elements. No missing source proof supplied.
- **1.4.7**：Polynomial spectral mapping andr<=norm excludeRe(z)=1/2 for any alloweda, without normality. The characteristic function is holomorphic on the open disconnected neighborhood C\{Re(z)=1/2} of the spectrum, not merely a function on a closed set. It vanishes at0, so the nonunital calculus returns an element ofA; chi^2=chi yields an idempotent, not automatically a selfadjoint projection. Final comment thatExample1.4.5 already needed no normality retained.

## 版面、重编与接口

所有3页当前作者预览实际看过；C在独立新目录两遍XeLaTeX成功，3页几何、提取文本和1.5倍渲染像素与已看作者PDF完全一致，字体均嵌入。没有缺字、裁切、溢出或公式/列表丢失。

旧6个批准单元和宏保持原哈希。共享42的End在本节补齐；46的End属于后续1.5，不算遗漏。C账本加入本单元，批准仅绑定当前字节。

全书合编、最终导航、实际源码ZIP冷重建、包审计及发布仍是独立门槛。
