# Higher Index batch31 两完整原单位独审

4.6 Exercises与4.7 Notes分别approved，详batch31-exercises与batch31-notes。三原页及180/213/234/235语境全实际看；两习题译页+一Notes译页全看，术语delta后变页2重看/1严格像素承接。仅把原properly supported已定义词恢复为固有支撑，原题/所有式/提示/两Notes段及六引用组字节保持。没有新校注/答案/宏。两单位分别两独编0/14及6嵌字/所有五源目标/FLS5各匹配真实提交，无目标诊断。

旧40语义递归72实际与四技术真快照冻结，新两真快照，C现42语义74实际。第4章所有语义原单位现齐，可另建显式章链申请静态技术审核；这里不签未建driver/整章PDF/全书/ZIP。
