# Higher Index Theory：batch02 独立审校 C

**批准当前字节版本：approved。作者B，独立审者C。**

来源SHA256：`7b901e5ee458369ccf89da63b5a0b0b5e8aeb210d70cbd28a71f9ed473c839de`，原件597物理页。本批实际独立逐页看原图：30, 31, 32, 33, 34, 35。原页分别以1.8倍渲染并逐页查看；没有用OCR或作者摘要代替公式审读。

## 逐单元状态

|单元|来源物理页|状态|译稿SHA256|
|---|---|---|---|
|ch01-sec02|30,31,32,33,34,35|approved|`28ba5c42f48dccc2e30aaf5c41bf020f64e9e6ecbddf6313d836fa3d3c2bec9e`|

每份译稿当前SHA、原件SHA、首末对象、作者/审者身份及真实批准字节快照均在同名JSON中绑定。批准字节已实际复制到qa/approved-bytes/C/<sha>/book/...并复算校验，不是仅登记一个approved字符串。

## 完整性与假设核验

1.2的8个对象1.2.1–1.2.8、27个无号译稿显示组及编号式1.1–1.4齐全；27含把原推论1.2.7行内等式独立排成显示式，不增加结论。五个完整证明逐行核验，原脚注2及习题1.9.2/1.9.3/1.9.4引用保留。严格止于物35的1.3标题前。

核对了逆元差的非交换乘法次序、预解式导数正号、Liouville与Hahn–Banach论证、固定lambda的一致有界原理、幂级数延拓、正规元的2^n幂与2^{-n-1}指数，以及同态像的谱包含方向。

先检查原书全局约定：物24零代数在使陈述显然失败时不纳入；注1.1.2规定有单位元Banach代数的单位范数为1。非空谱定理未因此被误报“漏非零假设”。同时，原书明确允许一般复代数及更一般语境，不能把所有“复代数”自动当成Banach代数。非有单位元情形的逆元与谱按单位化理解；此为原定义的上下文，不是擅增全局有单位元假设。

## 译校注的独立数学核验

### hi-theorem-1.2.1-source-note

- **finite_sum_check**：For every integer N>=0, sum(n=0..N)b^n(1-b)=1-b^(N+1), including noncommutative algebras since all powers are of b. Under||b||<1, both b^N and b^(N+1) tend to0. Thus the original displayed equality of limits remains true; the note correctly describes a harmless finite-index mismatch, not a false limiting conclusion.
- **parenthesis_check**：Source31 visibly contains the extra opening parenthesis in||(a^(-1)(a-b)||; translation and separated note preserve/identify it.
- **inverse_norm_check**：Source31 actually prints||d_n||^(-1), not||d_n^(-1)||. Let A=M2(C) with operator norm, a=I, epsilon_n=1/(n+3), a_n=d_n=diag(1-epsilon_n,1). All a_n are invertible and a_n->I;||a-a_n||=epsilon_n<1/2. Then||d_n||=1 but||1-d_n^(-1)||=epsilon_n/(1-epsilon_n)>epsilon_n=||d_n||^(-1)||d_n-1||. The printed second inequality fails for an entire sequence satisfying all hypotheses. Replacing the reciprocal scalar norm by inverse-element norm yields||d_n^(-1)||||d_n-1||=epsilon_n/(1-epsilon_n), compatible with the preceding<=2 inverse bound.
- **multiplication_order**：Independently checked a_n^(-1)-a^(-1)=a^(-1)((a_n a^(-1))^(-1)-1) and d_n=a_n a^(-1); no illicit commutation is introduced by the translation.

### hi-definition-1.2.5-source-note

- **assumption_check**：Definition expressly says complex algebra, not Banach algebra; the source allows this generality in Remark1.1.2. Neither normalized units nor the zero-algebra convention removes this issue.
- **independent_counterexample**：In the nonzero unital complex algebra C[t], the only units are nonzero constants: for nonzero polynomials p,q with pq=1, degree(p)+degree(q)=0. Each t-lambda has degree1, so cannot be invertible. Hence spec(t)=C, and the set of moduli has no maximum. This verifies every step of the translator note.
- **positive_case**：For a nonzero unital Banach algebra in the preceding theorem context, spectrum is nonempty compact, and the continuous modulus attains a finite maximum. The note correctly distinguishes that context from arbitrary complex algebras.

### hi-theorem-1.2.6-source-note

- **quantifier_check**：The proof fixes lambda. Scalar power-series convergence gives bounded phi(lambda^n a^n) for each bounded phi; UBP applied to T_n:A*->C, T_n(phi)=phi(lambda^n a^n), yields an M_lambda for that fixed lambda. Hahn–Banach identifies||T_n||=|lambda|^n||a^n||. It does not supply one M for every lambda in D.
- **independent_counterexample**：In A=M2(C), take nonzero a=[[0,1],[0,0]] with||a||=1 and a^2=0. For mu!=0, (a-mu I)^(-1)=-(1/mu)(I+a/mu); a itself is noninvertible. Thus spec(a)={0}, r(a)=0 and D=C, without using the spectral-radius theorem under audit. For each fixed lambda the powers(I,lambda a,0,...) are bounded, but n=1 gives|lambda| and no bound uniform over D. This satisfies all Banach/unit/nonzero conventions.
- **repair_check**：Fix0<|lambda|<R and choose M_lambda>=max(1,|lambda| ||a||), finite and independent of n. Then||a^n||^(1/n)<=M_lambda^(1/n)/|lambda|, and limsup<=1/|lambda|. If r(a)>0, let|lambda| increase toR=1/r(a); if r(a)=0, R=infinity and let|lambda|->infinity. Excluding lambda=0 before division is necessary. The authored note supplies exactly these qualifications, with a!=0 already stated in the proof.

上述核验均在满足原书实际假设的模型中进行；没有仅凭“字形不同/源式有疑”就机械批准。原式按合同保留，译校注明确分层。批准忠实译稿与注释，不给原错公式的真值背书。

## 版面、重编与源页接口

作者预览5页全部实际逐页查看。独立在全新C输出目录两遍XeLaTeX成功；与已看作者PDF逐页几何、提取文本、1.5倍渲染像素全部相同，证据见independent-preview-rebuilds.json。字体均嵌入；未见裁切、重叠、缺字或脚注/子项丢失。源语义批准与这一预览版面检查分开记录。

脚注呼号1/2与注体原意及位置均核对；原件对应页和译稿均无脚注PDF链接动作，未把不存在的链接目标称作导航通过。

跨单元共享源页23、30的Start/End分别位于正确文件且各一次；全部已交文件合计Start16–35各一次、End16–34各一次。End35属于未来1.3的真实页尾，当前不算遗漏。

当前无未闭阻断项，各单元批准有效；若这些文件字节修改，需要受影响范围的独立差分复查。全书合编/最终导航/实际源码包冷重建与发布仍是独立后续门槛。
