# A 完整12.5独立语义与数学核验

作者C，非作者A。准确原483题头至488首段Lemma12.5.4完整证明/QED、12.6前。六整原/六当前译页全部实际1.5看，325–327原粗切除/MV及330原7.6.14完整上下文实际看，486/487原生4倍大图及487中间左项原生5倍另核。四TeX全文逐段逐式，四对象/两长printedproof/三原Roman/四tag12.26–29/三完整交换图33箭头/五分离注全保，无脚注，无新习题答案。

## 定义与Lemma3全论证

有限块距离有限，coarseunion与separatedcoarseunion分别保全有限跨块距离及∞跨块距离。一个共同的rho±控制全部n，lowerproperness必要；有限块的Hilbert像只张成有限维仿射空间，平移后取线性span不改差的范数，因此由全局粗嵌入得到的限制可用有限维E_n而不丢uniformcontrol。原映射fn紧后公式f字母不统一确印，第一注只解释各块读取fn。

Remark2：若d、d'都满足三条粗并条件，给定R，d跨块距离≤R的点对只可能涉及有限多块（由dist(Xn,rest)→∞），每块有限，所以这些跨块点对在d'中的距离有有限上界。块内两度量相同，得id bornologous；反向相同。由有限块/远离尾部，任一有界集有限，有限值度量下有限集有界，故id proper。这证明coarseequivalence，不声称度量唯一。

Lemma3：有界几何使闭半径球包含于稍大开球而有限，故每个径向Xn有限。Rn=[n³-n,(n+1)³+(n+1)]覆盖全部非负径向；同奇偶n与n+2的区间间隙为3n²+7n+4→∞，因此Y、Z分别是所述粗并，交按evenannulus与Z的有限交块亦粗并。X0=[0,2],X1=[0,10]，所以基点x0在Y∩Z；原Xn=n≥0并非漏n0成员。继承有界几何、粗嵌入。

粗切除：取整数n>r，s=(n+1)³。若R(x)≤s，用x0∈交即可。否则d(x,y),d(x,z)≤r给R(y),R(z)>n³。若y,z均在两色排他部分，则落入不同奇偶的coreband [m³+m,(m+1)³-(m+1)]，运行m≥n；相邻反色core间隔为2(m+1)>2r，非相邻更远，故|R(y)-R(z)|>2r，与d(y,z)≤2r矛盾。原两个union里运行m而端点n确为源错字，第二注准确；正确变量解释后证明闭合。原末写≥2n≥2r不需新错注，因为已经严格n>r，足以矛盾。

有界几何有限值X是离散proper，每个子集Y/Z闭；满足325 Definition7.5.3的闭覆盖条件。325–327 Theorem7.5.5给Roe与localized的MV和评价交换，再330 Exercise7.6.14正是所用KX/装配长列。三主要组和两侧延续箭头、三竖直装配箭头全保，用五引理两次数得到Lemma3；不把该原引用练习补写成教材中新答案。

## Lemma4与五条源注的scope

12.26原生细图确为n>m时dist(Xn,Xm)>diam(X0∪...∪Xn)，右端确包含Xn。对两个非空有限块，任选a∈Xm,b∈Xn，左inf≤d(a,b)≤右sup，故所印严格>不可能；两单点时左=右已足够。原coarseunion定义跨块距离有限，有限prefix直径有限，一切原条件兼容，非用∞扩展度量造假反例。第三注只指出该wlog选择及后续单形分解不能据此直接成立，保原式/原证明，不声称约化定理或粗BC假。

仅QA的相容解释：若Dn=diam Xn，选严格递增A_n→∞且A_n>max(D0,...,Dn,2A_(n-1))，保块内度量，跨块m<n距离置A_n。三不同块满足max型ultrametric三角；同块内部距离≤Dn<A_n，不破跨块三角。此为有限值粗并，按Remark2与原粗并粗等价。对共尾r≥D0，取prefix到最大A_n≤r的n，该prefix所有距离≤r故Rips为全单形，所有尾跨块距离>r，所以源所需prefix+separatedtail分解成立。不能声称所有小r<D0也已有全单形prefix，更不能把此QA新度量偷换成源12.26。书注保必要差异而未补完整替代proof。

12.27：separatedY的有限Rips复形分成各块。紧支撑directsum的K类到全体K同调由各块projection检测而单射。Roe侧directsum紧块理想也被块评价检测，K边界为零后可按原群商列读取。最上行正极限iso只需每固定有限块r≥diam Xn时contractiblefullsimplex及pointassembly，直和类有限支撑，所以可选共同r处理该类；不误需一个r同时控制无限全部n。源却写diameter(X)原生图确无下标，第四注正确指出整体通常无界并不提供每块阈值。

12.28：在相容prefixmetric与cofinalr读取下，finiteprefixK类及有限支撑tail最终进入一个有界simplex，最上行colimit为pointK，映到compactK为iso。PrY是PrX的子空间，但不能把仅限在旧PrY稠密点上的表示硬叫整个PrX ample；可以选包含新点并通过proper有界位移Borel选点关系的共同ample模块（两表示），这是Roe层的coarsecover识别，而非K同调的粗不变性。K同调层只在杀有限支撑prefix后的群商比较，不误说两个全空间K同调同构。

正确的Roe代数比较为C*(PrX)=K(Hr)+C*(PrY)：有限传播跨块项因coarseunion尾间距发散，只涉及有限块/有界prefix，局部紧性使它们compact；闭包传递。Y的blockdiagonal算子为compact，当且仅当各compactblock norm→0，交为c0 directsum。于是商同构。源第一代数式RHS再次写X，虽为tautological正确包含等式，却不能单独给X/Y商比较；第五注准确提醒需要此前对象识别而保原重复X。

原12.28左下分母P0没有在此定义为前面的Delta_r，原后两句把五引理比较叫“右侧/中间vertical”，实际上是两个竖直正合列间的horizontal装配比较；这些源事实均实际图核，原方位词不静改。初看整图中间左项字形曾似Y，另做原生5倍图明确是X，当前稿X正确，未报虚假问题。所述五引理路线在相关正极限的正确比较下成立，不冒称原错误wlog和全部不相容标签被字面证明。

## 版式与范围

三个图：MV六主组/四左右延续箭头+三装配箭头，共11；12.27和12.28各十节点/八竖直+三水平箭头，各11，合33。原零端点、groupquotients、源P0、Kcompact目标以及tag都逐一核。当前6末页只含完整编辑注，不是原proof遗漏；wholechapter最终重排另验，不为局部QA页数改数学。十source目标End483/full484–487/Start488，488End归12.6。无作者修改请求，本审者不改C稿；两遍独立编译和当前真身份记录另存，仅整12.5局部验收。
