# 三个既有 core 的独立技术身份补齐

状态：`TECHNICAL_INPUT_ONLY`。此为 B 现在首次明确建立这三个文件的逐文件独立技术批准及真实快照；不虚称早期已有独立 core 快照。

| 文件 | 当前/旧真实副本/原报告一致的 SHA-256 |
|---|---|
| `book/preamble.tex` | `dd64887dce8fea041d5fd946bc81b9c00ae28710934ff56c41499901803aeee2` |
| `book/navigation.tex` | `770aae7244ebd3a86b55a1c32485972eac3503df1f09a96bdd140a3acf466aae` |
| `book/style/textbook-template.sty` | `c03b2346e991871bcc62324c083a2a00adfabc05e4cea75edc6f5c499e800732` |

B 已完整读取当前 preamble、navigation 和 style。确认它们分别承担包/数字原标识/源锚、导航补充、冻结版式和原编号环境；未见隐藏缺章分支、执行外部命令或新增数学正文。

实际逐字比对 `qa/reviews/C/chapter01-chain-submitted-inputs/book/...` 三个历史真副本及 C 当时作者报告的 core/technical_submission SHA；同时读取当时 C 与 B 两份真实 `.fls`，三输入均确实列于其中。B 原独立章1技术审状态 approved、三遍退出0、42页；真实 B PDF 当前哈希仍为 `74dd1b481ae6029d1a5cc3563c404bffe2b640c3a965d586571178e5517ec9fb`，与原 B 报告相符。这里只承接这些真实旧证据，没有再编章1或重审数学。

现在三份当前真实字节存于 `qa/approved-bytes/B/<SHA>/book/...`，technical-ledger-B 只追加三条，原两条技术记录及原 artifact 全保留；写前完整旧账本另存 history。

旧只读 preflight JSON/MD、当前 main/build、所有 book 正文均未改。正式 main/build 的技术预核另报 pending；完整整书 FLS、139行TOC、149/355引页、最终源锚/视觉/源码包均不在本次批准范围。
