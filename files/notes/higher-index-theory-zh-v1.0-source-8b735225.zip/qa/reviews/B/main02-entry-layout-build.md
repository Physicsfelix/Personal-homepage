# 正式 main02 三技术输入独立审核

状态：`TECHNICAL_INPUT_ONLY`。批准本次 root 的三个实际输入身份，不代签整书最终 PDF 或源码 ZIP。

| 输入 | 当前 SHA-256 |
|---|---|
| `book/main.tex` | `518b58e5b8161acf188f961ff45fcc340f6646ca783aa92ec2e9e1fb9cab6770` |
| `book/layout-integration.tex` | `41888e1d28cb0d25902d78ce6d30941837bf12ff3cbc781f905a15e7ff05c095` |
| `build.ps1` | `3baabdfe76073c492e16f81e0f1e8256270583c8daa246d3dddacaebffd232de` |

## 实际输入与目录门

B 独立解析真实 main02 FLS：404个不同本地book输入，等于声明闭包；404份当前文件/真实提交副本 SHA 全同。旧402路径逐项命中当前独立审者账本和真实批准快照，包括继承已批完整单元状态的nested component/原生图记录，不能只查wrapper。13幅原生图、390个TeX及一个本地style闭合；没有fixture或原PDF输入，其他项目内INPUT仅是当前构建的aux/toc/out。

新main的43个直接input＝4个前导＋39个原序正文根，全部无条件，独占宏owner各一次。layout只override originalunnumberedheading：正文section*不变，写目录由section改为subsection。main仅加一条input，移除后逐字恢复旧main及EOL；旧402数学/图/core全部未动。

真实生成toc：5part＋22chapter＋112section＝139可见行，另11个subsection保持隐藏。已逐行核原139manifest的类型/原编号顺序，139目的地均解析到正确PDF页标；实际目录PDF11–15五页完整看过，章3副题已出现，11正文小题头不再新增可见行。最小真实toc试验也核：before chapter/section/section/section，after chapter/section/subsection/subsection。

此前preflight字面parser漏宏展开，139不能当真实目录门；失败main01和诊断报告均保留。当前真正成功的main02 PDF为514页、3,526,506bytes、SHA `82e0939e3af626d05c13b5df81bfb0586e3ee561ffc20cd4e47853cdfb08d3e4`。本报告绑定它作为技术证据，不批准全部514页视觉或1194来源端点的语义对象绑定。

## 构建与时序

build.ps1仍是此前独立AST/安全/路径审过的同SHA；实际root latexmk构建完成，完整FLS可读。没有新跑B整章/整书，也不声称备用XeLaTeX分支或最终ZIP冷构建已经执行。

时序诚实保留：准备recorder时shell引号错误，main02启动后才保存404真实提交副本；不把它写成编译前冻结。B实际比对了当前完整FLS路径集、current/copies、402批准快照一致，承接root声明期间无源编辑。实际最终ZIP的独立冷建仍是之后的更强实物门。

main02当前确有9条Underfull及15条hyperref math-string warning；不声称零warning。相关最终版面/书签影响另由root/A/C按实际证据核，不捆绑到本次目录类别修正。

## 新身份与范围

三份真实批准快照写入 `qa/approved-bytes/B/<SHA>/...`。B技术账本仅追加三条，原6条及artifact保留，写前完整旧账本归档。旧core/数学正文、新main/layout/build及他人账本均未被B修改。

原只读preflight、pending静态预核报告和失败01证据保持历史采样；当前批准不回写它们。最终全PDF页图、完整来源对象绑定、Symbols/Index最终检查、portable源码包与实际ZIP冷重建均另门。
