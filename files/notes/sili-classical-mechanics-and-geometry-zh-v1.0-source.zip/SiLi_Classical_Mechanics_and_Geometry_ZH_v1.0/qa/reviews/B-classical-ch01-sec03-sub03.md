# B 独立源审 ch01-sec03-sub03

批准当前 SHA256 `a66eba79bc8b3b7398ec325d9731b9f47189f7d255f65ae631ae04acb383e483`。源物理 25,26 全页实际2x读图，对照完整当前TeX逐段逐式核对。编号、原脚注与无号段完整；无待修项。全书实际排版另验。

Source25 time translation example includingfullenergycomputation/boxedprinciple and cycliccoordinatevariation retained.

Source26 freeparticle andelectromagneticcanonicalmomenta includingQA_i shift, allSO/so definitions/oneparameterexponential/componentrotation/antisymmetricmatrixspecialization/angularcrossproduct retained.

All3originalboxed symmetry→conservation principle displays present. Originalnote6 belongs precedingtheorem1.3.4 and iscorrectlynotduplicated.
