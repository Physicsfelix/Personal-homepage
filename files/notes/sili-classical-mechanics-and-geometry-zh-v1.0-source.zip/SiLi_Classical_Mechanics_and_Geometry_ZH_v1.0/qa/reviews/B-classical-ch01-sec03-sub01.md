# B 独立源审 ch01-sec03-sub01

批准当前 SHA256 `4395fb092203390b87e56b9290001e52da528a0735cbc938c5c968afd598d333`。源物理 22,23 全页实际2x读图，对照完整当前TeX逐段逐式核对。编号、原脚注与无号段完整；无待修项。全书实际排版另验。

Source22 full real-time action divergence warning, compactly supported first variation and integration by parts, Euler-Lagrange and fixed endpoint interpretation retained.

Source23 infinitesimal definition all velocity/time dependence, original derivative-overbar notation, full total derivative expansion, time-translation example and all deltaq/deltaqdot/deltaL/action-translation steps retained.

Author footnote4 infinitesimal variable/first-order alternative present at the right callout.
