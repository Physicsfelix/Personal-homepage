# B Classical3.6.2 独立源审

批准当前SHA `2a2cb2c222964b04dba2bd50d50eb04c7178a8fa982e142fc18998e502c1e065`，五源页全部相关内容实际2x读。

原126–130五页相关范围逐幅2x实际读，与整个currentTeX逐段式核。6原号3.6.11–16、完整对偶配对/环面/平移/旋转/GL与SO例全保。

旋转三矩阵与四步向量场计算、GL dualinverse transpose action/全部求导与双求和/5×5稀疏Eij全格/末角动量均核齐。源128dp^i与dx^i上标及后pi下标混排保留；fraktur g、rsfsH、italicgl/so字体保。

原127四箭头交换图从actualcurrent源码独立编译并2x实际看：g到C∞/g到Vect/C∞到Vect/H_A到V_A四箭头及Hamilton向量场中文label全齐。无脚注/源习题/新增解答。

非连通M上df固定时f仅逐连通分支相差常数，note001准确。

定义两条件未推出H线性：平凡R作用且H_a=a³为常函数时满足两式但非线性，无法配成g*元素；note002准确。

原129第一偏导分母只印xi，图上可见，note003指出缺partial而原式保留。

由本书Poisson定义直接求导H_A=-p^TAx得{H_A,H_B}=p^T(AB−BA)x=−H_[A,B]，note004与源3.6.10正向左作用反同态同源，正确。

94源锚，6原号，无待修。非最终全书PDF/冷编批准。
