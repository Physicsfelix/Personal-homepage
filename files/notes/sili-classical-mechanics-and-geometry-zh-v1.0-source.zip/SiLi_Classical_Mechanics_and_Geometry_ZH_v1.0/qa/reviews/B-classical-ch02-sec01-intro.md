# B 独立源审 ch02-sec01-intro

批准当前 SHA256 `ef10588648eb04bc95095ca8d2e893460c38eb039d0b61beefee185d8a1b1e3b`。原47相关页实际逐幅2x读，对照当前全部段式。该单元只有原题头，未增加伪导语。原所有数学式/陈述保留，现短注均独核。无未修项；正式PDF布局另验。

Originalsource47headingonlyisfullypreservedandtranslated; noprosemadeup.
