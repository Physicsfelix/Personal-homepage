# B 独立源审 ch03-sec05-sub01

批准当前SHA `c98ed9ed80c80d47bdfd0e9fbc8486f2f4a15d1ce173d4ddb9278d5d7c6ee2b9`。实际物[113, 114, 115, 116, 117, 118, 119, 120, 121]全部相关原页逐幅2x读并与current TeX逐段式比对。

113–121全部原页相关内容逐幅2x实读并与current TeX全段式对照，六小标题/17原编号对象俱全。

chart/Hausdorff可数基/atlas完整定义、球面两投影及逆图坐标变换、CPn商及全部去帽商坐标、光滑函数及换卡、p形式与向量场拉回/推前方向逐核。

切向量曲线两卡导数相容、子流形定义/秩满射三行矩阵、两正则值例全部中间式/球面、Hopf北极原纤维、Cartan两算子及五恒等式全保。

六原生图从actualPDF独立2.5x重渲逐幅实际看，区域、阴影、所有箭头/上下标/拉回星推前下标星均齐；原请验证提示只保留未添答案。

指数(-1)^alpha按degreealpha理解，note001正确且未冒称必为误式。

118取p须在U1坐标域，原U/U1混用note002准确。

120原varphi(U)subsetV域不合，所列phi∘f∘varphi^-1需f(U)subsetV，note003正确；原phi(U)/plaininnerU保留。

143源锚，17原号，6原图组。无待修。源码实bytes与全文存JSON；非最终PDF版式/导航/冷编批准。
