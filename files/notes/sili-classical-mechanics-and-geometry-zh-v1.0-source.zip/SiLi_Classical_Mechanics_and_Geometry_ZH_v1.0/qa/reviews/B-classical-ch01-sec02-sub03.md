# B独立源审：经典1.2.3

当前SHA `4fda6a70a0d6fdfd522dfef864699b943a88c3121ffd646050bcd8ea64481e8c` 批准。原14–19共6页实际2x逐页读，六原例1.2.2–1.2.7及所有中间式/无号评注/六图全核，未只核编号。

Original14-15: Example1.2.2allK/V/L/Newtonandfreeparticlederivatives; Example1.2.3allLorentzforce/charges/threecoordinates/scalarandvectorpotentialbullets/E-Bformulas/Ltwoforms; fullvelocitydependentV, bothEuler-LagrangederivativesincltotalA_i time3steps, exactallFi sumsandbothE/Binterpretations, finalforce; entireunnumbered1-formremarkandtrajectoryintegral retained.

Original15-16: Example1.2.4masslessspring/gravityparameters, K/Vwithheightnegativecoordinate/L/all3EulerLagrangesteps; springdiagram. Example1.2.5idealAtwoodassumptionsm1>m2/masslessinextensiblestring/frictionless, massesandlengthdiagram, allK/V/Lincludingwhole(l-x)derivative, equationandaccelerationinterpretation.

Original17-18: Example1.2.6allrotatingbeadgeometry/assumptions, theta=omegat/bothposition/bothvelocitycomponents, everyexpandedkineticterm/cancellation, V0/L/effectivecentrifugalpotential/force/ODE/bothexponentials/initialconditions/solveda,b/coshform/divergencelimit.

Original18-19: Example1.2.7disk/tabledropgeometry/masses/r/theta/l-r, bothkineticenergies/V/L, bothEulerLagrangecasesandresultingradial/angularcases, Jconstant, allreplacementsteps/effectiveforce/potential/equilibrium/rstar/frequency/noncircularorbit; allsixoriginalfiguresretained. CurrentfiveTikZfiguresprivatelycompiledandactuallyviewed; unchanged1-4andactualPDForbitviewcarriedbyspecificexactdelta, changed5recompiledand3xviewedcurrent.

两注独核：势耦合为1-form积分Q倍；J=0时径向力恒负而无正r平衡，频率式除J也需非零。原文与所有式保留。

稳定图真实几何偏移已关闭：原a2cf实际before仅3处几何替换到当前4fda，B独立构造expected与实际全文bytes相同；除图005外全部原文字节不动。当前图重新独立编译并3x实看，r_*虚线、唯一水平最低点和箭头精确同点。其余五图均已看，最终整书PDF分页另验。
