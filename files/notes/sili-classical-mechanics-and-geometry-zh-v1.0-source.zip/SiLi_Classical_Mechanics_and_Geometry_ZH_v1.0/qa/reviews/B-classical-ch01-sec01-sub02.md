# Classical1.1.2 source review and missing-figure closure

Approved by nonauthorB at exact currentSHA `e9cef25540d2781fe706eeec8e4e03bc0430d166786e856ee874cbb962c538c9`. Actual source physical8 and9 before1.1.3 were viewed individually at2x. Text, all formulas, qualifiers and original footnote3 match.

The initially missing two author illustrations onphysical9 are now present within1.1.2: rolling hill-ball with direction arrow and parabolic projectile trajectory. B read the actual newTikZ and exact before/current diff; original noncomment body is unchanged. The original088422 before remains preserved. FindingB-CL-1.1.2-001 is closed. Actual translatedPDF diagram rendering/layout remains a later separate acceptance.
