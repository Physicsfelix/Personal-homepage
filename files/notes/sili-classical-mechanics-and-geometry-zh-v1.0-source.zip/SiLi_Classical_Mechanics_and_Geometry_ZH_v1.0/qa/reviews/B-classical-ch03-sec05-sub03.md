# B 独立源审 ch03-sec05-sub03

批准当前SHA `2ab2ba5b5b4340a8934fc4a135177c9ebf841fee84bceb7e18863e8269bdfc9c`。实际物[122]全部相关原页逐幅2x读并与current TeX逐段式比对。

Lagrange子流形定义与半维条件、切空间线性等价、全R^n图参数化、pullback闭性→exact→生成函数每步全保。

本例定义域整个R^n，Poincare全局exact步骤成立；末一般Darboux局部形式按可选适合坐标理解，无额外改注。无图/脚注/新增答案。

15源锚，2原号，0原图组。无待修。源码实bytes与全文存JSON；非最终PDF版式/导航/冷编批准。
