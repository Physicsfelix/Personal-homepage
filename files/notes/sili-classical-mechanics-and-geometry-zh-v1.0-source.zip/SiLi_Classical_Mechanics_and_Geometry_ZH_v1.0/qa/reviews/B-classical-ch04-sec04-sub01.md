# Classical ch04-sec04-sub01 独立源审

B 对 A 译稿，当前 SHA `8f5a45be926f7527fa52f3bf64b1fb6c16b47c37a6fe6d98c127d45dcdec006d`，approved。

实际原页：[150, 151]，每全页2x，逐段式及全部原编号/证明/注核验。

Toda链模型/H/四行Hamilton方程/Flaschka变量/边界约定/H(a,b)/全部Poisson与Casimir例完整；L/A所有格、命题及n3全乘积和差矩阵每项完整。

原force图所有粒子/两箭头/轴向与数学标记完整，force改力，currentPDF3x实际看。独立重新符号相乘n3交换子吻合全部原格。

原q作指数底确可见；由H求导内点项应e^(qi−q(i+1))，现注正确，原式保持。

不据此签署合编译本 PDF 最终版式。