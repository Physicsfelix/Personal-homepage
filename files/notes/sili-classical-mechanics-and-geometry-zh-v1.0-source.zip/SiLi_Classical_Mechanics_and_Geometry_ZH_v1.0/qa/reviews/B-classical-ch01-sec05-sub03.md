# B 独立源审 ch01-sec05-sub03

批准当前 SHA256 `73195a4349c55f2c362537c0db96432878ef14b016f6d27510ca69802ba4ec61`。原41,42全部相关页实际逐幅2x读，全文逐段逐式核；所有原作者式与无号段保全，无原题解增写。当前字节与我首次完整审读身份精确一致。无未修项；正式全书PDF版式另验。

Original41fulltripleproductangularmomentum/I-Omegarelationretained.

Original42fullspace-conservedJ/bodyframecomponents distinction, basis-motionterm, vectorcomponentcontractionandthreeEulerrowssignsallmatchsource.

Nooriginalproof/answeromittedornewoneinserted; sourceLagrangianwrittenKandunarrowedOmega atintermediaterowpreserved.
