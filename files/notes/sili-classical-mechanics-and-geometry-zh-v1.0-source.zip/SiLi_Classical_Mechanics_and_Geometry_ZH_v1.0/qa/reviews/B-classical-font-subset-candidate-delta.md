# B 六项 Classical 字体子集候选独立差分审

批准清单中六份actual候选字节，审者未应用替换。独立读book/assets当前及qa候选，逐页6页盒/rotation/全文/逐字坐标、字号、色值、方向、flags/3xRGB严格相同。没有引用root equal布尔代替复算，也未冒称本轮重读原数学。

实际另发现字体元数据名从FandolSong-Regular变为FandolSong Regular；原始fontname不相等，已明确记录，未用它冒充逐字像素差异。所有字形在3xRGB实测严格同一。

book/assets/cl-p0058-divergence-volume.pdf：`af35de3800d23589f7718f93b7f317accd44e7654bc5c9a97b21cef15d33e9e1` → `beb3929a335fc3d006551095cd235cc46ea53eb65f6b80ac7b55c33f168df789`

book/assets/cl-p0062-recurrence.pdf：`8fe636a2e40500c8119691deb4695e7dbcf87a561126f5c4758cc5d73b03a57f` → `7658bbb8457af409d672992bf57296f4eacbaf5746de3b1daf537a4115865981`

book/assets/cl-p0070-phase-lift.pdf：`33fa1549df8af2a058ba2ddb5f4d2318eae18db86d11947d7178a8e9ba1b9c67` → `e6d663b82ddeba8d3747f86adee462d4cc1b2b915993413f9ee225179df51843`

book/assets/cl-p0073-plane-wavefront.pdf：`093ead6bd562f0eb2b3f5f1251d3e0e2d88d87946ab1d5bdc919abf347ed6501` → `3a98dd89402f15e24dad87866ebd1b359484069b235b0a1cd004e22677340ce7`

book/assets/cl-p0073-spherical-wavefront.pdf：`72b8ae28a5dcfbf3f796ec4731714cae073e8ea936d5cb3df226cc05ccc94f95` → `d701017bed82e78cb49c8e839c392a047cc143d89eab3ef93cc81f7318611fb1`

book/assets/cl-p0078-wavefront-ray.pdf：`c0d72e009cc32a90f4940ee9318c1afdb2a06498080ed2e34dc3e41cf9915c1d` → `55e9e96d97ee9ed4a4cbf3c4cc8231373b3cddffb74b671d4ca7713285ee5dae`

24779143 → 1459017 bytes，减少23320126 bytes。root可按逐字候选替换，替换后登记actual currentSHA；原74内容文件身份未动。

旧语义资产身份补闭：六actualbeforeSHA均独立命中B先前实看时保存的 qa/B-Liouville-assets/actual-assets.json、qa/B-HJ-assets/actual-assets.json 或 qa/B-optics-assets/actual-assets.json（逐项见JSON），原来源/实看证据可按真实旧bytes承接到本次严格等像素候选。
