ch03-sec02-intro：B独立源审批准

当前SHA `ac4c35ba1dc62abb798d7f43ac80e40086ab7826ae9107c135df390b21a37e57`。

- 源3.2仅标题完整，未增导语。

无待修项；最终PDF另验。
