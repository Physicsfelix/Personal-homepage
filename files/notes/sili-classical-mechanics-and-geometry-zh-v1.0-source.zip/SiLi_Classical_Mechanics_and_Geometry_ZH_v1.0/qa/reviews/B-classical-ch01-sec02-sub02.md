# B独立源审：经典ch01-sec02-sub02

当前SHA `d6bcba819c9c3ef0f2bb941a9ba44c84eccd31347e4206ac6f2904c5771d4f01` 批准。原件 `494811e67828f9f6b3db8cbc1e975f52c0133621254ae8a0a9372555bedd01fb`，实际源页13,14逐2x读。

Original13: completetotaldifferentialdf=f_x dxwithinfinitesimalmeaning; pathspacefrakXall smoothqintervaltoRn, Smap/Xinfinitedimensionalprose, deltaqandtotaldeltaS; everymapandbothvariationintegralstepsincludingendpointterm.

Source14: fixedendpointdeltas0, EulerLagrangeconclusion, fullTheorem1.2.1crossreference andclosingrigor-versus-artparagraphretained.

CurrentTikZ fcurvewithaxes/f/twodottedverticalsdx; independentlycompiledexactcurrentTikZ andactualtestPDFp2viewed2xagainstoriginal.

CurrentTikZ pathspacevariationq/q+deltaq withcommonendpointsanddots, independentlycompiledexactcurrentcode andactualtestPDFp3viewed2xagainstsource13.

全部段、式与证明中间行完整。无原脚注/题项漏失，无新增译校注。

图另用实际当前TikZ编私有3页测试并逐图看，不冒称正式整书PDF分页/导航通过。
