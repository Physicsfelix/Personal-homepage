# B 独立源审 ch01-sec03-intro

批准当前 SHA256 `ad676102317d9a949dddd3330f0bd041052d9956572d365b8642b261a419bbab`。源物理 22 全页实际2x读图，对照完整当前TeX逐段逐式核对。编号、原脚注与无号段完整；无待修项。全书实际排版另验。

Full source section title, principle continuous symmetry→conservation law boxed display, and both introductory sentences retained.
