# B独立源审：经典ch01-sec02-intro

当前SHA `171d58fedebd6127731169de1030ef802c2cb0829d5f76156df2c9d0b6b96588` 批准。原件 `494811e67828f9f6b3db8cbc1e975f52c0133621254ae8a0a9372555bedd01fb`，实际源页11逐2x读。

Original1.2headingonly, noinventedintroduction; physical11printed10boundaryafterleverdiagramandbefore1.2.1 preserved.

全部段、式与证明中间行完整。无原脚注/题项漏失，无新增译校注。

图另用实际当前TikZ编私有3页测试并逐图看，不冒称正式整书PDF分页/导航通过。
