# 李思《经典力学与几何》全范围来源清单 A

来源盘点完成，非数学或译文批准。实际原件161页、872238字节，SHA256 `494811e67828f9f6b3db8cbc1e975f52c0133621254ae8a0a9372555bedd01fb`。封面July2023 preliminary draft；前言署静斋、Jan1,2023。正文英文，中文题名与姓名；不是已有完整中译。

实际查看：161页全页概览；封面、反馈页、三页目录、前言、末正文与两页书目单页；全部83个节/小节正文起点2倍裁图；9作者脚注全部2倍。边界以正文原标题/原句/下一单元起点及坐标核，未只凭目录和正则声称逐段数学审过。

4章、22节、61小节、17参考文献，无附录和索引。92原子槽包括4章引导区、22节引导区、61小节、前后置5项；73项有实质文字。章1/2/4无导语文字，仅标题；章3有导语。节导语仅1.3/1.4/1.5/2.4/2.6/3.6；其余不能凭空添写。封面无可见页码，物2–161印1–160。

| 单元 | 原标题 | 物理页 | 印页 | 目标文件 |
|---|---|---|---|---|
| ch01-intro | Lagrangian Mechanics | 7–7 | 6–6 | book/chapters/ch01-intro.tex |
| ch01-sec01-intro | Principle of Least Action | 7–7 | 6–6 | book/chapters/ch01-sec01-intro.tex |
| ch01-sec01-sub01 | Newtonian Mechanics | 7–8 | 6–7 | book/chapters/ch01-sec01-sub01.tex |
| ch01-sec01-sub02 | Action Functional | 8–9 | 7–8 | book/chapters/ch01-sec01-sub02.tex |
| ch01-sec01-sub03 | Principle of Least Time | 9–10 | 8–9 | book/chapters/ch01-sec01-sub03.tex |
| ch01-sec01-sub04 | Principle of Minimum Energy | 10–11 | 9–10 | book/chapters/ch01-sec01-sub04.tex |
| ch01-sec02-intro | Euler-Lagrange Equation | 11–11 | 10–10 | book/chapters/ch01-sec02-intro.tex |
| ch01-sec02-sub01 | Calculus of Variations | 11–13 | 10–12 | book/chapters/ch01-sec02-sub01.tex |
| ch01-sec02-sub02 | Comparison with Calculus | 13–14 | 12–13 | book/chapters/ch01-sec02-sub02.tex |
| ch01-sec02-sub03 | Examples | 14–19 | 13–18 | book/chapters/ch01-sec02-sub03.tex |
| ch01-sec02-sub04 | Plane Motion with Central Force | 20–22 | 19–21 | book/chapters/ch01-sec02-sub04.tex |
| ch01-sec03-intro | Noether’s Theorem | 22–22 | 21–21 | book/chapters/ch01-sec03-intro.tex |
| ch01-sec03-sub01 | Infinitesimal Symmetry | 22–23 | 21–22 | book/chapters/ch01-sec03-sub01.tex |
| ch01-sec03-sub02 | Noether’s Theorem | 23–25 | 22–24 | book/chapters/ch01-sec03-sub02.tex |
| ch01-sec03-sub03 | Energy, Momentum, and Angular Momentum | 25–26 | 24–25 | book/chapters/ch01-sec03-sub03.tex |
| ch01-sec04-intro | Kepler Problem | 27–27 | 26–26 | book/chapters/ch01-sec04-intro.tex |
| ch01-sec04-sub01 | Harmonic Oscillator | 28–29 | 27–28 | book/chapters/ch01-sec04-sub01.tex |
| ch01-sec04-sub02 | The Inverse Square Law | 29–33 | 28–32 | book/chapters/ch01-sec04-sub02.tex |
| ch01-sec04-sub03 | Laplace-Runge-Lenz Vector | 33–35 | 32–34 | book/chapters/ch01-sec04-sub03.tex |
| ch01-sec05-intro | Rigid Body | 35–36 | 34–35 | book/chapters/ch01-sec05-intro.tex |
| ch01-sec05-sub01 | Angular Velocity | 36–38 | 35–37 | book/chapters/ch01-sec05-sub01.tex |
| ch01-sec05-sub02 | Inertia Tensor | 38–41 | 37–40 | book/chapters/ch01-sec05-sub02.tex |
| ch01-sec05-sub03 | Euler’s Equation | 41–42 | 40–41 | book/chapters/ch01-sec05-sub03.tex |
| ch01-sec05-sub04 | Free Tops | 42–44 | 41–43 | book/chapters/ch01-sec05-sub04.tex |
| ch01-sec05-sub05 | Euler’s Equation in Lax Form | 44–46 | 43–45 | book/chapters/ch01-sec05-sub05.tex |
| ch02-intro | Hamiltonian Mechanics | 47–47 | 46–46 | book/chapters/ch02-intro.tex |
| ch02-sec01-intro | Hamilton’s Equations | 47–47 | 46–46 | book/chapters/ch02-sec01-intro.tex |
| ch02-sec01-sub01 | Hamilton’s Equations | 47–50 | 46–49 | book/chapters/ch02-sec01-sub01.tex |
| ch02-sec01-sub02 | Legendre Transform | 50–51 | 49–50 | book/chapters/ch02-sec01-sub02.tex |
| ch02-sec02-intro | Poisson Bracket | 52–52 | 51–51 | book/chapters/ch02-sec02-intro.tex |
| ch02-sec02-sub01 | Phase Space and Poisson Bracket | 52–53 | 51–52 | book/chapters/ch02-sec02-sub01.tex |
| ch02-sec02-sub02 | Constant of Motion | 54–55 | 53–54 | book/chapters/ch02-sec02-sub02.tex |
| ch02-sec03-intro | Liouville’s Theorem | 56–56 | 55–55 | book/chapters/ch02-sec03-intro.tex |
| ch02-sec03-sub01 | Phase Flow and Liouville’s Theorem | 56–60 | 55–59 | book/chapters/ch02-sec03-sub01.tex |
| ch02-sec03-sub02 | Liouville’s Equation | 60–61 | 59–60 | book/chapters/ch02-sec03-sub02.tex |
| ch02-sec03-sub03 | Poincaré’s Recurrence Theorem | 61–62 | 60–61 | book/chapters/ch02-sec03-sub03.tex |
| ch02-sec04-intro | Canonical Transformation | 62–62 | 61–61 | book/chapters/ch02-sec04-intro.tex |
| ch02-sec04-sub01 | Time-independent Canonical Transformation | 62–64 | 61–63 | book/chapters/ch02-sec04-sub01.tex |
| ch02-sec04-sub02 | Infinitesimal Canonical Transformation | 65–65 | 64–64 | book/chapters/ch02-sec04-sub02.tex |
| ch02-sec04-sub03 | Time-dependent Canonical Transformation | 66–69 | 65–68 | book/chapters/ch02-sec04-sub03.tex |
| ch02-sec05-intro | Hamilton-Jacobi Equation | 69–69 | 68–68 | book/chapters/ch02-sec05-intro.tex |
| ch02-sec05-sub01 | Extremal Action and Hamilton-Jacobi Equation | 69–74 | 68–73 | book/chapters/ch02-sec05-sub01.tex |
| ch02-sec05-sub02 | Canonical Transformation via Hamilton-Jacobi | 74–75 | 73–74 | book/chapters/ch02-sec05-sub02.tex |
| ch02-sec06-intro | Geometric Optics | 75–75 | 74–74 | book/chapters/ch02-sec06-intro.tex |
| ch02-sec06-sub01 | Eikonal Equation | 76–77 | 75–76 | book/chapters/ch02-sec06-sub01.tex |
| ch02-sec06-sub02 | Wavefront | 77–78 | 76–77 | book/chapters/ch02-sec06-sub02.tex |
| ch02-sec06-sub03 | Maxwell Fisheye | 78–80 | 77–79 | book/chapters/ch02-sec06-sub03.tex |
| ch03-intro | Interlude of Symplectic Geometry | 81–81 | 80–80 | book/chapters/ch03-intro.tex |
| ch03-sec01-intro | Vector Field and Differential Form | 81–81 | 80–80 | book/chapters/ch03-sec01-intro.tex |
| ch03-sec01-sub01 | Vector Field | 81–87 | 80–86 | book/chapters/ch03-sec01-sub01.tex |
| ch03-sec01-sub02 | Differential Form | 87–91 | 86–90 | book/chapters/ch03-sec01-sub02.tex |
| ch03-sec01-sub03 | Lie Derivative | 91–93 | 90–92 | book/chapters/ch03-sec01-sub03.tex |
| ch03-sec01-sub04 | Stoke’s Theorem | 93–98 | 92–97 | book/chapters/ch03-sec01-sub04.tex |
| ch03-sec02-intro | Cartan Formula and Poincaré Lemma | 98–98 | 97–97 | book/chapters/ch03-sec02-intro.tex |
| ch03-sec02-sub01 | Cartan Formula | 98–100 | 97–99 | book/chapters/ch03-sec02-sub01.tex |
| ch03-sec02-sub02 | Poincaré Lemma | 101–103 | 100–102 | book/chapters/ch03-sec02-sub02.tex |
| ch03-sec03-intro | Symplectic Form | 103–103 | 102–102 | book/chapters/ch03-sec03-intro.tex |
| ch03-sec03-sub01 | Symplectic Vector Space | 103–105 | 102–104 | book/chapters/ch03-sec03-sub01.tex |
| ch03-sec03-sub02 | Symplectic Form | 105–108 | 104–107 | book/chapters/ch03-sec03-sub02.tex |
| ch03-sec03-sub03 | Darboux Theorem | 109–110 | 108–109 | book/chapters/ch03-sec03-sub03.tex |
| ch03-sec04-intro | Geometry of Canonical Transformations | 110–110 | 109–109 | book/chapters/ch03-sec04-intro.tex |
| ch03-sec04-sub01 | Canonical Transformation Revisited | 110–112 | 109–111 | book/chapters/ch03-sec04-sub01.tex |
| ch03-sec04-sub02 | Poincaré’s Integral Invariant | 112–113 | 111–112 | book/chapters/ch03-sec04-sub02.tex |
| ch03-sec05-intro | Symplectic Manifold | 113–113 | 112–112 | book/chapters/ch03-sec05-intro.tex |
| ch03-sec05-sub01 | Smooth Manifold | 113–121 | 112–120 | book/chapters/ch03-sec05-sub01.tex |
| ch03-sec05-sub02 | Symplectic Manifold | 121–122 | 120–121 | book/chapters/ch03-sec05-sub02.tex |
| ch03-sec05-sub03 | Lagrangian Submanifold | 122–122 | 121–121 | book/chapters/ch03-sec05-sub03.tex |
| ch03-sec06-intro | Moment Map | 122–122 | 121–121 | book/chapters/ch03-sec06-intro.tex |
| ch03-sec06-sub01 | Lie Group and Lie Algebra | 123–126 | 122–125 | book/chapters/ch03-sec06-sub01.tex |
| ch03-sec06-sub02 | Moment Map | 126–130 | 125–129 | book/chapters/ch03-sec06-sub02.tex |
| ch03-sec06-sub03 | Symplectic Reduction | 130–133 | 129–132 | book/chapters/ch03-sec06-sub03.tex |
| ch04-intro | Integrable System | 134–134 | 133–133 | book/chapters/ch04-intro.tex |
| ch04-sec01-intro | Liouville Integrability | 134–134 | 133–133 | book/chapters/ch04-sec01-intro.tex |
| ch04-sec01-sub01 | Liouville Integrability and Liouville Tori | 134–136 | 133–135 | book/chapters/ch04-sec01-sub01.tex |
| ch04-sec01-sub02 | Liouville-Arnol’d Theorem | 136–139 | 135–138 | book/chapters/ch04-sec01-sub02.tex |
| ch04-sec02-intro | Integrability of Kepler Problem | 139–139 | 138–138 | book/chapters/ch04-sec02-intro.tex |
| ch04-sec02-sub01 | Complete Integrability | 139–140 | 138–139 | book/chapters/ch04-sec02-sub01.tex |
| ch04-sec02-sub02 | Action-Angle Variables | 140–144 | 139–143 | book/chapters/ch04-sec02-sub02.tex |
| ch04-sec03-intro | Hamilton-Jacobi v.s. Liouville Integrability | 144–144 | 143–143 | book/chapters/ch04-sec03-intro.tex |
| ch04-sec03-sub01 | Local Complete Solution | 144–146 | 143–145 | book/chapters/ch04-sec03-sub01.tex |
| ch04-sec03-sub02 | Integrability via Hamilton-Jacobi Theory | 146–149 | 145–148 | book/chapters/ch04-sec03-sub02.tex |
| ch04-sec04-intro | Toda Lattice | 150–150 | 149–149 | book/chapters/ch04-sec04-intro.tex |
| ch04-sec04-sub01 | Toda Equations in Lax Form | 150–151 | 149–150 | book/chapters/ch04-sec04-sub01.tex |
| ch04-sec04-sub02 | Integrability of Toda Lattice | 152–154 | 151–153 | book/chapters/ch04-sec04-sub02.tex |
| ch04-sec05-intro | Calogero-Moser System | 154–154 | 153–153 | book/chapters/ch04-sec05-intro.tex |
| ch04-sec05-sub01 | Calogero-Moser Space via Symplectic Reduction | 154–157 | 153–156 | book/chapters/ch04-sec05-sub01.tex |
| ch04-sec05-sub02 | Integrability of Calogero-Moser System | 157–159 | 156–158 | book/chapters/ch04-sec05-sub02.tex |
| front-cover | Classical Mechanics and Geometry / 经典力学与几何 | 1–1 | None–None | book/matter/cover.tex |
| front-feedback | Author feedback, QR and homepage | 2–2 | 1–1 | book/matter/front-support.tex |
| front-contents | Contents | 3–5 | 2–4 | book/matter/front-contents.tex |
| front-preface | Preface | 6–6 | 5–5 | book/matter/front-preface.tex |
| back-bibliography | Bibliography | 160–161 | 159–160 | book/matter/bibliography.tex |

辅助盘点：163编号对象标题（定义47、命题28、例68、定理16、引理3、推论1）；8显式Exercise任务；9作者脚注；92个插图/图式组（可能多面板）；5表组；16无编号内部小标题。详表在JSON，不以盘点代替后续逐段逐式独审。

脚注1/2在物8归1.1.1、3归1.1.2；物23脚注4归1.3.1，虽排在1.3.2下方。其他为物24/25/27章1注5/6/7，物67/68章2注1/2。它们是独立归属的页尾部件，不能按连续矩形简单切给下一小节。

所有原图均无编号图题；页眉/背景求真徽标属于装饰，不计正文图。数学文本提取有数组、分式、向量/重音、私用字符和括号控制符失真。公式、图和脚注以后实际原页为准；本阶段没有批准数学正确性。

书内仅作者反馈表、主页、邮箱，未发现.tex链接；未执行书内反馈或联系指令。已查[作者主页正文](https://sili-math.github.io/bodypg22.htm)、[作者教学页](https://sili-math.github.io/teachingpage.htm)及官方主页GitHub HTML，没有明确源码链接。仓库递归API403限额，故不宣称全库没有源码。当前[官方PDF](https://sili-math.github.io/notes/Lecture-Classical-Mechanics.pdf)仅6页节选，后段目录页码也与此161页完整版不同，不能替换或静默换版；未使用外部tex。

安全并行：前置物1–6、章1物7–46、章2物47–80、章3物81–133、章4物134–159、书目物160–161。节内共享页按JSON坐标/原句及明确脚注归属，避免整页重复或遗漏。按root新授权由A完整翻译classical、B独审，开始流式交审；公共宏归root。

B独立补核：1.1.2的完整材料延至物9标题前，两幅无文字图像不可因原生文字末行在物8而漏掉；JSON范围已按全部可见图像组件扩展。


2026-10-26逐段译制更正：物25原脚注6的真实上标挂在定理1.3.4作用量之后，归属1.3.2（ch01-sec03-sub02）；不能按页下位置误归1.3.3。原脚注总数仍9。JSON已更正。
