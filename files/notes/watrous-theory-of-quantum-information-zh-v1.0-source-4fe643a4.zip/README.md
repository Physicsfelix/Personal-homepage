# 量子信息理论：中文译排源码

原著：John Watrous, *The Theory of Quantum Information*，用户提供的2018年出版前草稿，共598张原始物理页。本源码完整涵盖原封面说明、两张真实空白页、目录、前言、八章正文、全部习题及提示、参考文献、记号表和索引，保留原编号与作者约定；原文问题以独立的“译校注”说明。

正文按用户提供的“泛函分析I”模板作视觉复原。当前候选PDF为478页；原页与译页对应见 `qa/source-page-map.json` / `.csv`。索引和记号表中的原书页码已转换成当前译本相应内容的实际页码或页码区间，并带内部链接。

## 编译

安装包含中文字体和常用宏包的TeX Live（本次验证环境为TeX Live2026），保证XeLaTeX和latexmk在系统路径中。在PowerShell运行 `./build.ps1`；也可从任意目录通过完整路径调用此脚本。输出为 `build/main.pdf`。

也可在此目录运行：

```
latexmk -norc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
```

字体使用TeX Live内附Fandol，不依赖本机私人字体。无需原书PDF、扫描缓存、工作区或本机图片路径。全部378个实际编译输入和所用插图均已包含。

全部原文单元已由非作者独立审校，全部实际编译输入身份见 `qa/current-accepted-inputs.json`。最终实际ZIP的独立技术审核回执与发布信息外附于正式交付记录，避免在ZIP内部自引用其最终哈希。源文件、语义审校、整书版面导航和源码包验收分别记录；不以编译成功代替逐节独立审校。
