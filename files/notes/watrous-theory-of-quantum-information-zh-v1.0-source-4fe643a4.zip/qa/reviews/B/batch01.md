# Watrous batch01 — Independent reviewer B

Result: **approved** for all five exact current TeX files and the stated source ranges. AuthorA did not review their own work; reviewerB did not write these files.

Source SHA-256: `992de30011ff2ec70994256d6ad5f3a93f250a6f0d08fa4314bd0c9ea5156a36` — January2018 pre-publication draft,598 physical pages.

## Source review performed

Independently rendered at1.55x and individually viewed original physical pages1,7–16. Read all five TeX files in full and compared every paragraph, condition, formula and continuation against visible originals. Examined equations1.1–1.31,Proposition1.1,all3 unnumbered Remark paragraphs,all6 internal subheadings,footnote1,all11 preface acknowledgement names,title/affiliation/publication notice and author/date. No proof was invented for the reference-only chapter.

- Physical1: Complete title/author/affiliation/copyright/Cambridge planned publication and personal-use/no-sale/no-redistribution draft notice; all source information retained.
- Physical7: All3 preface paragraphs; audience, excluded fields, motivation and Schrödinger/building-device statements retained.
- Physical8: All5 paragraphs, all11 acknowledgement names,2 funding bodies, author/location/date retained; notation and exercise caveats faithful.
- Physical9: Complete chapter opening,1.1 opening,1.1.1 opening and first unnumbered heading; alphabet sentence continues correctly to physical10.
- Physical10: All alphabet/vector-space constructions,2 operations,notation paragraph,footnote1,equations1.1–1.2; continuation to physical11 retained.
- Physical11: Equations1.3–1.8 and every condition; conjugate is on u(a) in1.5,second-variable linearity in1.6,full swapped-inner-product conjugation in1.7; all match visible source.
- Physical12: Equations1.9–1.14,3 norm axioms,Cauchy–Schwarz equality criterion,unit sphere,p norms,range[1,infinity],orthogonality definitions. Inline subset symbol restored and rechecked in delta.
- Physical13: Equations1.15–1.19,orthonormal basis iff cardinalities match,disjoint-union coordinate definition and unique direct-sum representation; all retained.
- Physical14: Equations1.20–1.28,coordinate tensor definition,bilinearity/product inner product,Kronecker alternative,Proposition1.1 start. Separate qualification note now independently checked and approved.
- Physical15: Proposition1.1 continuation1.29–1.30,unique linear map and all quantifiers;1.31; all3 unnumbered Remark paragraphs; real-space paragraph across boundary.
- Physical16: Both real-space continuation paragraphs retained before1.1.2 heading; correct exclusion of1.1.2. Source16 End intentionally remains with next subsection.

## Findings and exact delta closure

B-WAT-01 is closed. Original tensor sentence remains verbatim; a separate SourceError states the nonzero-factor qualification and one-factor/dimension-one degeneracies. Its mathematics is independently verified: choose bases in1-dimensional factors to prove every vector is simple when at most one factor is higher-dimensional. With two higher-dimensional factors, choose independent pairs and sum matching tensors; a2x2 flattening coefficient submatrix has determinant1 and rank2, whereas an elementary tensor has flattening rank at most1. Thus the threshold is both necessary and sufficient.

B-WAT-02 is closed. The single inline general-subset glyph is restored from subseteq to the visible source subset glyph.

Actual new subsection bytes equal A’s submitted after-file. Reversing precisely the added SourceError line and that one subset replacement reproduces every byte of the previously reviewed file. The other four files and their approved snapshots remain byte-identical. New subsection SHA-256: `eda4a02dfebf37b27a94c65772de1a437c1ec7df569e22bf9aec0759b434b942`. Original physical12/14 were re-opened for the delta; physical9/10 nonempty-factor evidence remains the previously actually inspected unchanged source.

## Final rendering evidence

Initial preview8 pages were all individually viewed. Final preview SHA-256: `366f7505bc01c3101b960baaf1bb1140df0fb1e530afa3ec0ff10393314a1ef8`. Independently compared reviewer-rendered old/new PNGs: pages1,2,3,4,6 are pixel-identical; changed pages5,7,8 were individually re-rendered and viewed. No changed source formula or omitted continuation was found. Layout/compile evidence does not replace the source comparison.

## Current file-bound approvals

| Unit | Current approved SHA-256 | Actual approved-byte snapshot |
|---|---|---|
| title | `7e850507923bdfb867807a330bf7c435893cfe02c9e5661da9c7033f6884add1` | `qa\approved-bytes\B\7e850507923bdfb867807a330bf7c435893cfe02c9e5661da9c7033f6884add1\book\matter\title.tex` |
| preface | `0c09204e743e0a5a6e45abf3f74b96b8c93768636a22188920461ba7aa760345` | `qa\approved-bytes\B\0c09204e743e0a5a6e45abf3f74b96b8c93768636a22188920461ba7aa760345\book\matter\preface.tex` |
| chapter-1-opening | `c5bb4c83cd1bebed40fec6307d61251254bc36e64f92bea0e51aa7f3add1d479` | `qa\approved-bytes\B\c5bb4c83cd1bebed40fec6307d61251254bc36e64f92bea0e51aa7f3add1d479\book\chapters\ch01-intro.tex` |
| section-1.1-opening | `305b40e55a793e25e8ad8102f59eea6af881242e7a316ea5b2a7eed7697d7b51` | `qa\approved-bytes\B\305b40e55a793e25e8ad8102f59eea6af881242e7a316ea5b2a7eed7697d7b51\book\chapters\ch01-sec01-intro.tex` |
| subsection-1.1.1 | `eda4a02dfebf37b27a94c65772de1a437c1ec7df569e22bf9aec0759b434b942` | `qa\approved-bytes\B\eda4a02dfebf37b27a94c65772de1a437c1ec7df569e22bf9aec0759b434b942\book\chapters\ch01-sec01-sub01.tex` |

Source9 is correctly shared between chapter opening and subsection. Source16 Start belongs to this subsection, while End belongs later in1.1.2 at the true source page end. That expected interface is accepted, not an omission.

Initial needs-revision history remains in batch01-v1-needs-revision.json. This approval covers only these exact five files/source ranges. Full-book inclusion,pagination,cold rebuild and final packaging remain separate gates. ReviewerB changed no translation,macro,original source,or shared style.
