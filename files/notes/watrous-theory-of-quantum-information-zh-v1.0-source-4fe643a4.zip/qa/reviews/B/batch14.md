# Watrous batch14 独立审校 B

结论：两单元 approved。源物108的2.3标题起，至物113命题2.38证明末、2.3.2标题前；6张完整原页与4张当前译页均实际逐段看图核过。

2定义2.34/35、命题2.36/38、定理2.37共5对象，17式2.199–215、3完整证明、2无号小标题、两套两项列表及全部普通段落完整；原无脚注、图或SourceError，未补造。

- **Probability/measurement convention**：All PSD measurement effects sum to I. Independently Tr(mu rho)=Tr(sqrt(mu)rho sqrt(mu))>=0, and total probability=Tr rho=1. All two operational list items retained, including author destructive measurement convention: measured register has no defined state and cannot be reused; not converted into a claim about pure states. Nondestructive alternative and channel-composition interpretation fully retained.
- **Prop2.36**：Density operators complex-linearly span L(X): PSD spectral decompositions span Hermitian operators, and X=H+iK spans general operators. Hence agreement Phi=DeltaPhi on all density operators extends to all operators. Both original directions complete.
- **Thm2.37 forward/uniqueness**：Second-slot-linear product gives<Eaa,Phi(X)>=<Phi*(Eaa),X>. Phi* positive from PSD selfduality, and TP implies adjoint unital, so mu(a)=Phi*Eaa forms a measurement. Uniqueness follows from linear independence of diagonal Eaa then nondegeneracy of the Hilbert–Schmidt product for every X. Both complementary quantified theorem clauses and full proof steps retained.
- **2.213/214 conjugation**：Actual physical112 bars viewed and compared. Since mu Hermitian, coefficient Tr(mu Eij)=mu(j,i)=conjugate(mu(i,j)); row-major Choi has input factor mu^T=conjugate(mu), not mu. Independent witness mu0=(1/2)[[1,i],[-i,1]],mu1=I-mu0 are PSD effects; the E01 coefficient for output0 is-i/2, while omitting the bar gives+i/2. Each conjugate effect is PSD and summing them gives conjugate(I)=I, proving CP/TP; diagonal output proves QC.
- **Prop2.38 compact convex**：Delta squared=Delta gives DeltaPsi QC for every channel; any QC Phi is in the image by choosing Psi=Phi. The map L:Psi->DeltaPsi is linear and continuous, so compactness and convexity both follow from source Prop2.28. Source final paragraph mentions continuity only, but displayed L is explicitly linear; no erroneous blanket claim about arbitrary continuous maps or gratuitous SourceError introduced.

Start108由C审前批13提供，本批闭End108；Start113在本批，End113留2.3.2真正原页末。此接口并非漏页。独立2遍冷编退出0无问题，全部4页几何/文字/像素与作者当前PDF `37826ef714f3e9df4bf3eb7e1edd8eb50688a6465754832c18003ee4c920e3ed` 相同。旧B44及C4输入逐字等于各自真实批准快照；core与旧宏不变。

- `book/chapters/ch02-sec03-intro.tex`：`b464c1c39c050d8f06a7315ba545dfac1c3c313c8ba9d7cface580ef75591b47`；真实快照 `qa\approved-bytes\B\b464c1c39c050d8f06a7315ba545dfac1c3c313c8ba9d7cface580ef75591b47\book\chapters\ch02-sec03-intro.tex`。
- `book/chapters/ch02-sec03-sub01.tex`：`8815ebdbe966326a7a1c5f208bebb94f46c0252937857b79fa61cf4d6eee943b`；真实快照 `qa\approved-bytes\B\8815ebdbe966326a7a1c5f208bebb94f46c0252937857b79fa61cf4d6eee943b\book\chapters\ch02-sec03-sub01.tex`。

未发现待修项；本记录不代全书验收。
