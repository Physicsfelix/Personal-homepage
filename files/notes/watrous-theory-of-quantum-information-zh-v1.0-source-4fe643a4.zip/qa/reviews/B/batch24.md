# Watrous batch24：B独立审校

**完整3.3导语及完整3.3.1当前两文件均 approved。** 原172–174三整页实际看图，共享174下3.3.2只作后界。当前两译页全实际看；12式3.220–231、情景3.35全部条件/两项行动、例3.36完整Werner–Holevo计算/论证及末完整段落逐段核。原无新脚注/图/正式证明环境/译校注。

- **3.3 opening andScenario3.35/strategies**：Wholetrace-norm/state-discrimination/CBtrace-norm/channel-discrimination opening retained. All registers/channelknowledge/priorlambda/twoAliceactions/Bobgoal match source172. Bobpreparesinput first, Aliceappliesrandomchannel, BobmaykeepancillaW andjointlymeasureY,W; orderandknowledgeunchanged. Weightednorm3.220is theHolevoHelstromsuccessobjective up to affinefactor, general strategy3.221hasPhi onXonly/identityonW. Every explanatory paragraph andterminalnecessityparagraph retained.

- **Example3.36 CP/TP and prior**：n>=2 ensures n+/-1 positive. TrPhi0X=(nTrX+TrXT)/(n+1)=TrX and minus analog. Choi transposemap is swapW=sumEab tensorEba, W*=W,W²I so I+/-W PSD, giving bothCP. Withlambda(n+1)/(2n), traceparts cancel andtransposecoefficient1/n remains. Transpose preserves PSD/tracenorm, so norm1/n for everydensityinput, giving success<=1/2+1/(2n), equalto priorlambda. Noauxiliarystrategy claim beyondthisnorm/HHbound; bothoutputs are O(1/n)trace-normclose toI/n as stated.

- **Normalized maximally entangled tau/output states**：tau=(1/n)sumEab tensorEab=(vecI)(vecI)*/n isPSD rankone withtrace1, notswap/n. Partialtranspose onfirstfactor turnsit intoW/n, whilepartialtrace termgivesI tensorI/n. Thus outputs(I+/-W)/(n²+/-n) exactly. TrW=n, so bothnormalized; supports symmetric/antisymmetricorthogonal because(I+W)(I-W)=I-W²=0. Source3.230fullHilbertSchmidttrace expansion preserved.

- **All-prior perfect distinguishability3.231**：FororthogonalPSD traceoneoutputs rho0/rho1, spectrumoflambda rho0-(1-lambda)rho1 splitsnonnegative/negativeonsupports, so normlambda+(1-lambda)=1forEVERYlambda[0,1], includingendpoints. Sourceearlierfixedprior3.224usedonlyunassistedcomparison, finaluniversalquantifierretained. Bobprojectivemeasurementontoorthogonalsupports makeserror0, as sourceconcludes. No proof or mathematical annotationadded.

Start172在导语，End172/Start173绑定后让Alice首词、End173/Start174在任意/输入句界，End174留下一完整小节。既有A19情景宏在局部入口仅一次，不新增宏。两遍独编0，两页几何/文字/1.5倍像素匹配9a546e13…，18字体嵌，无缺字/溢出/未定义。旧B71+C11真实批准字节/core冻结。新两快照已落，B ledger73条。

- `book/chapters/ch03-sec03-intro.tex`：`5ecc6bedcf01e9ef19550400557ff8d2a1d89c7b7a1e23a837156649951eb351`。
- `book/chapters/ch03-sec03-sub01.tex`：`874fdeb3e7753d3e003530fce1a7a6c26a4a3798db51f077253ac1d55ef21ed0`。
