# Watrous 第三批：审者 B 独立审校

结论：**四份新增文件全部 approved，无未闭环问题。** 作者为 A，审者为 B；审者未撰写本批译文。

原件 SHA-256：`992de30011ff2ec70994256d6ad5f3a93f250a6f0d08fa4314bd0c9ea5156a36`。版本为 2018 年 1 月出版前草稿，共 598 个物理页。

## 实际核对范围

自行渲染并逐页查看原件物理页 32–43 的完整页图，另放大查看第 38 页极分解与第 39 页伪逆唯一性推导。第 43 页只核边界：其页顶已经是 1.2，整页没有本小节译文，未纳入本节源范围。实际译文范围是 32 页 1.1.3 标题至 42 页公式 (1.186) 末。

全部普通段落、52 式 (1.135)–(1.186)、3 个定理、2 个推论、8 个无编号小标题与全部列表均已逐段逐式对照原图。三条函数演算例子、零奇异值补零、以 2 为底的对数、Schmidt 共轭、六条 Schatten 性质、谱范数简写约定均保留；迹距离按作者约定不额外加入 1/2。

- 原物理 32（opening only）：Start exactly at1.1.3; decomposition/norm overview and entire spectral-theorem introductory paragraph retained; closes shared source32.
- 原物理 33（1.135–1.138）：Theorem1.3 distinct eigenvalues/nonzero projections/sum identity/uniqueness and ranks;Corollary1.4 orthonormal basis; every paragraph on eigenvectors,converse normality and alphabet reindexing.
- 原物理 34（1.139–1.143）：Nonunique rank-one spectral convention and wording;Theorem1.5 commuting normal pair with joint basis and both spectra;Jordan–Hahn spectral data and definitions ofP,Q.
- 原物理 35（1.144–1.148）：Complete Jordan–Hahn uniqueness conditionsP,Q>=0,PQ=0;normal functional calculus domain restriction;first power example,r>0,nonnegative eigenvalues,positive-integer consistency andunique PSD square root.
- 原物理 36（1.149–1.152）：Remaining2 scalar-function examples:arbitrary realpowers onpositive-definite domain andbase2log;Theorem1.6 nonzero rankr assumption;left/right singular vectors,ordering,formal nonzero definition andallzero-padding/zero-operator conventions.
- 原物理 37（1.153–1.156）：SVD/eigenvalue correspondence andleft/right eigenvector choices;normal-case reindexing;Corollary1.7 exactthin typesD inPd(Cr),U:Cr->X,V:Cr->Y,all3 nonzero/rank assumptions preserved.
- 原物理 38（1.157–1.160）：Bothpolar directions anddifferentP/W qualification;original W=VU* retained andseparate mathematical note independently audited;all3 pseudoinverse conditions,existence/projection explanation andall3 B/C comparison conditions.
- 原物理 39（1.161–1.164）：All4 rows andevery intermediate equality inuniqueness chain;B=C conclusion;full Schmidt via vec including conjugatedy_k andorthonormality ofconjugatedset;all3normaxioms andquantifiers.
- 原物理 40（1.165–1.172）：Schattenfinitep definition andp>=1,infinity max andlimit,pnorm ofsingularvector;properties1–4 include monotonicity,nonzero rank inequality,specialrank bounds,isometric domain/codomain conditions anddual exponent definition.
- 原物理 41（1.173–1.179）：Properties4–6 completed:dualmax,Hölder,ABC source/target types andsubmultiplicativity,adjoint/transpose/bar symmetry;specialnorms,spectralidentity andbare-norm convention,Frobeniusinnerproduct formula.
- 原物理 42（1.180–1.186）：Frobeniusentrynorm,trace definition,author trace-distance convention without1/2;unitarydualmax andentirepartialtracecontraction chain;rank2 Hermitianspectrum expression andallunit/nonnegative assumptions;actualpageend after1.186.
- 原物理 43（boundary only）：Viewed fullpage:1.2 Analysis,convexity,andprobabilitytheory starts attop. No1.1.3 content andno43markers belong tothisbatch.

## 极分解译校注的独立数学核验

已经回原物理第 37 页推论 1.7 核对：对于方算子，U、V 是从 C^r 到原空间的等距嵌入，不一定是酉同构。由 U*U=V*V=I_r，得到 (VU*)*(VU*)=UU*。当 0<r<n 时，UU* 的秩是 r，因此不等于 I；所以原文直接把 VU* 称为酉算子的构造确有缺口。取 X=diag(1,0)、U=V=e1、D=[1] 即得到具体反例。

将 U、V 的列按同一列次序分别补全为标准正交基，得到 Utilde、Vtilde。若 J 是前 r 个坐标的嵌入，则 Utilde*U=J、Vtilde J=V。于是 W=Vtilde Utilde* 为酉算子，P=UDU* 半正定，而且 WP=Vtilde JDU*=VDU*=X。此处必须保留 WP 的方向，不能把同一个 P 写成 PW；取 U=e1、V=e2 可直接区分这两个乘积。X=0 时取 P=0、W=I，单独处理零情形也是正确的。

因此作者的 SourceError 注条件充分、方向正确，已由非作者独立核验通过。原文 W=VU* 的句子仍明确保留，没有静默更换作者原式。

## 推导与版面

伪逆唯一性的 (1.161) 四行和所有中间等号都已逐一回核；随后 Schmidt 推导中的 y_k 共轭及共轭向量组的标准正交性完整。偏迹收缩的全部最大值比较，以及秩至多二算子的谱表达式及迹范数结论，都未删略。

当前 8 页预览均由审者独立渲染并逐页查看；未见裁切、重叠或漏式。预览 SHA-256：`4dfabd4c07bb4cb988db0d040629839412a32be4061f63ba87b937215b0af2eb`。这项版面检查不替代前述来源语义审校。

## 当前文件及真实批准字节

| 单元 | 当前批准 SHA-256 | 实际批准快照 |
|---|---|---|
| 1.1.3-wrapper | `ce7e59cdc047ded7003196e94f3f0dd6c5ecdf57f12e8913fc9be9c17d7a7f61` | `qa\approved-bytes\B\ce7e59cdc047ded7003196e94f3f0dd6c5ecdf57f12e8913fc9be9c17d7a7f61\book\chapters\ch01-sec01-sub03.tex` |
| 1.1.3-part01 | `f578cd29a3948494c41864e7adde3652a0ccedcdadcb975ca6c9a71c66c27365` | `qa\approved-bytes\B\f578cd29a3948494c41864e7adde3652a0ccedcdadcb975ca6c9a71c66c27365\book\chapters\ch01-sec01-sub03-part01.tex` |
| 1.1.3-part02 | `34e98ff268da44134b37663f5345af2fb74f6f418e149f8c8ef584662a92d54c` | `qa\approved-bytes\B\34e98ff268da44134b37663f5345af2fb74f6f418e149f8c8ef584662a92d54c\book\chapters\ch01-sec01-sub03-part02.tex` |
| 1.1.3-local-macros | `e134129b6dca3937fd585ff3e42fd979a4ff7100aaca010ae5542d02a901ae35` | `qa\approved-bytes\B\e134129b6dca3937fd585ff3e42fd979a4ff7100aaca010ae5542d02a901ae35\book\macros-A03.tex` |

源页 32 的 Start 沿用上批，本批补真实 End32；End42 附于最后公式，整个第 43 页留给未来 1.2。先前九份已批文件及其批准快照逐字复核未变，批准链继续复用。新增宏只有 WatrousSchatten，不覆盖既有定义；旧宏依赖身份保持。

本批准仅适用于本次四份文件的精确字节与明确源范围。整书合编、导航、冷重建与最终压缩包验收仍是独立关卡。审者未改译稿、宏、原件或主页。
