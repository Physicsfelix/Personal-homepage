# Watrous batch20：独立审校 B

**当前三输入均 approved。** 作者A，审者B；未修改作者译文。源 SHA `992de30011ff2ec70994256d6ad5f3a93f250a6f0d08fa4314bd0c9ea5156a36`。范围为原物140的3.1.2标题至147的Barnum–Knill证明末、3.2标题前。物140 Start沿用上批，End140本批；物147 Start本批，End147留后节。

原140–147八整页逐页实际看图；补看原71确认既有零概率系综约定。当前六译页全部实际看图，34式(3.30)–(3.63)、情景3.8、两完整定理证明、四个SDP块、三个无号题头、脚注1及其中3.51、所有普通段落均逐段逐式核对。

- **Scenario3.8/zero-weight convention**：Original140 all registers/probabilities/conditional state and success sum match. Context original71 freshly viewed: after2.11 it explicitly restricts determination of rho_a to eta(a)!=0 and explains that zero-probability events need no specified state. This existing ensemble convention applies to3.31, so no new SourceError is warranted. Ensemble sums to density rho; all p(a) nonnegative sum1.

- **Payoffs and compact optimization3.33-36**：Real payoff K makes phi(b)=sum_a K(a,b)eta(a) Hermitian; trace linearity gives double sum and outcome sets may differ as stated. Finite-dimensional POVM set is closed, bounded (0<=mu(a)<=I), nonempty by I/|Sigma|, hence compact; real continuous objective attains maximum. All hypothetical/generalization prose retained.

- **Four SDP blocks3.37-42**：Formal primal off-diagonal blocks may be nonzero. Diagonal compression is PSD with sum partial trace I; block diagonal objective A ignores off-diagonals, preserving objective. Dual block PSD iff every Y-phi(a) PSD. Y constrained Hermitian, not PSD. X=I tensor I/|Sigma| strictly positive with correct partial trace; gamma>lambda1(A) gives strict dual, even if gamma negative. Two-sided Slater implies finite attained optima. Source/target/order/normalization in all four blocks retained.

- **Theorem3.9 whole two-direction proof3.43-47**：Forward: primal optimal X and attained dual Z, complementary slackness (I tensor Z)X=AX. Partial trace Z TrY X=TrY AX=sum phi(a)mu(a) gives Y=Z, Hermitian and feasible. Order phi mu must not reverse. Converse: stated Hermiticity and all inequalities make Y dual feasible; traces yield matching real objectives because Tr phi mu=Tr mu phi, and weak duality proves both optimal. Both directions and introductory criterion prose present.

- **PGM and footnote1/3.48-52**：im eta(a) subset im rho by positivity: ker rho annihilated by all eta. Sum sqrt(rho+) eta sqrt(rho+)=support projection; adding kernel projection/|Sigma| to each outcome completes identity. Kernel terms have zero pairing with eta, so any POVM above these base operators gives identical success for ensuing bound. Footnote retains entire arbitrariness/any-outcome quantifier/3.51. Original3.51 footnote is source145 final object; End145 there, actual translated page4 with marker and3.52.

- **BarnumKnill3.10 whole proof3.53-63**：Support identity rho^1/4 (rho+)^1/4=Pi_imrho yields3.55 under trace cyclicity. HS CS followed by real-vector CS retains quarter powers and two sum-of-squares factors. First squared factor=sum Tr(nu sqrt(rho) nu sqrt(rho)) <=sum Tr(sqrt(rho) nu sqrt(rho))=Tr rho=1, using nu<=I and other factor PSD. Second squared factor=sum<sqrt(rho+) eta sqrt(rho+),eta> <=sum<mu,eta>. Hence every measurement nu has success squared <= PGM success; attained optimum may be substituted. Both norm2/Frobenius conventions and all intermediate lines retained.

两次独立重编均0，六页几何/文本/1.4倍像素与已实际看图的作者PDF逐页相同。25字体程序全嵌，无缺字、未定义或溢出版式问题。源Start144在定理框第一对象内；End145位于原页真正最后脚注对象，与呼号和3.52同译页4。

旧B55及C11批准输入已逐字对真实批准快照核验，core与作者当前提交字节一致。当前三文件真实批准字节已存，ledger-B更新为58条。候选PDFSHA `ea501d29c0bbfe730bb6260a793140d7f0b3a93d382d56032027f71fa6ac5a4f`。本报告只批准此完整小节及其三输入，不是全书验收。

- `book/chapters/ch03-sec01-sub02.tex`：`10d8c9ac74005515f2d0e6c9b2318d5037a863950125276db32972af75e1e091`；快照 `qa\approved-bytes\B\10d8c9ac74005515f2d0e6c9b2318d5037a863950125276db32972af75e1e091\book\chapters\ch03-sec01-sub02.tex`。
- `book/chapters/ch03-sec01-sub02-part01.tex`：`2646ee471fd35211e663a971dff494898e3cf65cc212547c3c7ec76d77501565`；快照 `qa\approved-bytes\B\2646ee471fd35211e663a971dff494898e3cf65cc212547c3c7ec76d77501565\book\chapters\ch03-sec01-sub02-part01.tex`。
- `book/chapters/ch03-sec01-sub02-part02.tex`：`337426271989689a34fbecf34788bdfb49de4ecca13f035a1a31b7f156266ca0`；快照 `qa\approved-bytes\B\337426271989689a34fbecf34788bdfb49de4ecca13f035a1a31b7f156266ca0\book\chapters\ch03-sec01-sub02-part02.tex`。
