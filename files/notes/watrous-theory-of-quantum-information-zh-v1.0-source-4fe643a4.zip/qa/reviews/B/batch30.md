# Watrous batch30 非作者 B 独审

状态：**approved**。章4完整开头、4.1完整开头与完整4.1.1分别核实；原209–219全部实际看，220页顶为下一小节，仅边界。11对象、63式、4正式完整证明（4.8双向）、九个乘积矩阵/两5×5矩阵、4无号题头、全部段落均齐。无原脚注/图/译校注/新宏。

## Chapter4/4.1 complete openings and4.1/4.2

Allunitalclass/majorization/Hermitianandrealvectorplansandthreechannelclassesretained. CP-TPunitalmapX->YforcesdimX=TrPhiI=TrIY=dimY, explainingrestrictiontosamespace. Mixedunitarydefinitionfinitealphabet/probability/unitaryfamily/forallXandconvex-combinationequivalenceexact;everyunitaryandconvexcombinationunital.

## Example4.3 fullargument/nine3x3products

Source210/211allentriesviewedandindependentlyexact-computed. AntisymmetricA1/A2/A3 all1/sqrt2signsretained;sumA* A=I andsumvecA vecA*=(I-W)/2withrow-majorvec, Choi rank3. AllnineproductsAj*Akexactlyprintedmatrices, familyrank9 confirmed. ThuschannelisextremebyearlierChoi2.31criterion,andnotunitarysinceChoirank3, so cannotbeconvexcombinationofunitarychannels. Completeexampleargumentnotreplacedbyjustassertion.

## 4.4/4.5/4.6 fullpinchingproof/4.7

ProjectionssummingIarepairwiseorthogonal: Pi_a sum_bPi_b Pi_a=Pi_a forcesallpositivePi_aPi_bPi_azerooutsidea. Thus U_w=sumw(a)Pi_a unitaryforallsignvectors. Averagingw(a)w(b)overALL2^|Sigma|signs givesdelta_ab; allnormalizationsandsums4.14-17retained. Two5x5input/outputmatricespreserve2+3diagonalblocks andall25inputentries/allcrosszeros. Nondestructivemeasurement/discardoutcomeandnonstandard-basisnamingparagraphsfull. Complete dephasingexampleanditsrank-oneprojections retained.

## 4.8 entire1=>2 proof andconjugations

ArbitrarygivenStinespringisometryandallXcorrectionconditionretained. Addzero-probabilityoutcomes tomake|Sigma|>=dimZ; tightframevaexistsandKrausAa=(I tensorva*)A. Equal-sizeKraussetsrelatedbyunitaryWwithsqrtpUa=sumW(a,b)Ab. Consequentlyua=sum conjugateW(a,b)vb;firstWconjugatein4.29andnoextraonein4.31areessentialandmatchactualsource215. POVMsumua ua*=IZ,conditionaloutputpUaXUa*, inverseunitarychannelUa*XUaandweightedcorrectionidentityallexact. CPconditionalmapcanbemovedtosandwichsqrtmuinsidepartialtrace, so sourceone-sidedmu formulaisvalid.

## 4.8 entire2=>1 proof

SharedGammaonlypaddingzeroKrausoperators,noequalminimalrankassumption. IdChoiisrank-onevecIprojector,soeachAa,b Ba,c scalaralphaI. Sum|alpha|²1andPsi_aTPsumAa,b*Aa,bIforceBa,c*Ba,c=(sum_b|alpha|²)I. ForpositivecoefficientpolarBa,c=betaUa,c;forzeroBa,cchooseanyunitary,sozeroprobabilitiesnotexcluded. p(a,c)=|beta|²sums1andPhi=sum_aPhi_a provesmixedunitary. Allindices,orderA B,adjoints,normalizationandwhole4.35-44 retained.

## 4.9 wholeCaratheodoryproof

HermXrealorthogonalbasisIplusn²-1tracelessHj, notnecessarilyorthonormalI. TensorbasisdecomposeskernelXi spanHj tensorHk,dimension(n²-1)²;remaining2n²-1imagesmutuallyorthogonalincludingoneI tensorIterm. PartialtracesofunitaryChoiI/I giveaffinefiberdimensionn4-2n²+1;realCaratheodorygivesatmostdimension+1=n4-2n²+2. n1edgegives1. Entire4.47-54linear-map/basis/orthogonality/equivalenceargumentretained.

## 4.10 completeproof/4.11

ChoiPSDtrace dimX>0sorankr>=1. Xi(H)captures trace/outside-support/crossblocks;kernelpreciselyHermitianH=PiHPi,TrH0, realdimensionr²-1. Phi infinitefamilyconvAmeansfiniteconvexcombination;anypositiveweightJ(Psi)hasrangewithinrangeJ(Phi)bypositivity/kerneltest,soPhi inconvB. AllBChoihaveXi image diag(dimX,0,0), henceaffinefiber dimensionr²-1,Caratheodorym<=r²withoutclosingconvexhullorassumingAcompact. CorollaryusesunitarychannelsandallXformula4.63. Allcrossblockorders/codomainthreeblockspaces andfinalforallretained.

## 身份与预览

全部当前9译页实际看。独立两遍0，9页几何、文字、1.5倍像素与作者PDF相同；21字体全嵌，无缺字溢出未定义。Start209在OriginalChapter清页后，与真正章4页同页；209–219所有首末锚各一次，220无标记。旧B87/C16真实批准字节及core冻结，作者提交实际字节相等。本记录不作整章验收。

- `book/chapters/ch04-intro.tex` SHA256 `d598cd190cd28ec12f617d2d6b0799aab0c6030eeeda76da81378eafac847d22`；真实快照 `qa\approved-bytes\B\d598cd190cd28ec12f617d2d6b0799aab0c6030eeeda76da81378eafac847d22\book\chapters\ch04-intro.tex`。
- `book/chapters/ch04-sec01-intro.tex` SHA256 `1dcdd7615fadc2745c2460248d1b626327bc51d615e41d092ea3214a8775b917`；真实快照 `qa\approved-bytes\B\1dcdd7615fadc2745c2460248d1b626327bc51d615e41d092ea3214a8775b917\book\chapters\ch04-sec01-intro.tex`。
- `book/chapters/ch04-sec01-sub01.tex` SHA256 `5733b816baf299d50dcca853bcc2ed0acb73728d889baaab5c029ef95359d0b7`；真实快照 `qa\approved-bytes\B\5733b816baf299d50dcca853bcc2ed0acb73728d889baaab5c029ef95359d0b7\book\chapters\ch04-sec01-sub01.tex`。
- `book/chapters/ch04-sec01-sub01-part01.tex` SHA256 `3a0f353228b7e5cd7ac1be866d89c34fc9890762109a17c23523e0d56f71b9ed`；真实快照 `qa\approved-bytes\B\3a0f353228b7e5cd7ac1be866d89c34fc9890762109a17c23523e0d56f71b9ed\book\chapters\ch04-sec01-sub01-part01.tex`。
- `book/chapters/ch04-sec01-sub01-part02.tex` SHA256 `e20ba8d5fc68f481bb14bc4ffa4c87e2c12da00a04fb281bd6432e9027a140e2`；真实快照 `qa\approved-bytes\B\e20ba8d5fc68f481bb14bc4ffa4c87e2c12da00a04fb281bd6432e9027a140e2\book\chapters\ch04-sec01-sub01-part02.tex`。
- `book/chapters/ch04-sec01-sub01-part03.tex` SHA256 `b71653c3e93c032fcec1f97b2260ee1099e61f8365b16b87e275f2fbb1730035`；真实快照 `qa\approved-bytes\B\b71653c3e93c032fcec1f97b2260ee1099e61f8365b16b87e275f2fbb1730035\book\chapters\ch04-sec01-sub01-part03.tex`。
