# Watrous batch19 独立审校 B

当前结论：needs_revision；仅来源Start138定位待最小修订。完整原132–140共9页和当前6译页已实际看过，所有29式/3情景/4完整证明/全普通段落、三题头与列表通过语义核。

- **Bayes source note3.1**：Actualsource134 saysforeachb;chooseSigma{0,1},p0=p1=delta0,lambda1/2,b1giveszeroeventand0/0. No priorcontextrequiresstrictlypositiveprobabilities. Nonnegativitymeansbothjointweightszero,soarbitrarydecisiononthateventcontributes0tosuccess/failure. Noteaccurateandoriginalformula/forallretained.
- **Classicalsuccessandendpoints**：Peroutcomechoosemax(alpha,beta),summax=(1+sum|alpha-beta|)/2. Norm0forceslambda1/2andp0p1samebynormalization;norm1equalstodisjointweightedsupport,includinglambda0/1zero-weightvectors. Fulltieparagraphandallscenariogoals/choicesretained.
- **Lemma3.3 andHH3.4 fullproofs**：A=sum sqrtPa tensorea hasA*A=sumPa andA*(I tensorEaa)A=Pa. Diagonaluoperatornormmax|u| givesboundevencomplexu. POVMmu0+mu1I implies||mu0-mu1||<=1byu=(1,-1);HoldergivestheHHbound. JordanHahnPQorthogonal,mu0supportsP/complementmu1givesTrP+TrQ,includingzeroP/Q/Xandendpriorlambda. Allproofcalculations/projectiveattainment/coarsegrainingparagraphretained.
- **Prop3.5 conjugation3.22/23**：Native138barsonuactuallyviewed. Chooseu=conjugate(v)/|v|when vnonzero,anyphaseat0. First-slotconjugatelinearityrequiresconjugate(u)insidesum. Independent1Dmu1,X=i,v=i,u=-i gives< i,i>=1;omittingbarwouldgive<-i,i>=-1. Lemma3.3+HolderthenprovesnorminequalityforarbitraryoperatorX,notmerelyHermitian.
- **ConvexadversarialtaskandSion**：C0/C1onlynonemptyconvex,notnecessarilyclosed. AdversarialchoicesdependonBobmeasurementallowed;noprobabilitydistributionassumed. Ablockstatesconvexpossiblynoncompact,BweightedPOVMimagecompactconvexevenlambda0/1. TracepairingrealcontinuousbilinearonHermitianblocks;Sionvariantwithcompactmax-sideBapplieswithoutclosingA. ForfixedBlinearcontinuous;inf_AgivesuppersemicontinuousobjectiveoncompactB,ensuringmaxattained. Alice-sideusesinfandneednotbeattained. Allminmaxquantifiersandstate-weightfactorscorrect.

阻断项：part02的SourcePageStart138置命题3.5环境前，实际目标仍在第4译页，命题首对象已移至第5译页。已请A仅将该锚移入命题环境首词前。源文字/数学不需修；不得在新字节差分复核前沿用旧批准。

独立2遍冷编0，全6页几何/文字/像素同当前作者PDF；无版式/缺字诊断。非空前页夹具亦独立2编，Start132实际章页2且图已看。未创建本批新批准快照，旧B48账本保持。
