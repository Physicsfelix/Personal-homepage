# Watrous batch31 完整4.1.2非作者 B 独审

状态：**approved**。原220–227完整Weyl协变小节，至4.113全部forall句、共享227的Schur题头前。全8原页/6译页实际看；4对象、50式、4.14四向蕴含完整证明、4.15完整证明、三题头、两个原脚注与全部普通段落核齐。无新宏/注。

## AllWeyloperators/phases/basis/Fourier andExample4.12

VU=zetaUV withpositivezeta/shiftU/diagonalV givesWab=UaVb andentryzeta^bc E_(a+c,c). ConjugateWab=W_(a,-b),transpose=zeta^-ab W_(-a,b),adjoint=zeta^ab W_(-a,-b);allsource4.74 bars/signs independentlyread. Productphasebc andcommutatorphasebc-ad followmovingVbthroughUc. Charactersumzeroexcepta0 givesTrW=nonly00andHSorthogonalitynormsquaredn; n²operatorsformbasis. PositiveexponentFourierFunitary,FU=VF,FV=U*F, FWab=zeta^-ab W_(-b,a)F. n2W11=-i sigmayandallPauli entriesretained. Generalalgebraicderivationscheckalln>=1, separatefiniteconsistencytestsn1-5notusedasproof.

## 4.13 wholedefinition/prose/footnotes

CovariantmapscommutewithALL Weylconjugations/allX, linearCOMPLEXsubspaceandchannelconvexsubset. ArbitraryA/BinL(X), noextraPSD/Hermitianhypothesis. Fullthreeheadingsandtwocharacterizationparagraphsretained;foot1arbitraryfixedbijectionSigma/Zn,n=|Sigma|;foot2eigenoperatorasanoperator-spaceeigenvectorretainedwithoriginalnumbers.

## 4.14 allfourimplications/fullproof

1=>2: Wab*PhiWabcommutesallWcd*usingcovarianceandphasealpha=zeta^(ad-bc);firstswapadjointfactorisBARalpha,whichcancelsalpha pulledfromPhi. Basisofalloperatorsmakescommutantscalar. 2=>1: applyeigenrelationtobasisWcdwithphasebc-adandextendlinearly. 3=>2: A(c,d)=sum_ab zeta^(bc-ad)B(a,b), exactly A^T=n F* B F since(nF*BF)_(d,c)=thatsum; transposecannotbeadjoint. 2=>3: B=(1/n)F A^T F*,samecharactersumreconstructsmaponallbasisthenallX. Entire4.87-99alllines/quantifiersretained, includingnon-HPcomplexcoefficients.

## 4.15 complete proof

OrthogonalvecWbasisnormsqrt(n)diagonalizesChoiJwithREALnonnegativeeigenvaluesnB(a,b)ifCP. ThisrequiresentrywiseB(a,b)>=0, notmatrixBPSD;candidatecorrect. TPforallXforcescoefficientssum1, soBentriesareprobabilityandmapmixedunitary. All4.100-105andproofendingretained.

## Depolarizing/dephasingwholelastheading

Omega/Weyl-eigenmatrixE00 andB=allones/n²giveuniformallWconjugations; vecWresolutiongivesChoiI tensorI/n,correctnormalization. ArbitrarySigmaidentificationpreservesthemapandmixedunitaryconclusion;originalprintedpage212footnotereferenceexplicitlyidentifiedasoriginalsourcepage. DephasingeigenmatrixA=e0 onesrowkillsallnonzeroshifta, FA^T F*=A, henceB=A/nandaveragingW0cphasesgivesdiagonalprojection. All4.106-113andfinalforallXclausecomplete before4.1.3; placingforallleadbefore4.113doesnotomitit.

## 身份与源锚

End220在脚注1末（译页1），该源页正文4.69及脚注均已在1完成；End222在脚注2末（译页3），该源页全部正文也在3完成。两呼号/注体/链接同页，不以源码中footnote命令位置代替实际完成位置；后源内容同页出现不改变这两源页最后对象的身份。Start227在本批，End227留后小节。

独立两遍0，6页几何、文字、1.5倍像素与作者PDF相同；27字体嵌，无缺字溢出未定义。旧B93/C16实际快照/core冻结。

- `book/chapters/ch04-sec01-sub02.tex` SHA256 `f78a2a87d6fb5dad9339f9ffb2a174ee6aa035682a3272ecdad144785c9cb81b`；真实快照 `qa\approved-bytes\B\f78a2a87d6fb5dad9339f9ffb2a174ee6aa035682a3272ecdad144785c9cb81b\book\chapters\ch04-sec01-sub02.tex`。
- `book/chapters/ch04-sec01-sub02-part01.tex` SHA256 `c2872ab543fb836fefacb2f3a22951b8d4c56fb2e71b458f71146eca6fd9a952`；真实快照 `qa\approved-bytes\B\c2872ab543fb836fefacb2f3a22951b8d4c56fb2e71b458f71146eca6fd9a952\book\chapters\ch04-sec01-sub02-part01.tex`。
- `book/chapters/ch04-sec01-sub02-part02.tex` SHA256 `2c05a84d95fb55bce35f90fd3ebb6e2dfac7d7f8f9e46a5351ac1adca3009b2e`；真实快照 `qa\approved-bytes\B\2c05a84d95fb55bce35f90fd3ebb6e2dfac7d7f8f9e46a5351ac1adca3009b2e\book\chapters\ch04-sec01-sub02-part02.tex`。
- `book/chapters/ch04-sec01-sub02-part03.tex` SHA256 `b4bbd1b7ed1f02af2ac01736ba23112b4e1bd0273422f09e8e6c684193a84dda`；真实快照 `qa\approved-bytes\B\b4bbd1b7ed1f02af2ac01736ba23112b4e1bd0273422f09e8e6c684193a84dda\book\chapters\ch04-sec01-sub02-part03.tex`。

非整章验收。
