# Watrous batch26 独立审校 B

状态：**approved**。作者 A；审者 B。批准完整 §3.3.3 的忠实译文与分离译校注；**所给原书定理 3.56 的数值结论已被反例否定，不作为真命题批准**。

原件 SHA256：`992de30011ff2ec70994256d6ad5f3a93f250a6f0d08fa4314bd0c9ea5156a36`。实际逐页看物183–192全页及193边界；191/192关键公式另放大。实际看当前全部9译页。58式(3.281)–(3.338)、7对象、6完整源证明、5无号题头、整幅图3.1及完整长图注、全部普通段落均保留。无原脚注。

## Lemma3.50 fullproof

For ||X||1=1, offdiagonal Hermitian dilation H=(X tensor z0z1*+X* tensor z1z0*)/2 has trace norm1. HP gives Phi(X*)=Phi(X)*, so the output dilation norm equals ||Phi(X)||1. Spectral coefficients of H have absolute sum1; the triangle inequality forces at least one unit pure projector to attain no smaller output norm. All six equations3.285-290, adjoints and convex-combination prose retained.

## Theorem3.51 fullproof

Apply Lemma3.50 to Phi tensor IdX with an extra two-dimensional ancilla, then compress combined X tensor C2 ancilla to X by Lemma3.45 preserving the xx* output trace norm. Reverse inequality is definition; zero map harmless. Ordinary induced double bars and stabilized triple bars remain distinct.

## Theorem3.52 fullproof

For every ancilla Z, density sigma, binary measurement mu and real prior lambda in[0,1], HolevoHelstrom bounds success by half plus half output trace norm, then induced-ancilla norm <= CB norm by3.46. The weighted channel difference is HP. If dimZ>=dimX, pure CB attainer embeds by V:X->Z and projective HH measurement attains; I_X and I_Y types retained. Original unusual equation order3.301 before definition3.302 retained.

## Network/wholeFigure3.1

Acyclic network admits topological hybrid replacement one channel at a time. Other channels have CB norm1; identity stability, unitary factor reorderings, composition and triangle give the sum of local errors, no network factor. Independently cropped source187 RGB pixels exactly equal candidate native figure; six channel boxes, all input/output/internal arrows and labels retained. Full long caption translated, including Phi1 unnamed output as second of three Phi4 inputs and total composite register type.

## Definition3.53/ToeplitzHausdorff3.54 fullproof

Continuous unit-sphere image gives compactness. Alpha!=beta implies u,v independent. Affine Y sends their Rayleigh values to1,0; H=(Y+Y*)/2,K=(Y-Y*)/(2i). Phase of v makes u*Kv purely imaginary while endpoint K-expectations vanish. The actual source path is z(t)=(tu+(1-t)v)/norm, nonzero for real t; K-expectation is0 and H-expectation a real continuous path from0 to1. IVT proves every convex combination without normality. Full normal versus nonnormal discussion, equations and phase qualifications retained.

## Theorem3.55 fullproof/uniform quantifier

Pure-output trace distance formula gives sqrt(1-4lambda(1-lambda)|u*V0*V1u|^2). An entangled input produces Tr(rho V0*V1), a convex combination of numerical-range points, hence a pure-vector expectation by3.54. A single u for all lambda exists by minimizing modulus on compact numerical range; that minimizer maximizes every lambda expression, including trivial lambda endpoints. This independently substantiates the short source concluding sentence, without adding a replacement proof to translation.

## Theorem3.56 source hypotheses and genuine failure

Actually read full original191/192, including epsilon in[0,2], arbitrary channel, forall density input and unhalved trace/CB norms; no hidden small-epsilon restriction. Phi(X)=Tr(X)I2/2 has Kraus Eij/sqrt2 with sum K*K=I. Every qubit density with eigenvalues r,1-r has ||Phi(rho)-rho||1=2|r-1/2|<=1. Epsilon=1 therefore satisfies every hypothesis. Normalized maximally entangled tau maps to I4/4; difference spectrum -3/4,+1/4,+1/4,+1/4 gives norm3/2>sqrt2 (9/4>2). Thus provided source conclusion3.326 is false. This is not a translation error.

## Theorem3.56 original proof and SourceError

All original proof equations3.327-338 and wrong constants preserved. Diagonal bound3.328 is valid from traceless Hermitian spectral norm <= half trace norm. Orthogonal u=e0,v=e1 gives uv*=E01, Phi(E01)=0 and abs HS(E01,-E01)=1, refuting claimed1/2 in3.329. Four-phase polarization3.331 is correct; the final1/4 sum of FOUR terms each <=epsilon in3.333 yields epsilon, not epsilon/2. Schmidt overlap3.335, subsequent reliance on bad offdiagonal bound and FvdG steps all faithfully retained. Separate note after whole proof explicitly displays counterexample and arithmetic defect; no corrected theorem or new replacement proof invented.

## 字节、预览与边界

新7输入与作者实际提交逐字一致，真实批准快照逐一落盘。旧 B78/C11 批准字节及核心不变。独立两遍编译均退出0，9页几何、文字、1.5倍像素全与当前作者PDF相同；20字体均嵌入，无缺字、溢出或未定义引用。图3.1独立重渲染裁片与候选2040×690 RGB逐像素相同。

Start183沿用上一批，End183本批；184–192各首末锚一次，End192在原完整证明与分离注之后，193不计译文。187首锚随整图绑定，跨页句与第一真实对象对应。详细目标页/坐标见 build-verification。

当前作者PDF SHA256：`2b08589155e991d141e4f37bb8c0c2a726ab6cd901f1dc834d8d2d75722e29de`。本报告不是章或全书验收。

- `book/chapters/ch03-sec03-sub03.tex`：`88285570df0f822dee4f6fba1e211b668959e756b048622ffcb1c8d68b4253ef`；快照 `qa\approved-bytes\B\88285570df0f822dee4f6fba1e211b668959e756b048622ffcb1c8d68b4253ef\book\chapters\ch03-sec03-sub03.tex`。
- `book/chapters/ch03-sec03-sub03-part01.tex`：`55d6bf904c3444f110b2cee799b3011112d53a32eae390b3726a933921d73df7`；快照 `qa\approved-bytes\B\55d6bf904c3444f110b2cee799b3011112d53a32eae390b3726a933921d73df7\book\chapters\ch03-sec03-sub03-part01.tex`。
- `book/chapters/ch03-sec03-sub03-part02.tex`：`eab3c53a65859775f7246d015d88b03e662df5bc20241fd3c7725a6c8fe577a8`；快照 `qa\approved-bytes\B\eab3c53a65859775f7246d015d88b03e662df5bc20241fd3c7725a6c8fe577a8\book\chapters\ch03-sec03-sub03-part02.tex`。
- `book/chapters/ch03-sec03-sub03-part03.tex`：`871cff22211f1939fcdd61ff62b52756b3c65167e62cffc1d0f97ce7a6079d7a`；快照 `qa\approved-bytes\B\871cff22211f1939fcdd61ff62b52756b3c65167e62cffc1d0f97ce7a6079d7a\book\chapters\ch03-sec03-sub03-part03.tex`。
- `book/chapters/ch03-sec03-sub03-part04.tex`：`b9a87d2151a901712c9767cc21bfb08fc03c55e0abe94198dcfeaf64c71a1cf3`；快照 `qa\approved-bytes\B\b9a87d2151a901712c9767cc21bfb08fc03c55e0abe94198dcfeaf64c71a1cf3\book\chapters\ch03-sec03-sub03-part04.tex`。
- `book/chapters/ch03-sec03-sub03-part05.tex`：`a561462eadd8397a48b1c72c1b5163aae1503f7a47aab9084990f7021adaaf94`；快照 `qa\approved-bytes\B\a561462eadd8397a48b1c72c1b5163aae1503f7a47aab9084990f7021adaaf94\book\chapters\ch03-sec03-sub03-part05.tex`。
- `book/figures/watrous-fig3-1-channel-network.png`：`5f43be3e8f7e8c051075bec8fb3a9d47699fed3948d32a20e150716c5fbd2da7`；快照 `qa\approved-bytes\B\5f43be3e8f7e8c051075bec8fb3a9d47699fed3948d32a20e150716c5fbd2da7\book\figures\watrous-fig3-1-channel-network.png`。
