# Watrous batch23：独立审校 B

**完整3.2.3，当前六输入均 approved。** 原163–171九整页及172页首下一节界已实际看图；当前八译页全实看。55式3.165–219、十编号对象、十完整证明（包括3.33两种证明）、五原无号题头和全部普通段落完整核对。本批原无脚注/图/新宏/译校注。

- **3.25 and3.26 full proofs**：Previous3.17 Remark gives attaining X_i with real nonnegative trace=F_i, not merely absolute trace. Sum of PSD blocks is PSD, trace additivity yields superadditivity. Simultaneous scaling of both arguments by lambda gives lambda F (two square roots), including endpoints0/1. Joint concavity and both separate-concavity prose/quantifiers retained.

- **3.27 channel monotonicity full proof**：CP means Id_C2 tensor Phi takes positive2x2 input block to positive output and preserves adjoints; trace preservation applies also to non-Hermitian X. The3.17 block maximum then gives Foutput>=|TrPhiX|=|TrX|=Finput. Both CP and TP are required and retained; direction not reversed.

- **3.28 extension maximum full proof**：Z dimension dim(X tensor Y) suffices to purify arbitrary Q0; with ancilla Y tensor Z there is also room to purify P1. Fix u0 purifying Q0/P0 and use Uhlmann to choose u1 achieving F(P0,P1). Q1=TrZ(u1u1*) extends P1. Partial trace channel gives lower bound matching earlier upper bound3.177, so maximum attained independently of chosen Q0. All dimensions/trace factors/order and two bounds retained, including nonnormalized PSD inputs.

- **3.29 sum-of-squares theorem full two-step proof**：Nonzero spectrum of two unit rank-one projections sum equals spectrum of2x2 Gram matrix [[1,c],[barc,1]], so largest1+|c|, also collinear case. First choose u0/u1 attaining mutual F, then maximal eigenvector v, and sigma its marginal gives >= bound. Conversely fix any density sigma and its purification v (norm1 follows also directly Tr sigma1), choose u0/u1 separately attaining their F against this fixed v. Their mutual overlap<=F(rho0,rho1), and Rayleigh bound gives <=. Chosen purifications in second step need not maximize mutual overlap; quantifiers and two proof stages intact.

- **3.30 definition and3.31 Kraus formula full proof**：Mapping fidelity defined with unsquared F and u=vec sqrtP, for any CP map, not necessarily TP; channel/entanglement fidelity terminology limitation complete. Rank-one fidelity formula gives sqrt(sum_a |u*(Aa tensor I)u|^2). Row-major vec yields <sqrtP,Aa sqrtP>=Tr(sqrtP Aa sqrtP)=Tr(P Aa)=<P,Aa>, under second-slot linearity. Formula3.199 retains outer square root, Kraus order/adjoints, arbitraryPSD P and all worst-case explanatory prose.

- **3.32 full proof and purification independence**：Previous2.29 channel from ancilla Y to Z sends uu* to Q with fixed marginal P. Apply channel monotonicity to Id_X tensor Psi, which is TP; do not apply it to Phi, which is onlyCP. Phi and Psi act on separate factors so commute, giving exactly (Phi tensor Id_Z)Q. Comparing pure extensions in both directions proves independence of purification. Both distinct ancillas and entire final prose retained.

- **3.33 Fuchs-van de Graaf first proof both bounds**：3.24 provides measurement attaining unsquared F and probability p/q. Scalar inequality (sqrtalpha-sqrtbeta)^2<=|alpha-beta| plus norm1 measurement contraction gives ||rho-sigma||1>=2-2F. For other side Uhlmann unit purifications have overlapF, pure difference eigenvalues +/-sqrt(1-F^2) yields norm1=2sqrt(1-F^2), and partial trace contracts Hermitian norm1. Equivalent3.204 keeps half and quarter factors; no half trace-distance convention silently introduced.

- **3.34 complete noncommuting proof and3.33 alternative**：Let S=sqrtP0-sqrtP1=Q0-Q1 JordanHahn, D=Pi0-Pi1 has ||D||<=1 and DS=SD=Q0+Q1. Identity A^2-B^2=half(A-B)(A+B)+half(A+B)(A-B) is valid noncommutatively; both ordered half terms retained. HS pairing and trace cyclicity produce3.217 with Q0+Q1. Difference from <Q0-Q1,sqrtP0-sqrtP1> is2Tr(Q0 sqrtP1)+2Tr(Q1 sqrtP0)>=0, yielding squared Frobenius bound. Alternative3.219 uses Tr(sqrt rho sqrt sigma) real nonnegative <=norm1=F, not equality; exact factors2 and unsquaredF kept. Original second-bound reference retained, not expanded as new source proof.

源163–171 Start/End各一次，实际首对象/末对象页匹配；Start169框内译页5，Start171证明内译页7，End171最后原证明句译页8；无172锚或译文。两遍独立重编0，全八页几何/文字/1.4倍像素匹配作者当前PDF，16字体全嵌，无缺字/溢出/未定义。旧B65及C11批准输入逐字对真实快照冻结，六当前输入匹配作者实际提交字节。新六真实快照已落，B ledger71条。PDFSHA `545c06f147687bf8ba467904fa3c505744439b0c5b491398d7b4007a8afbadda`。仅此完整小节获批，不是整章或全书验收。

- `book/chapters/ch03-sec02-sub03.tex`：`a1ebad36fce5c89e73445635dfbd0f95023ccef86c7cd17986c5cc944616173a`。
- `book/chapters/ch03-sec02-sub03-part01.tex`：`2c09ce2be2655ed8b8d342c67d72e60559b4f1279196d795a9b43ad7b3f7dd2f`。
- `book/chapters/ch03-sec02-sub03-part02.tex`：`afb8f43011083232e6cc7c542fbe8568d95012e3582548017f0a5e2db2620e87`。
- `book/chapters/ch03-sec02-sub03-part03.tex`：`e01cef2b32f7d1b70bbe81c1699ac6553551b577b1a38346cf7828ff3fe90240`。
- `book/chapters/ch03-sec02-sub03-part04.tex`：`07dea7696c80b9b52626901aaeffdb616bf1049e672bf906e0741180a24951ec`。
- `book/chapters/ch03-sec02-sub03-part05.tex`：`853bb27cf83a1d50f64bc524126b9b888715337ac1a2fecde51799bb865d44d6`。
