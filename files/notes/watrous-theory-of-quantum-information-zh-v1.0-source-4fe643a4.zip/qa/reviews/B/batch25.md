# Watrous batch25：B独立审校

**完整3.3.2，五当前输入均 approved。** 原174共享标题至183首个证明末、3.3.3前，十原整页与八当前译页实际看图；原182双X0条件另作B独立4倍放大。49式3.232–280、十三编号对象、七完整证明、完整例3.42双向界、八命题子项、三原题头、无号Remark与全部普通段落逐段逐式核。

- **3.37/3.38 inducednorm andfullconvexity proof**：Finite-dimensional unitballcompact and Phi continuous, so maximum attained. SVDwrites any ||X||1<=1 as sum singularweights uv*, with total<=1; remainderweight canrepresent0asaverage ofoppositerankones. Convexity of outputtrace norm reduces maximum to unit uv*, generally u!=v. Sourcewholeproof and all inducednorm/motivationalprose retained; no rank-oneprojection asserted absent positivity.

- **3.39 RussoDye fullproof/3.40/Remark**：Duality gives induced1->1norm=maxunitaryU spectralnormPhi*(U). PositivePhi haspositiveadjoint; spectralprojectionsPik go toPSD, andunitcircleeigenvaluespermitLemma3.3bound ||sumlambda_k Phi*Pik||<=||sumPhi*Pik||=||Phi*I||. Iitselfunitaryattainsbound. Phi*I PSD Rayleigh quotient yieldsrank-oneprojectioninput trace. ForpositiveTPPhi, Phi*I=I, so inducednorm1; contraction applies toALLcomplexoperatorsX, notonlyHermitian, and requirespositivitynotCP. Exact normsubscripts/operatornorm distinctions retained.

- **3.41 all3items/fullproof and3.42 example**：Submultiplicativity is operator-inducednorm composition. TelescopingPsi1Psi0-Phi1Phi0=Psi1(Psi0-Phi0)+(Psi1-Phi1)Phi0, channelnorms1 give sum bound. Independent unitaryleft/right U/V preserve trace norm, inverse identityPhi(X)=U1*Psi(U0*X V0*)V1* retains allfourstars. ForTpartialtranspose, normalized tau=(vecI)(vecI)*/n mapsW/n, givingnormn. Upperbound onmatrixdimensionn² is ||Y||1<=n||Y||2; entrypermutationpreservesFrobenius and||X||2<=||X||1. Full two-sided example3.249-255 retained.

- **3.43/3.44 definition andallthreeproperties**：CBtriplebarnorm explicitlystabilizesbyinputspaceX; inducednormdoublebars remain distinct inmacroandactualPDF. Rank-oneattainers uv*unitonXtensorX, channelnorm1byCP+TPofstabilizedmap, andindependentunitaryleft/rightinvariance allmatchsource. No originalproof suppliedfor3.44, so none invented. Both fullparagraphs onancillarelevance/sufficientworst-casesize retained.

- **3.45 whole two-case compressionproof**：IfdimZ<=dimX, oneancillaisometryZ->Xembeds x/y andpreservesbothnorms. IfdimZ>dimX, padSchmidtcoefficientswith0andcompleteorthonormalsetsupton=dimX. Copysecondfactor xk/yk withoutconjugation in u/v, then U=sumzk xk* and V=sumwk yk* are twopossiblydifferentisometries andsatisfy(I tensorU)u=x,(I tensorV)v=y. Left/right outputisometriespreservenonzero singularvalues andboth trace norms in3.263/264. No forcedcommonbasisorunwarrantedbar introduced; all lines ofxy*andxx*arguments retained.

- **3.46/3.47 stabilization size**：Rank-oneattainment plusLemma3.45 yields inducedancillanorm<=CBforanyZ. IfdimZ>=dimX, chooseV:X->Z and embedarbitrarytrace-unitballinput withI_XtensorV; outputembeddingusesI_YtensorV, preserved asdistinctspacesin3.269. Reversebound proves equality underthisSUFFICIENTdimensioncondition, not an iff forparticularPhi (identitymapalreadyequalswith1dimancilla). 3.47followsbytensorpermutationandTheorem3.46withenlargedancillasize>=dimX. Full statement/prooflines/equalityhypothesisretained.

- **3.48 bothitems/fullproof**：ComposewithancillaX toapplyinducedsubmultiplicativity/telescoping. ForPsi:Y->Z, ancillaX neednotbeaslargeasY, so onlyTheorem3.46inequality ||Psi tensorIdX||1<=CBPsi isused, notunsupported equality. Phi usesdefiningancillaX. Tensorchannel differences keep correctfactororder andchannelnorm1. Both inequalitiesand sourceproof3.274/275 retained.

- **3.49 wholemultiplicativity proof/source normalizationnote**：Upperfactors (Phi0 tensorIdY1)(IdX0 tensorPhi1) havecorrectintermediates, compositionbound andidentitystability give product. Original182 actuallyrepeats||X0||1=1twice, independently4xenlarged; bodyretainsboth andseparatednote correctlysuppliesintendedX1normalization. Eachmap hasunittrace-normattainer bycompactnessandhomogeneity, includingzero mapchooseanyunitinput, so ||X0tensorX1||1=1. Input/output middlefactorpermutations areunitary changesoforder, giving3.279; evaluatingreorderedmaponX0tensorX1andtrace-normmultiplicativity givesoppositebound3.280. Note repairslocalnormalizationletteronly, doesnotrefutetheorem.

唯一新宏WatrousCbNorm仅有带前缀的三竖线记号，wrapper显式加载一次，不重定义旧宏；当前PDF中与诱导迹范数双线清楚区分。原X0重复条件照录并有独立通过的分离注。定理3.46维数条件是等号的充分保证，当前正文正确，不能误读成对每个映射的必要条件。

源174 Start在已批24，本批End174；175–183新Start/174–182End各一次。Start181短框在译页6，Start183首句译页8；End183留3.3.3。两遍独编0，全八页几何/文字/1.5倍像素同65a8e5c6…，19字体嵌，无缺字/溢出/未定义。旧B73+C11真实快照/core冻结，五当前输入匹配作者提交，真实批准快照齐。B ledger78条，仅完整本小节通过，不是全书验收。

- `book/chapters/ch03-sec03-sub02.tex`：`eb39fa148edd290f9105181cf4384659aee1391f06dde4b76078128db26749ac`。
- `book/chapters/ch03-sec03-sub02-part01.tex`：`1677848a975fe645a59cd1c462e9244019d5612c0a8f90139bb4e3ce3d41e773`。
- `book/chapters/ch03-sec03-sub02-part02.tex`：`f0133bc1391c6393f34c144e7bb78bc915b6b26d1147c2682ba89d9c4ad86840`。
- `book/chapters/ch03-sec03-sub02-part03.tex`：`81e5335108a5498ae00498188ce9f8fdffefcb0127b437b3eac1572877af8c4b`。
- `book/macros-A25.tex`：`e39909346ae86cd6fd6464c273e72b7255e8eb6850fec93ec2bc8fdb6ea63ca4`。
