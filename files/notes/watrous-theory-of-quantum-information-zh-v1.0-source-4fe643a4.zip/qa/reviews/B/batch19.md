# Watrous batch19 独立审校 B（r2）

结论：7份新输入当前字节均 approved。章3完整导语、3.1完整导语与完整3.1.1，原132–140至下一3.1.2前。9张完整原图逐段逐式实际核，原29式/3情景/4完整证明/3小标题及所有普通段落与列表齐。

- **Bayes source note3.1**：Actualsource134 saysforeachb;chooseSigma{0,1},p0=p1=delta0,lambda1/2,b1giveszeroeventand0/0. No priorcontextrequiresstrictlypositiveprobabilities. Nonnegativitymeansbothjointweightszero,soarbitrarydecisiononthateventcontributes0tosuccess/failure. Noteaccurateandoriginalformula/forallretained.
- **Classicalsuccessandendpoints**：Peroutcomechoosemax(alpha,beta),summax=(1+sum|alpha-beta|)/2. Norm0forceslambda1/2andp0p1samebynormalization;norm1equalstodisjointweightedsupport,includinglambda0/1zero-weightvectors. Fulltieparagraphandallscenariogoals/choicesretained.
- **Lemma3.3 andHH3.4 fullproofs**：A=sum sqrtPa tensorea hasA*A=sumPa andA*(I tensorEaa)A=Pa. Diagonaluoperatornormmax|u| givesboundevencomplexu. POVMmu0+mu1I implies||mu0-mu1||<=1byu=(1,-1);HoldergivestheHHbound. JordanHahnPQorthogonal,mu0supportsP/complementmu1givesTrP+TrQ,includingzeroP/Q/Xandendpriorlambda. Allproofcalculations/projectiveattainment/coarsegrainingparagraphretained.
- **Prop3.5 conjugation3.22/23**：Native138barsonuactuallyviewed. Chooseu=conjugate(v)/|v|when vnonzero,anyphaseat0. First-slotconjugatelinearityrequiresconjugate(u)insidesum. Independent1Dmu1,X=i,v=i,u=-i gives< i,i>=1;omittingbarwouldgive<-i,i>=-1. Lemma3.3+HolderthenprovesnorminequalityforarbitraryoperatorX,notmerelyHermitian.
- **ConvexadversarialtaskandSion**：C0/C1onlynonemptyconvex,notnecessarilyclosed. AdversarialchoicesdependonBobmeasurementallowed;noprobabilitydistributionassumed. Ablockstatesconvexpossiblynoncompact,BweightedPOVMimagecompactconvexevenlambda0/1. TracepairingrealcontinuousbilinearonHermitianblocks;Sionvariantwithcompactmax-sideBapplieswithoutclosingA. ForfixedBlinearcontinuous;inf_AgivesuppersemicontinuousobjectiveoncompactB,ensuringmaxattained. Alice-sideusesinfandneednotbeattained. Allminmaxquantifiersandstate-weightfactorscorrect.

唯一首轮问题已闭：仅将SourceStart138从命题3.5环境外移入首词前。B独立检验精确替换唯一、反向替换恢复旧part02全部字节；其余6输入与原候选SHA逐一相同。主体与非空前页夹具各由B独立重编2遍，Start138分别在真命题页5/6，两个当前页均实际看过；Start132亦在真章页2。

全部6译页在首轮实际看图，r2全6页几何/文字/像素逐页等于原实际看过的版本，且逐页等B当前冷编；当前第5页另放大实看。PDF SHA `326cb00c39c63b2e7ac9e4afa21400f23c6a2cdddfefbba3412428c5c7fb3eec`。无缺字/未定义/overfull/underfull。旧B48及当前C批准记录逐字等其真实快照；本次未改作者tex。

共享原140本批写Start，End留下一3.1.2真正原页末；不据此误判漏项。

- `book/chapters/ch03-intro.tex`：`05d9806f5739dfc2fe5084e2b0b22dbeeec2f449fc57dbe24f365f61d884a2e8`；真实快照 `qa\approved-bytes\B\05d9806f5739dfc2fe5084e2b0b22dbeeec2f449fc57dbe24f365f61d884a2e8\book\chapters\ch03-intro.tex`。
- `book/chapters/ch03-sec01-intro.tex`：`d006cdb5ba3c04be38d7e16d7592198308b673084a49747d71dc2f137d3c7954`；真实快照 `qa\approved-bytes\B\d006cdb5ba3c04be38d7e16d7592198308b673084a49747d71dc2f137d3c7954\book\chapters\ch03-sec01-intro.tex`。
- `book/chapters/ch03-sec01-sub01.tex`：`60171bed466bb31da860d48329688785b9c47ca1ea6283c73d9b40941863b49b`；真实快照 `qa\approved-bytes\B\60171bed466bb31da860d48329688785b9c47ca1ea6283c73d9b40941863b49b\book\chapters\ch03-sec01-sub01.tex`。
- `book/chapters/ch03-sec01-sub01-part01.tex`：`348273b991d3581461597fb26c441b25a555c0e0e7d7099630c95f6ed2111935`；真实快照 `qa\approved-bytes\B\348273b991d3581461597fb26c441b25a555c0e0e7d7099630c95f6ed2111935\book\chapters\ch03-sec01-sub01-part01.tex`。
- `book/chapters/ch03-sec01-sub01-part02.tex`：`a329b64a73fa5abf56124e8849d20af292010bfddc2a9de8c75ccee747922be3`；真实快照 `qa\approved-bytes\B\a329b64a73fa5abf56124e8849d20af292010bfddc2a9de8c75ccee747922be3\book\chapters\ch03-sec01-sub01-part02.tex`。
- `book/chapters/ch03-sec01-sub01-part03.tex`：`4a9b49d29c4ffb9c617852ba65dd63d5e6546a1eaaf95eed61b257726f3e6c7e`；真实快照 `qa\approved-bytes\B\4a9b49d29c4ffb9c617852ba65dd63d5e6546a1eaaf95eed61b257726f3e6c7e\book\chapters\ch03-sec01-sub01-part03.tex`。
- `book/macros-A19.tex`：`04491041fbd062ff3ab87ec49d7541b4106cc22d77bbe46ada5fb3d56cb86adf`；真实快照 `qa\approved-bytes\B\04491041fbd062ff3ab87ec49d7541b4106cc22d77bbe46ada5fb3d56cb86adf\book\macros-A19.tex`。

首轮needs_revision证据另存batch19-r1-needs-revision.json/md。当前无待修问题。
