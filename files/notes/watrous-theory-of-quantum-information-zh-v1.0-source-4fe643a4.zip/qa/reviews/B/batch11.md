# Watrous batch11 独立审校 B

结论：approved。审者 B 未撰写或修改 A 的译稿；本次批准绑定下列四份实际字节。源 SHA：`992de30011ff2ec70994256d6ad5f3a93f250a6f0d08fa4314bd0c9ea5156a36`。

范围为原物85的2.2.2标题至物99命题2.29证明结束、2.2.3标题前。全部15张完整原页已实际看图逐段逐式核，全部12张当前译页已实际看图。物99的End留后节，当前Start99正确，不把未结束的共享原页误判为漏项。

原81式2.60–2.140、10编号对象2.20–2.29、9完整证明、8无号小标题及两行蕴含关系全部保留。推论2.27原无独立证明，未补造；本批原无脚注、图或译校注。

- **Natural/Choi representations 2.60–66**：Independently reconstructed row-major vec(AXB*)=(A tensor conjugate(B))vec(X), and Tr(Eab X^T)=Xab. Thus Choi inverse right multiplication by IY tensor X^T and trace over X are correct, with no adjoint replacement.
- **General Kraus/Stinespring adjoints 2.70/73; Prop2.20**：Under second-slot-linear Hilbert–Schmidt product, Tr(Y* A X B*)=Tr(B*Y*A X)=<A*YB,X>. The Stinespring adjoint is A*(Y tensor I)B. Source conjugate bars in 2.74 and 2.79 actually inspected on physical88/89 and preserved.
- **Cor2.21 rank construction**：For nonzero Phi, r>=1. Choose U columns a basis of range J; J=UV* with unique V* obtained by a left inverse of U. Vec inverses yield matched r terms and any specified alphabet/environment of that size. Both any-quantifiers retained.
- **Thm2.22 all seven CP conditions**：All paths in both rows 1=>2=>3=>5=>4=>1 and 5=>7=>6=>1 checked. PSD spectral J supplies rank-r Kraus terms; arbitrary ancillary PSD input stays PSD under each conjugation, and partial trace is CP. Nonzero qualification and all arbitrary ancillary spaces retained.
- **Cor2.23/24 unitary equivalence**：Extracting ea*U produces row U(a,b), without conjugation or transpose. Equal-alphabet possibly nonminimal Kraus families are purifications of one Choi operator, so theorem2.12 supplies a unitary even with zero terms. Slicing Stinespring gives B=(IY tensor U)A in the original left-multiplication direction.
- **Thm2.25 Hermitian preservation**：Full H+iK and Jordan–Hahn arguments checked. If either Jordan part vanishes, its associated zero map is directly CP, so earlier nonzero theorem qualification causes no defect. Five conditions and every implication retained; no invented HP heading.
- **Thm2.26 TP and Cor2.27 channels**：Source cross normalization is sum Aa*Ba=I and A*B=I. This equals adjoint unitality. Cyclic-trace normalization sum Ba*Aa=I is the adjoint equivalent, not a reason to reverse source factors. Both existential and universal clauses retained; representations always exist so universal clauses are not vacuous. Matrix-unit marginal proof and six channel conditions/minimal rank restrictions checked.
- **Prop2.28 compactness**：Finite-dimensional linear bijection J is a homeomorphism. Its channel image is PSD cone intersected with a closed affine marginal constraint; PSD trace norm equals trace=dim X, proving boundedness. Convexity and all source steps preserved.
- **Prop2.29 arbitrary extension from fixed purification**：The two independent W bounds permit purification of P and embedding Y into Z tensor W. A is an isometry; applying purification uniqueness to (I tensor A)u and v gives (I tensor UA)u=v. UA is an isometry, hence the defined partial-trace map is a channel. Full marginal/output chains checked. P=0 gives u=v=0 and any compatible unitary; no normalization assumption needed.

两次独立空目录重编均退出0，无缺字、未定义、溢出或underfull。12页几何、文字和1.35倍像素均与作者当前PDF逐页相同。当前PDF SHA `71a9030a6bf7fcbcbbeb42d132f41e97e93304708a2bd1983acecc7193a4ed89`。旧40份数学批准输入逐字等于其实际批准快照，未改动。

- `book/chapters/ch02-sec02-sub02.tex`：`acc7c8027d31aae0d6485b7485a6bb17cf1028e2e7d6861dbbdb664f86a18e98`；真实批准快照 `qa\approved-bytes\B\acc7c8027d31aae0d6485b7485a6bb17cf1028e2e7d6861dbbdb664f86a18e98\book\chapters\ch02-sec02-sub02.tex`。
- `book/chapters/ch02-sec02-sub02-part01.tex`：`77d6800d8e1ee938d67fa6b4a5fa9ee1242b3bc3bbd3a79205044f00aa840c1a`；真实批准快照 `qa\approved-bytes\B\77d6800d8e1ee938d67fa6b4a5fa9ee1242b3bc3bbd3a79205044f00aa840c1a\book\chapters\ch02-sec02-sub02-part01.tex`。
- `book/chapters/ch02-sec02-sub02-part02.tex`：`23b4bc8e976e0580f2e02256863732052e8f361420b4c05a7610bab74e32d8ab`；真实批准快照 `qa\approved-bytes\B\23b4bc8e976e0580f2e02256863732052e8f361420b4c05a7610bab74e32d8ab\book\chapters\ch02-sec02-sub02-part02.tex`。
- `book/chapters/ch02-sec02-sub02-part03.tex`：`36ca0dee03665d5552cb44145d1338d672d04943a4309b5afe4203deb5b14478`；真实批准快照 `qa\approved-bytes\B\36ca0dee03665d5552cb44145d1338d672d04943a4309b5afe4203deb5b14478\book\chapters\ch02-sec02-sub02-part03.tex`。

未发现待修问题。此记录仅批准本节四份输入，不代表全书验收。
