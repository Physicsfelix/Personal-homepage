# Watrous batch33 非作者 B 独审

状态：**approved**。4.2完整导语与完整4.2.1，物230–236至4.23完整证明末、4.2.2前。全7原页/5译页实际看；4对象、35式、4完整证明、原一个题头、两个列举与全部普通段落核齐。无新注宏。

## 4.2/4.2.1 fullopenings/embedding/generalKraus

Fullsetoffixed-spaceunitalchannelsandfuturefixedpoints/normplansretained. V vecX=vecdiag(X,X^T)givesV*V=2I, NOTanormalizedisometry;leftinverseV*/2provesinjectivityofcongruencephi. ForarbitraryPhiX=sumAaXB_a*,embeddedKrausoperatorsdiag(Aa,Aa^T)anddiag(Ba,Ba^T)retaindifferentA/B. CPiffviaChoiVJV*andV*(VJV*)V=4J. TracepreservationofphiiffsumBa*Aa=Iand(sumAaBa*)^T=I, exactlyTPandunitalPhi;thenphialso unital. All2prelimitemsand4.131-136/codomainsretained.

## Lemma4.20 bothdirections/fullproof

Linearinjectivephicarriesproperconvexdecompositionsforward. ConverselyPSDChoiidentityofnontrivialdecompositionforphiforcesbothJXi-supportedinrangeV;chooseQi=(1/4)V*JXiV PSD, thenJXi=VQiV*. CPofPsiandTPofphigivePsiCP-TP/unital, distinctXisgive distinctPsis,injectivitypullsdecompositionback. All4.137-145/real0<lambda<1/PSDconditionsandnotjustoneimplicationretained.

## Theorem4.21 fullcriterion/proof/conjugation

IndependentAa implyindependentembeddedCa=diag(Aa,Aa^T),sopriorChoi2.31criterionapplies. Cb*Ca=diag(Ab*Aa, BARAb Aa^T), matchingoriginal4.148. Thelinear invertible operationtransposingonlylowerrightblockyieldsAaAb*,withoutconjugatingcoefficientsorchangingupperblock. Hencecriteriondiag(Ab*Aa,AaAb*) precisely4.147. RawbarAbcorrectlyvisible,allforallindicesandiffretained.

## Lemma4.22 fullpolar/jointdiagonalproof

Finite-equalsizeAi admitsunitarypolarextensionsUi evenifrankdeficient/zero;notincorrectthinpartialV. P1²=I-P0²andunitalrowidentitygiveWA1normalforW=U0*, all6lineidentities4.151-152retainorder/stars. PositiveP0/P1commutebysquare-rootfunctionalcalculus. ConjugatesU0P0²U0*=U1P0²U1*giveuniquePSDsquarerootidentity,soP0commutesU0*U1;thenWA0=P0commutesWA1=U0*U1P1. Commutingnormaloperatorsjointlyunitarilydiagonalize, chooseV=UW. No invertibilityassumptioninserted;zeroAi boundaryworks.

## Theorem4.23 compactness/fulltwo-rank-caseproof

Unitalchannelsetcompactconvexasclosedaffinesliceoffinitechannelset, henceconvextremeby1.10. IndependentKrauscardinalityr=Choirank,unitaryiff1. Forr>=3, atleastr²>=9pairedblockoperatorsincomplex8-dimensionaldiagL(C2)directsumL(C2),sodependent. Forr2,Lemma4.22givesVAaU*=diag(alpha_a,beta_a),henceAb*Aa=alpha_a BARalpha_b U*E00U+beta_a BARbeta_b U*E11UandAaAb*samecoefficientswithV*EV. Fourpairedoperatorsspanatmost2,not4;allbarsandU/Vdirectionactualsource236checked. Thusnonunitarynotextreme,allunitalqubitchannelsmixedunitary. Wholebothcases/4.158-165/finalproofretained.

## 身份与预览

两独立编译0，5页几何、文字、1.5倍像素与作者PDF相同，17字体全嵌，无诊断。4.20/21短框完整，End231在前者真实末对象，Start233在后者首词同页绑定；Start230在前批，End236留后节。旧B98/C16当前实际批准字节/core冻结。

- `book/chapters/ch04-sec02-intro.tex` SHA256 `cac2660f9b38a5903e8b09f2f0f159d6c0f3cc6bab23f470f31235b0bd89cdee`；真实快照 `qa\approved-bytes\B\cac2660f9b38a5903e8b09f2f0f159d6c0f3cc6bab23f470f31235b0bd89cdee\book\chapters\ch04-sec02-intro.tex`。
- `book/chapters/ch04-sec02-sub01.tex` SHA256 `c44e3fbd75bbce3dce560447131a319492606f6bb18b1a2ca48814f67596a3a3`；真实快照 `qa\approved-bytes\B\c44e3fbd75bbce3dce560447131a319492606f6bb18b1a2ca48814f67596a3a3\book\chapters\ch04-sec02-sub01.tex`。
- `book/chapters/ch04-sec02-sub01-part01.tex` SHA256 `36ad7006b711f398f5a90025be232ad440468bd6ff4468adec0dfe5a866bee91`；真实快照 `qa\approved-bytes\B\36ad7006b711f398f5a90025be232ad440468bd6ff4468adec0dfe5a866bee91\book\chapters\ch04-sec02-sub01-part01.tex`。
- `book/chapters/ch04-sec02-sub01-part02.tex` SHA256 `e61fe74aff8352ddd52cf94e200ef34e335818b83b466ba67ec2702155ae9273`；真实快照 `qa\approved-bytes\B\e61fe74aff8352ddd52cf94e200ef34e335818b83b466ba67ec2702155ae9273\book\chapters\ch04-sec02-sub01-part02.tex`。

不是整章验收。
