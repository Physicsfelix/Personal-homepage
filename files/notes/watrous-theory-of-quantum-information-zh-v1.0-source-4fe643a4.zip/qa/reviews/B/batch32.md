# Watrous batch32 完整4.1.3非作者 B 独审

状态：**approved**。四原页227–230全部实际看，至4.19完整证明末、4.2前；当前3译页全看。四对象/17式/三完整证明/全部普通段落齐，无新注宏、脚注或图。

## 4.16/4.17 completeequivalenceproof

ArbitraryoperatorAentrywiseproduct definitionwithallentriesretained. V copiescanonicalbasis e_a->e_a tensor e_a, isometryV*VI, soJ(SchurA)=VAV*;PSD A givesCP,CPgivespositive,positiveSchurmapappliedtoallonesrank-onePSDoperatorgivesA PSD. Allthreeimplications/fullproofmatchsource, n1andzeroAallowed.

## 4.18 all3items/twoiffpairs/fullproof

NoCP/positive/HermitianhypothesisassumedonA. DiagAall1 iffAodotIpreservesI, andifftraceAodotX=traceXforallX;converseTPtestEaa givesAaa1 andunitalconversecomparebasisEaa. Thusall3equivalentforARBITRARYcomplexA. Fullsource4.118-122/sumandTrordersretained. Statementboxcontinues1->2withall3itemsvisible, readablewithoutomission.

## 4.19 exists/everyKraus/fullproof/conjugation

CPensuresatleastoneKrausrepresentation,soevery=>existenceisnotvacuous. ForSchurPhi,PPSDby4.17andJ=VPV*. AnyrepresentationhaspositiveGram-sumJ, soeachvec(Aa) inrangeJ subsetrangeV=span e_b tensor e_b, henceeveryAa diagonal includingnonminimal/zeroKrausfamilies. ConverselydiagonalAa=Diag va givesP=sumva va*,andentryPbc=sumva(b) BARva(c),notconjugatingb. All4.123-130/quantifiers/codomainskept;source4.130baronva(c)independentlyread. NoextraTP/unitalclaimadded.

## 身份与预览

当前 `chapters/ch04-sec01-sub03.tex` SHA256 `d16f5b6dd9b653a58ff6f33e5b185c16adc52813e15e4390fbbe6a4d73eadf09`；真实快照 `[project]\qa\approved-bytes\B\d16f5b6dd9b653a58ff6f33e5b185c16adc52813e15e4390fbbe6a4d73eadf09\book\chapters\ch04-sec01-sub03.tex`。独立两遍0，3页文字、几何、1.5倍像素与作者PDF相同，16字体嵌入，无诊断。4.18陈述盒跨页1/2，三个子项均完整，当前可读且没有孤立编号。旧B97/C16批准字节/core冻结。Start227已在前批，End230留下一节，无伪造整页结束。非整章验收。
