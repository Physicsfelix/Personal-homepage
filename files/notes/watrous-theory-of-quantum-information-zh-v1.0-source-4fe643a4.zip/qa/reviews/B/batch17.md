# Watrous batch17 独立审校 B

结论：approved。Complete2.4Exercises, physical128headingthrough130Exercise2.6(c)finalequation2.316, before2.5Bibliographicremarks.

对应完整源页均实际看图逐段核，原130本单元止2.5标题前，End130由文献单元闭。

- **2.1/2.2 conditions and HilbertSchmidt order**：Real-linear functional on Herm(X) yields effect operators by real PSD selfduality; normalizing all density operators forces sum mu=I, so equivalence wording valid. HJW-style2.2 keeps environmentY POVM and outputX partial trace, with all-a quantifier; effect multiplication before uu* is source order and equivalent under traced subsystem cyclicity to positive sandwich. Neither slot convention nor output/input swapped.
- **2.3/2.4**：NonzeroCP hypothesis and r=rankJ retained. Row operator A=[A1 ... Ar]:X tensorZ->Y givesPhi(X)=sum Ai X Ai*, with TrZ(A*A)=I as simple TP criterion (only QA, no solution inserted). For positivePhi, adjoint effectsPhi*Eaa PSD; DeltaPhi has block-diagonal PSD Choi, so CP without a TP assumption. Original second request in2.3 retained.
- **2.5 sequential factorization**：Exact channels/spaces and two statement quantifiers retained. Choi orderY W X Z, tracingW givesY X Z matchingJPsi tensorIZ. Sequential map firstPhi0:X->Y tensorV, thenI_L(Y) tensorPhi1: Y tensorV tensorZ->Y tensorW; environment bounddimV<=dim(X tensorY) retained. Identity onoperator spaces is distinguished fromvectoridentity.
- **2.6 allabc andquantifiers**：(a) all-channel affine normalization, PSDP and densityrho retained. Channel Choi set has affine hullTrYJ=I, so annihilator formIY tensorrho withPSD/trace1 is consistent. (b) forallPhi existsPsi, CPXi inputY tensorX/outputW tensorZ, and Lambda:X->Z isUNITAL CP, not falsely TP; all-X equality and partialtraceW/Y correcttypes. (c) same(b) premise, Xi0:Z->X tensorV thenPhi tensorIdL(V) thenXi1:Y tensorV->W, forallPhi and uniquePsi viaChoiinjectivity retained. No source hints omitted; no proofs/answers added.

全部2当前译页实际看过，两遍独立冷编0，无缺字/未定义/溢出/underfull；各页几何/文字/像素与作者当前PDF `56c668bafa3bcd54235fba2f81081133a70a8276125d793ef0996b7da619df1d` 全同。旧批准输入逐字等于真实B/C快照，未修改原译稿或core。

`book/chapters/ch02-sec04.tex` SHA `492592fa0d4b05bd290061031b89b30f875f7aa6f3c7e8c37e5719e62144df99`；真实批准快照 `qa\approved-bytes\B\492592fa0d4b05bd290061031b89b30f875f7aa6f3c7e8c37e5719e62144df99\book\chapters\ch02-sec04.tex`。未发现待修项。
