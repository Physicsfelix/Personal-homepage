# Watrous batch28 独立审校 B

状态：**approved**。完整原单元逐段逐式核，全部原页与当前译页实际看；原209仅作后一章边界。

## 3.1 full parity/squared-delta bound

Both parityconstraints,2^(n-1)normalization,positiveintegern,unsquaredfidelitydeltaandnegativeexponentn delta²/2retained. QAconsistency: sigma0-sigma1=(rho0-rho1)^tensor n/2^(n-1). FvdGlowerboundandhalftracenorm<=sqrt(1-delta²)giveF>=1-(1-delta²)^(n/2)>=1-exp(-n delta²/2). Noanswerinserted.

## 3.2/3.3 complete hypotheses andrequests

PSD P/Qnotrequirednormalized, mapTPpositivebutexplicitlynotnecessarilyCP; measurementfidelitycharacterizationconsistentbecauseadjointunitalpositivepullsPOVMback. 3.3existsspaces/channelpairwithSTRICTinequalityforeveryrho, notoneinput/nonstrictbound;WernerHolevoseparationconsistent. Noanswersadded.

## 3.4-3.6 formulaorders/iff

Two independent densityroots flankChoiwithI_Ycorrectfactor; noextratranspose. 3.5hasHermitianconditiononTrY(HJ(Phi))ANDinequalityI_YtensorTrY(HJ)>=Hwithiff,HJorderkept. SDPslack(I tensorY-H)J0impliesTrYHJ=Y;converselyfeasibleHermitianYandthisidentitymakeprimalvaluedualbound. 3.6allmapswithinputdimensionn,CB<=||J||1<=nCB,constants1/npositionscorrect. Nineoriginaleq3.406-414andsixfullquestionsretained,nohint/proofadded.

## 身份与预览

当前 `chapters/ch03-sec04.tex` SHA256 `9d571906e26e5f865371fd86e42591099c0e07728942e7a85e740fbf035951ac`；真实批准快照 `[project]\qa\approved-bytes\B\9d571906e26e5f865371fd86e42591099c0e07728942e7a85e740fbf035951ac\book\chapters\ch03-sec04.tex`。旧B85/C16当前批准字节/core冻结，实际作者提交相等。独立两遍0，全部译页几何、文字、1.5倍像素与作者PDF相同，无缺字溢出未定义、字体全嵌。

源首末：Start205/End205here;Start206here/End206following3.5.

作者PDF SHA256 `7d48a6e7a711f38b9c1ea728466ee06695ba907c661cc7a7b69cca25bc1185d6`。本记录不作章或全书验收。
