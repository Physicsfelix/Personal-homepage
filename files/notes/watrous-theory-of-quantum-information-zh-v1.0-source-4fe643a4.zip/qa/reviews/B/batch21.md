# Watrous batch21 r2：独立审校 B

**完整3.2导语与3.2.1，两文件当前均 approved。** 原147–151整页逐一实看，152页首下一节仅边界。当前四译页已实际看图；r2仅3/4重流重看，1/2几何/文字/1.4倍像素同旧。

28式3.64–91、定义3.11、命题3.12全部七项、3.13/14/16与Winter推论3.15及五完整证明、脚注2和全部普通段落保留。

- Definition3.11 unsquared trace norm and sqrt(sqrtQ P sqrtQ) formula correct for arbitraryPSD, all scope prose retained.

- Proposition3.12 all seven properties/full proof retained. Zero product equivalent orthogonal supports; CauchySchwarz equality gives nonnegative scalar dependence including zero matrices. In independence direction, alpha sqrtP U=-beta sqrtQ implies |alpha|^2P=|beta|^2Q, forcing alpha=beta=0. Isometry may be nonsurjective; square-root identity acts zero on perpendicular complement and nonzero singular values unchanged.

- Proposition3.13 rank-at-most-one operator (sqrtP v)(sqrtP v)* has sole possible eigenvalue v*Pv including v=0; two rank-one fidelity abs inner product retains conjugation convention.

- Proposition3.14 A=sqrtP Q sqrtP positive implies sqrt(A^2)=A, trace cyclicity yields TrPQ=<P,Q>; all both proof formulas retained.

- Corollary3.15 strict positive pairing normalizes output, P<=I yields sqrtP>=P. Homogeneity 1/sqrt(pairing) gives stated lower bound. Complete footnote2 nondestructive high-probability measurement observation retained.

- Proposition3.16 square-root tensor identity/ordered product/norm1 tensor multiplicativity retains all four calculation lines and final conclusion.

首轮仅发现End150未绑定原150最后脚注2；A只移动这一个标记，其他字节逐字相等。当前sub01 SHA `0511c33ab323fe138d822472f5af0cfb9d08e8b0ffd9e1f6e2d28f81ba95cb30`。页3/4重流完整可读，不能称其像素未变；独立两遍当前重编均0，四页逐页几何/文字/像素同作者当前PDF。18字体全嵌，无缺字/溢出/未定义。旧B58与C11当前输入逐字对真实批准快照核验。

源Start147沿前批20，End147本批；148–151Start/End各一次，Start151在本节3.14证明首对象，End150在完整脚注2内，End151本节真末；无152标记。当前PDFSHA `bb81a6a6f50ae6d1a71e60b4883d903d5d39892160a6dc2e63425665318f0762`。两份真实批准快照已落，ledger-B60条。这是两个原单位的批准，不是整书验收。

- `book/chapters/ch03-sec02-intro.tex`：`fb888b1fdf4399e050f2c9871457455cd5afa1dc554c113390a6f187e3056389`。
- `book/chapters/ch03-sec02-sub01.tex`：`0511c33ab323fe138d822472f5af0cfb9d08e8b0ffd9e1f6e2d28f81ba95cb30`。
