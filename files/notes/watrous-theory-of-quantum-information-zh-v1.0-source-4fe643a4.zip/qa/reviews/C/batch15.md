# Watrous batch15 独立审校C

状态：approved；译者A／非作者审者C。

源范围：Complete2.3.2Basicnotionsconcerningmeasurements; source113titlethrough121lastinstrument-realizationparagraph,before2.3.3.

实际独立从原PDF渲染并逐页查看物113,114,115,116,117,118,119,120,121；当前全部7译页实看，逐段逐式对照全部普通文字/无号表达式/编号式/列表与证明。

## 独立数学核验

- 113 / Product measurements2.216-218：Product effects are positive and sum to tensor I. For rho=rho1 tensor...tensor rhon, Tr((tensor mu_i(ai))rho)=product Tr(mu_i(ai)rho_i), establishing the exact independent-outcome statement; no assertion of independence on entangled inputs was added.
- 114 / Partial measurements2.219-228：The register removed is Y_k; the output record Z is permuted to the first factor without altering individual contents. For positive effect M, Tr_k((I tensor M)rho)=Tr_k((I tensor sqrt(M))rho(I tensor sqrt(M))) by cyclicity on the traced factor, so the displayed unsymmetrized source formula is PSD. Tr eta(a)=Tr(M rho[Y_k]); normalization is stated only for a positive-probability outcome. All identity factors and tensor-register order preserved.
- 115 / Example2.39 / separated source note：Actual original2.230 has rho[Y] while the named joint state is tau. Independently, with d=|Sigma|, tau=(1/d)|sum_b eb tensor eb><sum_c ec tensor ec|, hence PSD trace1 and Tr_Z tau=I/d. Thus the particular marginal is tau[Y]=I/d and probability Tr(mu(a))/d. Tr(mu Ebc)=mu(c,b), so the complete conditional state is mu(a)^T/Tr(mu(a)), with plain transpose rather than adjoint/conjugation. Original rho is preserved and the note correctly explains its application to tau.
- 115-116 / Proposition2.40 /2.232-237：Subtracting the diagonal projectors from (sum P)^2=sum P gives sum_(a!=b) PaPb=0. Each Tr(PaPb)=||PaPb||_HS^2>=0, so trace zero forces every off-diagonal product zero. This also yields orthogonal ranges and at most dim X nonzero outcomes. Entire sum-square, split, trace, termwise argument retained.
- 116 / Complete projective and Example2.41：Orthonormal rank-one effects sum I, with standard-basis probabilities rho(a,a); the associated QC channel is precisely diagonal dephasing. Both the general basis terminology and the special example are complete.
- 117 / Naimark2.42 and Corollary2.43：A=sum sqrt(mu(a)) tensor ea has A*A=sum mu(a)=I, and compression of I tensor Eaa gives mu(a). Both J0=I tensor u and A are isometries with equal-dimensional initial space, so an orthonormal-frame extension supplies U with UJ0=A. Then nu(a)=U*(I tensor Eaa)U are orthogonal projections summing I and Tr(nu(a)(X tensor uu*))=Tr((A*(I tensor Eaa)A)X). This is valid for all X, preserving the inner-product first-slot adjoint and every operator order in2.246.
- 118-119 /2.44 and Example2.45：The Hilbert-Schmidt product is conjugate-linear in its first slot: a spanning family Aa with <Aa,X-Y>=0 makes <Z,X-Y>=0 for every Z; choosing Z=X-Y proves injectivity. If Q=sum rho_ab is singular, nonzero u in ker Q has u*rho_ab u=0 for every positive term, contradicting injectivity applied to uu*. Q^-1/2 congruence is invertible on L(X), preserves the span, and sends sum rho_ab to I, so the normalized operators form an IC POVM. Complete original positivity and span argument retained.
- 119-121 / Nondestructive measurements and instruments：Both original two-item lists retain probability and conditional state, including the M_a* M_a order. For instruments each Phi_a is CP and the sum is TP. The block-record map X->sum Eaa tensor Phi_a(X) is CP because each tensor embedding is CP and sums preserve CP; trace is the trace of the total branch map. Measuring Z returns Tr Phi_a(rho) and normalized Phi_a(rho), exactly the instrument. Zero-probability outcomes are not assigned conditional states. All ordinary opening, specialization and final realization paragraphs included.

两遍独立冷编均0，全部译页几何/文字/1.5倍像素与作者当前PDF逐页相同。字体全部嵌入，无实际溢出/缺字/未定义诊断。末页较疏仅因停在完整原小节边界。

旧B48及原C4当前输入与实际批准快照逐字节核同，未改A正文或B账本。以下新输入的批准字节真实保存在qa/approved-bytes/C/<SHA>/book/...：

- book/chapters/ch02-sec03-sub02.tex：`6a64262c67d0727a099f0d69dcfcbdb4bda256ed378826553bf6428a66e6713b`。
- book/chapters/ch02-sec03-sub02-part01.tex：`b6271fedf0a97f462316992259ccd4eec26c2094595f181af354192b5e2fe41d`。
- book/chapters/ch02-sec03-sub02-part02.tex：`4af1ad23a1280e51e1452764c14553542318670bf00c4149f34959024f4fa12e`。
- book/chapters/ch02-sec03-sub02-part03.tex：`c8d76bc117b520a2eb221ea378f6d31795526a6c6125a84f0987e525c8eb086e`。

唯一译校注独核通过：例2.39边缘态是tau[Y]=I/|Sigma|，原2.230的rho[Y]照录，说明与完整转置条件态计算相符。
