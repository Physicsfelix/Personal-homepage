# Watrous batch37：非作者 C 完整独立审校

状态 approved；作者A，审者C，root明确从B队列转派。

原范围：physical254 original4.4Exercisesheading 至 physical255 completeExercise4.6/allm quantifier before4.5Bibliographicremarks。原图与当前全部译页实际看。

## 语义、数学与源注独核

- Whole exercises4.1/4.2：Source254 full4.4heading andall6questions checked againstoriginalimages.4.1retainsdimX3,Schurchannelprecondition andrequestmixedunitarity.4.2retainsALLn>=2definition,Tr(X)I-Xtranspose dividedbyn-1,allX, identitysymbolmeaning, oddn conclusion, andthefullgeneralizationhint requiring a differentargument forn>=5. No proposedsolutionornewhypothesis inserted.
- 4.3 full iff and4.256/257：Positiveintegern, X=C^(Z_n), allW_abunitaries a,b inZ_n, channelPhi, bothSchur andWeylcovariance, probabilityp onZ_n andallX quantifier retained. The secondcondition uses only W_(0,a), with matchingadjoint, notW_(a,0) or a two-indexmixture. Bothnumberedlistitems andallformulas matchsource. No exercise proof added.
- 4.4 and4.5 ordinary statements/quantifiers：4.4 explicitly assumesHermitianpreservation soPhi(H) isHermitian; positive/TP/unital is notstrengthenedtoCP andtheallHermitianH condition retainsmajorizationdirectionPhi(H)precH.4.5 keepsarbitrarym, sortedprobabilityp1>=...>=pm, densityrho, allunitvectors notimposedorthogonal, iff,andallk throughrankrho.4.258sumendsm and4.259sumsendk precisely. Full4.34generalizationparagraph retained. Ordinaryexercisescheckedforfidelity, not expandedinto solutions.
- Only SourceError: zeroextension in4.259, independent condition check：Theactualoriginal255 specifiesp=(p1,...,pm), then asks4.259forall1<=k<=r=rankrho, withoutspecifyingp_j forj>m. Whenm<r those entries are notdefined merelybythefinitevectornotation; the explicitzero-padding convention in the adjacent singularvalueexercise concerns singularvalues, not thispvector. The note correctly suppliesonlyp_j0forj>m andpreservesalloriginalindices/formulas. It doesnotdeclaretheiff false. Independently, ifm<r,at k=m theleftpartialsum is1, whilethetopm positiveeigenvaluesofrank-r densitysumtostrictlylessthan1; so thezero-paddedconditionsfail. Any m-termrankoneensemble hasrank<=m, hence the existence sidealsofails. Ifm>=r allrequestedpindicesarealreadydefined. Thus the note gives a coherentinterpretationthrough theexact problematicrange and adds no textbooksolution.
- 4.6 singularvalue conventions andentire final request：UnitalchannelPhi, n=dimX, referenceChapter1Section1.1.3, alln descending singularvalues withzerosbeyondrank, ALLoperatorsX (notmerelyHermitian orstates), andEVERYm1..n retained. Inequality4.260 has inputpartialsum>=outputpartialsum andtheidenticalm onbothsides. Noanswers, proofs,figuresorfootnotes were presentoradded. SharedStart254 remainsin36; thisunit closesEnd254 andopens255, whileEnd255 remainsforBibliographicremarks.

独立两遍重编0，全部当前译页几何/文字/1.5倍像素逐页等作者当前PDF；字体全嵌，无缺字/溢出/underfull/未定义。所有本批源目标同实际aux页序。
- Bothcurrenttranslatedpagesactuallyviewed. Page2beginswiththeoriginal4.6singularvaluezero-conventioncontinuation thenitsfull4.260andallmquantifier; readable shortlocalcontinuation, not finalwholebookpaginationacceptance. SourceErroriscompleteonpage1; allsixoriginaltagsvisible.

旧B/C所有实际批准输入及C旧技术真快照冻结；审者未改作者正文。新真实批准字节快照已存。

tex SHA `878fa095bc45833346b0eb7f907be84eb487a2d9e922028dd8beeb05020d9f4e`；作者PDF SHA `1840393fffeb6ae1bf2863257b29fd7e164467a84b497bafc24abd43ffd57bc4`。
Complete original4.4Exercises at thisexactcurrentTeX byteidentity and existingA02 macrodependency only; not chapter4/fullbook/sourceZIP/publication acceptance.
