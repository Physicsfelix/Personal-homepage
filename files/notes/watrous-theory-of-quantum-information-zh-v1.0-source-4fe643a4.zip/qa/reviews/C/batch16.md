# Watrous batch16 独立审校C

状态：approved；译者A／非作者审者C。

源范围：Complete2.3.3Extremalmeasurementsandensembles,source121headingthrough128finalProposition2.52proofsentence,before2.4Exercises.

实际独立从原PDF渲染并逐页查看物121,122,123,124,125,126,127,128；当前全部6译页实看，逐段逐式对照全部普通文字/无号表达式/编号式/列表与证明。

## 独立数学核验

- 121-122 / Convex combinations and Definition2.46：Pointwise convex combinations preserve positive effects and sum I; QC-channel assignment is affine and injective, so extremality agrees. A classical random index b selects which original-register measurement mu_b is performed; b itself is discarded rather than being the system measured. One Chinese sentence was requested to clarify precisely this distinction.
- 122-123 / Theorem2.47 first direction2.267-271：For lambda<=1/2, nu0=2lambda mu0+(1-2lambda)mu1 and nu1=mu1; the other case uses nu0=mu0 and nu1=(2lambda-1)mu0+(2-2lambda)mu1. Each row gives two distinct POVMs with average mu. theta=nu0-nu1 sums to zero. For positive P,Q, ker(P+Q)=ker P intersection ker Q, hence im(P+Q)=im P+im Q; this proves the source image inclusion/equality, not a false general statement for arbitrary matrices.
- 123 / Theorem2.47 reverse direction2.272-276：For each a, let S=im mu(a). Hermitian theta(a) with image in S also kills S-perp. On S, mu(a)>=m_a I for some m_a>0; choosing epsilon_a ||theta(a)||<=m_a gives both PSD perturbations. If mu(a)=0, theta(a)=0 and any positive epsilon works. Finite alphabet gives a positive minimum; smaller epsilon remains valid by convexity. The zero-sum relation preserves normalization, nonzero theta gives distinct POVMs, and their midpoint is mu. Full reverse proof retained.
- 124 / Corollaries2.48-2.49：Real dimension of Herm(X) is d². More than d² nonzero effects gives a nontrivial real relation; scaling each nonzero effect gives a nonzero Hermitian theta, so Theorem2.47 applies. Compact convex QC set and finite-dimensional extreme-point convex-hull theorem then give Cor2.49. Original has no separate proof of2.49; no new proof was inserted in the body.
- 125 / Corollaries2.50-2.51：A Hermitian H supported in span u equals alpha uu*, with real alpha when u is nonzero; writing existence of alpha in C is still correct under the Hermitian hypothesis. For u=0, H=0 and alpha=0 works. Thus source alpha in C is not silently corrected or called erroneous. For projective effects Pb, Pb theta(a)=delta_ab theta(a), and left multiplication of the zero sum forces theta(b)=0. Complete proofs preserved.
- 126 / Ensemble convexity and extremes：Block-diagonal ensemble operators form density matrices with a classical block label. Spectral decomposition within nonzero blocks proves global extremes are one nonzero block with a rank-one unit-vector state, as2.293. The fixed-average convex subset is explicitly distinguished and need not have the same extremes as this global set. All affine average-state formulas retained.
- 127-128 / Proposition2.52 full proof：Let rho have rank r>=1 and choose injective A:Y->X with AA*=rho and dimY=r. Positivity of summands gives im eta(a) subset im rho. Lemma2.30 gives positive Qa with eta(a)=AQaA*. A has left inverse L=(A*A)^-1 A*, so applying L and L* to A(sum Qa)A*=AA* gives sum Qa=I. Cor2.49 decomposes this POVM into ones with <=r² nonzero effects. eta_b(a)=A mu_b(a)A* has average rho, is PSD, and has no more nonzero effects; injectivity even gives exact preservation of zero effects. Linearity gives the entire2.305 weighted reconstruction and all three asserted properties. Every equation, condition and concluding sentence retained.

两遍独立冷编均0，全部译页几何/文字/1.5倍像素与作者当前PDF逐页相同。字体全部嵌入，无实际溢出/缺字/未定义诊断。末页较疏仅因停在完整原小节边界。

旧B48及原C4当前输入与实际批准快照逐字节核同，未改A正文或B账本。以下新输入的批准字节真实保存在qa/approved-bytes/C/<SHA>/book/...：

- book/chapters/ch02-sec03-sub03.tex：`b80609866e543e6530049900aef16a4df450fe83c772928e25ab4748bfc00da6`。
- book/chapters/ch02-sec03-sub03-part01.tex：`70bb25abe67bc0b849884976eff2f14c0e545d266fbf6b2e5503513c6eac401b`。
- book/chapters/ch02-sec03-sub03-part02.tex：`49d27b26d27165173f0ec6f460763586fb45d7bb6fa0675464494f3e93ecf414`。

唯一译义修订闭环：物122用于随机选择测量的符号b，改成“实施由所选符号b确定的测量”，明确b不是被测对象。精确差分和新预览独立复核见batch16-delta-verified.json。
