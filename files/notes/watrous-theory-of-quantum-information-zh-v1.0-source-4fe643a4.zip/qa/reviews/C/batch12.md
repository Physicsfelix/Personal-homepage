# Watrous 2.2.3 独立审校 C

状态：approved。译者 A；非作者审者 C。

原件 SHA256：`992de30011ff2ec70994256d6ad5f3a93f250a6f0d08fa4314bd0c9ea5156a36`；January2018预出版草稿，共598物理页。

Complete2.2.3 Examplesofchannelsandothermappings, source99 headingthrough104finalclassical-quantum ensembleparagraph, immediatelybefore2.2.4. Physical104 shared; no2.2.4 included.

实际逐页查看原图范围：99, 100, 101, 102, 103, 104。独立从原PDF新渲染；已逐段逐式核当前源码。全部4页当前译文图均已实际查看。

## 数学与完整性

- 99-100 / 2.141-143：vec(AXB*)=(A tensor conjugate(B))vec(X) under row-order vectorization; expanding X=Eij gives J=vec(A)vec(B)*. A=B and A*A=I imply CP and TP; unitary specialization and scalar-environment representation retain the original conditions.
- 100-101 / 2.144-151：A=sum u_a x_a*, so Tr(A*X)=sum u_a*Xx_a. C_ab X D_ab*=v_b(u_a*Xx_a)y_b*, which sums to <A,X>B. Partial trace of C X D* kills unequal environment labels and returns the same sum. Natural rank-one operator is vec(B)vec(A)*, while J=B tensor conjugate(A); the bar is present on the original image and in the translation.
- 101 / 2.152-155：With n=dim X, replacement sigma=I/n gives K=vec(I)vec(I)*/n and J=I tensor I/n. Partial trace of J over output is I, with no normalized-Choi convention silently introduced. Density matrices linearly span L(X), so the stated uniqueness of the depolarizing channel is consistent.
- 102 / 2.156-161：Use uv^T, not uv*: vec(uv^T)=u tensor v, and transposition swaps the factors. Sum E_ab X E_ba* has (a,b) coefficient X(b,a), hence X^T. The swap has eigenvalue -1 on e_a tensor e_b-e_b tensor e_a for a!=b, establishing non-CP precisely when the stated dimension assumption holds.
- 102-103 / 2.162-169：The diagonal map kills each E_ab for a!=b and fixes E_aa, so both natural and Choi matrices are sum E_aa tensor E_aa. A e_a=e_a tensor e_a, A*A=I and environmental trace returns the diagonal map. Classical communication continuation over the source102/103 seam is fully retained.
- 103-104 / 2.170 and ordinary paragraphs：Classicality is invariance of the whole joint state under Delta tensor I, not merely a diagonal marginal. Invariant PSD states are block diagonal sum E_aa tensor K_a, K_a>=0; p(a)=Tr K_a, rho_a=K_a/p(a) for positive weights and any density matrix at zero weights give precisely the displayed CQ form. Ensemble eta(a)=p(a)rho_a and every condition on Sigma,p,rho are retained.

编号式完整顺序：2.141–2.170，共30个；普通文字、定义条件和跨页续文另行实际对照，不以编号计数代替全文审校。无SourceError新增、无待修项。

## 版面与身份

各两遍独立冷编均退出0，全部4页几何、提取文字、1.5倍像素与作者PDF逐页相同；两批共8页全图实际检查。字体正常，公式/矩阵无裁切或重叠。日志无实际溢出/缺字/未定义/重编请求。batch13末页稀疏是完整单元边界所致。

原B账本44个已批输入及其真实快照逐字节核同；未改B账本或任何作者正文。新批准字节复制到本册qa/approved-bytes/C/<SHA>/book/...，逐项记录如下：

- book/chapters/ch02-sec02-sub03.tex：`439542f5bd52c28d7c1bd4b9547ed38a1ad170499c34997190e1fec5493fbaea`；快照 `qa\approved-bytes\C\439542f5bd52c28d7c1bd4b9547ed38a1ad170499c34997190e1fec5493fbaea\book\chapters\ch02-sec02-sub03.tex`。
- book/chapters/ch02-sec02-sub03-part01.tex：`3cb574781eb8f756172ccdf92121c8da580204932ef6c078a5ce01bc88a272ff`；快照 `qa\approved-bytes\C\3cb574781eb8f756172ccdf92121c8da580204932ef6c078a5ce01bc88a272ff\book\chapters\ch02-sec02-sub03-part01.tex`。
- book/chapters/ch02-sec02-sub03-part02.tex：`0a3dc211a75ef5c9eca6dc2cfc06fb9dbc8a3703b294ffe0deae5b7882b49720`；快照 `qa\approved-bytes\C\0a3dc211a75ef5c9eca6dc2cfc06fb9dbc8a3703b294ffe0deae5b7882b49720\book\chapters\ch02-sec02-sub03-part02.tex`。

共享页99/101/104/108按全书连续输入检查；108末锚属于后续2.3，不算本节漏项。批准仅限本次完整小节及真实字节，不签全书。
