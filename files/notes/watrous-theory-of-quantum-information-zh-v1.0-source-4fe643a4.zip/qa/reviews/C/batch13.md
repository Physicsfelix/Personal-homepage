# Watrous 2.2.4 独立审校 C

状态：approved。译者 A；非作者审者 C。

原件 SHA256：`992de30011ff2ec70994256d6ad5f3a93f250a6f0d08fa4314bd0c9ea5156a36`；January2018预出版草稿，共598物理页。

Complete2.2.4 Extremalchannels, physical104 headingthrough108Example2.33finalextremalitysentence, before2.3Measurements. Physical108shared andEnd108deferred.

实际逐页查看原图范围：104, 105, 106, 107, 108。独立从原PDF新渲染；已逐段逐式核当前源码。全部4页当前译文图均已实际查看。

## 数学与完整性

- 104 / Lemma2.30 / 2.171-173：AQA* is PSD and has image in im A. Conversely Q=A+ P(A+)* is PSD. Pi=AA+ is the orthogonal projection onto im A, so PiP=P by the image condition, PPi=P by adjoint, and PiPPi=P. Both containments, the pseudoinverse, and operator order are faithfully retained.
- 105 / Theorem2.31 / 2.174-181：Linear independence of the Kraus family is explicitly assumed, giving injective M. MM*=J(Phi). A nontrivial convex decomposition yields positive Q0,Q1 with partial trace I. For v in ker P, lambda<v,Q0v>+(1-lambda)<v,Q1v>=0 forces both Q_i v=0; hence im Q_i subset im P=im M. Lemma2.30 supplies both R_i with no omitted direction.
- 106-107 / 2.182-190：Entrywise Tr_Y(vec(Aa)vec(Ab)*)=(Ab*Aa)^T. Therefore Tr_Y(MHM*)=sum H(a,b)(Ab*Aa)^T; transpose is complex-linear and does not conjugate H(a,b). Taking adjoints of sum Z_ab Ab*Aa=0 and exchanging a,b gives the displayed relation with Z*(a,b). Both Hermitian parts lie in the kernel and one is nonzero. Normalize H, then I+/-H>=0. Both perturbed Choi operators are PSD and have partial trace I by the zero relation; all two TP equalities are present.
- 107 / 2.191-193：Injective M has a left inverse L; MHM*=0 would imply H=L(MHM*)L*=0. Thus the perturbed channels are distinct, and their average is Phi. This closes the second contrapositive, not merely one implication. For the isometric example A*A=I is a single nonzero operator, satisfying the original criterion.
- 107-108 / Example2.33 / 2.194-198：The displayed 4x2 matrices have scaling 1/sqrt(6). Their Gram products are diag(2,1)/3, E10/3, E01/3, diag(1,2)/3, and the two diagonal products sum to I. If their linear combination vanishes, off-diagonal coefficients vanish separately and the two diagonal equations have coefficient determinant (4-1)/9=1/3 !=0. Thus all four are independent and the example is extreme. Every matrix entry, natural-ordering parenthesis, and final sentence is retained.

编号式完整顺序：2.171–2.198，共28个；普通文字、定义条件和跨页续文另行实际对照，不以编号计数代替全文审校。无SourceError新增、无待修项。

## 版面与身份

各两遍独立冷编均退出0，全部4页几何、提取文字、1.5倍像素与作者PDF逐页相同；两批共8页全图实际检查。字体正常，公式/矩阵无裁切或重叠。日志无实际溢出/缺字/未定义/重编请求。batch13末页稀疏是完整单元边界所致。

原B账本44个已批输入及其真实快照逐字节核同；未改B账本或任何作者正文。新批准字节复制到本册qa/approved-bytes/C/<SHA>/book/...，逐项记录如下：

- book/chapters/ch02-sec02-sub04.tex：`1720c527d252c077d76fb43ef02a72aec82937ebec21bcaa69be56e514e1bf03`；快照 `qa\approved-bytes\C\1720c527d252c077d76fb43ef02a72aec82937ebec21bcaa69be56e514e1bf03\book\chapters\ch02-sec02-sub04.tex`。

共享页99/101/104/108按全书连续输入检查；108末锚属于后续2.3，不算本节漏项。批准仅限本次完整小节及真实字节，不签全书。
