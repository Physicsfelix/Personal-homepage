param([string]$OutputDirectory = "build")
$ErrorActionPreference = "Stop"
if (-not (Get-Command latexmk -ErrorAction SilentlyContinue)) {
    throw "Please install TeX Live with XeLaTeX and latexmk, then run this script again."
}
Push-Location -LiteralPath $PSScriptRoot
try {
    & latexmk -norc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error "-outdir=$OutputDirectory" main.tex
    if ($LASTEXITCODE -ne 0) { throw "LaTeX compilation failed; inspect $OutputDirectory/main.log." }
} finally {
    Pop-Location
}
