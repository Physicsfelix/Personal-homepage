# 朱克和《算子代数导论》中文重排译本

依据用户提供的 Kehe Zhu, *An Introduction to Operator Algebras*（CRC Press，1993，ISBN 0-8493-7875-3）169页完整原件翻译与重排。固定原件身份见 `qa/source/identity.json`；源码中的原页与对象锚点用于回查。正文采用用户泛函分析I模板风格的视觉复原，封面重制。

原著三部分、二十六讲、全部编号小节、习题及其子问、证明中间步骤、无编号公式、前后置资料、12条书目与136个索引条目均纳入范围。原著疑点保留原式，并另标“译校注”；不以新增证明或习题答案替代原文。各单元的实际当前批准身份由 `qa/current-review-map.json` 与相应独立报告、已审字节副本共同确定；历史库存状态不代替当前批准。

## 编译

需要含 XeLaTeX、latexmk、CTeX、Fandol、Latin Modern、tcolorbox、TikZ 等标准包的 TeX Live。本版验收运行时为 TeX Live 2026。全部字体采用标准TeX运行时提供的字体，不依赖原书PDF、原工作区或私有字体。源码包不附编译缓存。

进入 `book` 目录运行：

```text
latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
```

输出 `book/build/main.pdf`。正式主入口无条件包含全书，缺少章节会直接报错。

### 修改正文后重建索引

原索引页码不能直接用作译本页码。本版为208处原索引引用设置对应出处锚点，再从真实TeX页码生成译本索引。同一条目中若多个原引用落在同一译页，会合并显示该页，并保留星号及全部原引用对应证据。原索引本身的页误以可见译校注说明。

Windows可在项目根目录运行 `./build.ps1`，它会编译、依据新页码重建索引、再次编译并检查索引固定点。重建索引另需 Python 3，索引脚本只使用标准库；可用 `./build.ps1 -Python '你的Python路径'` 选择解释器。

其他系统先执行上面的编译命令，再于项目根目录执行：

```text
python3 scripts/build_index.py --aux book/build/main.aux --write --report book/build/index-generation.json
```

然后重新编译，并执行下列只读检查：

```text
python3 scripts/build_index.py --aux book/build/main.aux --check
```

包内已保存与交付版本相配的完整索引，原样重编只需TeX运行时；正文改动后请按上述流程重新生成索引，避免原先合并显示的条目因改版分到不同页。

## 审校与验收证据

逐节语义核对、原编号盘点、编译、实际版面查看、目录/索引/链接核对、实际ZIP全新目录冷编和最终包审分别记录。编译输入清单见 `qa/compile-input-manifest.json`，逐节报告见 `qa/reviews`，真正已审字节副本见 `qa/approved-bytes`。最终包的外部审计如记录了本ZIP自身哈希，保留在包外以避免自指；包内提供不自指的验收说明。
