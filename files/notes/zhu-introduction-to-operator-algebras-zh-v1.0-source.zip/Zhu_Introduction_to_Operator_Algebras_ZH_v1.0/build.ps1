param([string]$Python = 'python')
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$bookDir = Join-Path $projectRoot 'book'
$indexScript = Join-Path $projectRoot 'scripts/build_index.py'
Push-Location $bookDir
try {
    & latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error '-outdir=build' main.tex
    if ($LASTEXITCODE -ne 0) { throw 'XeLaTeX/latexmk build failed.' }
    & $Python $indexScript --aux 'build/main.aux' --write --report 'build/index-generation.json'
    if ($LASTEXITCODE -ne 0) { throw 'Index generation failed; inspect missing anchors.' }
    & latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error '-outdir=build' main.tex
    if ($LASTEXITCODE -ne 0) { throw 'Final XeLaTeX/latexmk build failed.' }
    & $Python $indexScript --aux 'build/main.aux' --check
    if ($LASTEXITCODE -ne 0) { throw 'Index did not reach a fixed point.' }
    Write-Output (Join-Path $bookDir 'build/main.pdf')
} finally {
    Pop-Location
}
