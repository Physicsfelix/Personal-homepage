"""Read actual current files, independent ledgers, reports, and approved raw bytes."""
from pathlib import Path
import hashlib
import json
import re


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    root = Path(__file__).resolve().parents[1]
    identity = root / 'source/identity.json'
    if not identity.exists():
        identity = root / 'qa/source/identity.json'
    expected_source = json.loads(identity.read_text(encoding='utf-8'))['sha256']
    latest = {}
    for who in ['A', 'B', 'C', 'D']:
        path = root / f'qa/review-ledger-{who}.json'
        if not path.exists():
            continue
        ledger = json.loads(path.read_text(encoding='utf-8'))
        for row in ledger['records']:
            latest[(who, row['file'].replace('\\', '/'))] = row
    required = [root / 'book/main.tex']
    required += sorted((root / 'book/chapters').glob('*.tex'))
    required += sorted((root / 'book/matter').glob('*.tex'))
    rows, missing, stale = [], [], []
    for path in required:
        rel = path.relative_to(root).as_posix()
        chapter = re.match(r'ch(\d+)', path.name)
        if chapter:
            n = int(chapter[1])
            author = 'A' if n <= 5 else 'root' if n <= 7 else 'B' if n <= 15 else 'C'
            reviewer = 'C' if n <= 7 else 'A' if n <= 15 else 'B'
        elif path.name in ['part1.tex', 'part2.tex', 'part3.tex']:
            author, reviewer = {'part1.tex': ('A', 'C'), 'part2.tex': ('B', 'A'),
                                'part3.tex': ('C', 'B')}[path.name]
        elif path.name == 'index-entries.tex':
            author, reviewer = 'root', 'D'
        else:
            author, reviewer = 'root', 'A'
        row = latest.get((reviewer, rel))
        if row is None:
            missing.append({'file': rel, 'expected_author': author, 'expected_reviewer': reviewer})
            continue
        current = sha(path.read_bytes())
        if row.get('status') != 'approved' or row.get('sha256') != current:
            stale.append({'file': rel, 'actual_sha256': current, 'record': row})
            continue
        assert author != reviewer
        assert row.get('translator', '').split(' / ')[0] == author, (rel, row.get('translator'), author)
        if 'source_sha256' in row:
            assert row['source_sha256'] == expected_source
        snapshot = row.get('approved_bytes_snapshot') or row.get('approved_bytes')
        assert snapshot, ('No independently archived approved bytes', rel)
        if isinstance(snapshot, dict):
            snapshot = snapshot['path']
        snapshot_path = root / snapshot
        assert snapshot_path.read_bytes() == path.read_bytes(), ('Snapshot identity mismatch', rel)
        report = root / row['report']
        assert report.is_file() and report.stat().st_size, ('Missing report', rel)
        rows.append({'file': rel, 'sha256': current, 'translator': author, 'reviewer': reviewer,
                     'report': row['report'], 'report_sha256': sha(report.read_bytes()),
                     'approved_bytes_snapshot': snapshot,
                     'source_range': row.get('source_physical_pages', row.get('source_pages')),
                     'record': row, 'status': 'approved-current-actual-bytes-verified'})
    result = {'source_sha256': expected_source,
              'status': 'passed' if not missing and not stale else 'in-progress-not-release-approved',
              'required_book_unit_files': len(required), 'approved_current_book_files': len(rows),
              'missing': missing, 'stale': stale, 'units': rows,
              'scope': 'Current actual semantic/structural source identities only; no PDF visual, cold build or package claim.'}
    (root / 'qa/current-review-map.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'units'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
