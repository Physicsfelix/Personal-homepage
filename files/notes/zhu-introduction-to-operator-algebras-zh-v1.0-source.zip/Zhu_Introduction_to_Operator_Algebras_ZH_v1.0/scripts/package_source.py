"""Create a portable source candidate from actual frozen compiler inputs and QA bytes."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', type=Path)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--preliminary', action='store_true',
                        help='Explicitly label a pre-release candidate with outstanding final index acceptance')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / 'qa/compile-input-manifest.json').read_text(encoding='utf-8'))
    reviews = json.loads((root / 'qa/current-review-map.json').read_text(encoding='utf-8'))
    if not args.preliminary:
        assert reviews['status'] == 'passed' and reviews['approved_current_book_files'] == 166
        readiness = json.loads((root / 'qa/final-readiness-root.json').read_text(encoding='utf-8'))
        assert readiness['status'] == 'passed-for-candidate-packaging'
        assert readiness['PDF_sha256'] == manifest['verified_pdf_sha256']
    else:
        assert not reviews['stale']
        assert reviews['approved_current_book_files'] >= 165
        assert [r['file'] for r in reviews['missing']] in [[], ['book/matter/index-entries.tex']]
    for p, h in manifest['compile_inputs'].items():
        assert sha((root / p).read_bytes()) == h, p
    for p, h in manifest['index_generation_inputs'].items():
        assert sha((root / p).read_bytes()) == h, p
    assert not args.stage.exists() and not args.archive.exists()
    package = args.stage / 'Zhu_Introduction_to_Operator_Algebras_ZH_v1.0'
    package.mkdir(parents=True)
    selected = set(manifest['compile_inputs']) | set(manifest['index_generation_inputs'])
    selected.update(['README.md', 'build.ps1'])
    selected.update(p.relative_to(root).as_posix() for p in (root / 'scripts').glob('*.py'))
    # Keep actual semantic review records and approved raw bytes, never the original PDF or rendered images.
    for p in (root / 'qa').rglob('*'):
        if p.is_file() and p.suffix.lower() in {'.json', '.md', '.tex', '.sty', '.py', '.diff', '.txt'}:
            if 'cold-' in p.relative_to(root).as_posix() or 'release-stage' in p.parts:
                continue
            if p.suffix.lower() == '.tex' and any(part.lower().startswith('preview') for part in p.parts):
                continue
            selected.add(p.relative_to(root).as_posix())
    for rel in sorted(selected):
        p = root / rel
        assert p.is_file() and not p.is_symlink()
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
        target = package / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, target)
    package_info = {
        'status': 'preliminary-cold-test-candidate-not-final-release' if args.preliminary else 'candidate-for-actual-cold-rebuild',
        'compile_input_count': len(manifest['compile_inputs']),
        'paired_verified_PDF_sha256': manifest['verified_pdf_sha256'],
        'original_PDF_not_required_or_included': True,
        'auxiliary_PNG_evidence': 'Actual visual-review images stay in the working project; textual reports, hashes, approved bytes and source-page mappings are included.',
        'all_required_inputs_observed_and_packaged': True,
        'final_index_approval_pending_at_candidate_creation': reviews['status'] != 'passed',
    }
    (package / 'qa/package-candidate-info.json').write_text(json.dumps(package_info, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    with zipfile.ZipFile(args.archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in sorted(package.rglob('*')):
            if p.is_file():
                z.write(p, p.relative_to(args.stage).as_posix())
    with zipfile.ZipFile(args.archive) as z:
        assert z.testzip() is None
        for rel, h in manifest['compile_inputs'].items():
            assert sha(z.read(package.name + '/' + rel)) == h
    print(json.dumps({'archive': str(args.archive), 'sha256': sha(args.archive.read_bytes()),
                      'bytes': args.archive.stat().st_size, 'members': len(z.namelist()),
                      'stage': str(package), 'preliminary': args.preliminary}, ensure_ascii=False))


if __name__ == '__main__':
    main()
