# C：A第1讲两索引锚位置差分复审v2

结论：当前两文件的受控锚位置差分通过。C独立读取实际before/after，并将before与C原批准真实字节副本及SHA逐字比较相同；再确认每个文件只移动一个IndexMark token，删除该token后全文件原字节相等，总长度相同。原文字、公式、编号、其他锚、编码及换行全部保持。

- ch01-sec03：idx004p4从定理1.4环境前移动到begin、原标题和label之后，即Alaoglu定理的陈述框内部。该对象正是原physical15/printed4的定理1.4，已通过此前完整源页审校。位置改动旨在让锚随定理实际框移到该页，避免环境前锚停在上页。
- ch01-sec04：idx075p6从定理1.6环境前移动到begin/label之后，即局部凸空间定理的陈述框内部。该对象正是原physical17/printed6的定理1.6，符合索引实际对应定义/定理语境。

此次批准确认实际代码位置和精确字节差分，并承接原文语义批准；main03实际目标页落点须由A在新PDF另外确认，不冒称已经从未生成的新PDF核过。两文件当前真实原字节副本已独立保存，ledger-C旧身份标superseded而保留链。

|文件|移动锚|新SHA256|当前已审字节|
|---|---|---|---|
|book/chapters/ch01-sec03.tex|idx004p4|06cece0d9171c40f8f29dada6001c59c70fb8404fb9ace2cc951807d3ce21aef|qa/approved-bytes/C/2026-10-26-C-A-index-layout-v2/book/chapters/ch01-sec03.tex|
|book/chapters/ch01-sec04.tex|idx075p6|758b97a70dd99d575360c933dec53f9a91816738bd3b2077716f3a4acc2646c0|qa/approved-bytes/C/2026-10-26-C-A-index-layout-v2/book/chapters/ch01-sec04.tex|
