# B对C两短陈述框布局差分复审，v2

root要求将定理23.2与命题24.7两短框作为完整框排版。本轮B实际读当前两个文件，与B先前完整语义审批准的真实字节副本作精确差分；仅目标框前加入局部begingroup和tcbset breakable=false，框后结束group。相应文字、公式、条件、编号、索引/源页锚及其余每字节一致。局部设置在证明前结束，不改变其他框。旧完整源审证据承接，当前新PDF实际版面另待main03。


## book/chapters/ch23-sec02.tex

旧SHA 9f38e4568b183b9f680b5a585607c860638d371f601551136be15a9f892be3d3；新SHA dd93f0e9d59112037a4f74e48250d96c4dc88d77d5fd71cb645d81ced67c4f25。

```diff
--- B-approved-before
+++ current-layout-after
@@ -77,6 +77,8 @@
 
 下面去掉具有循环向量这一假设。
 
+\begingroup
+\tcbset{textbook statement/.append style={breakable=false}}
 \begin{originaltheorem}{23.2}\label{thm:23.2}
 设 $T$ 是可分 Hilbert 空间 $H$ 上的正规算子。则存在 $\sigma(T)$ 上的有限正 Borel 测度 $\mu$，使得 Gelfand 变换
 \[
@@ -84,6 +86,7 @@
 \]
 可延拓为从 $\A_T$ 到 $L^\infty(\sigma(T),d\mu)$ 上唯一的 $C^*$ 同构 $\Gamma^*$。而且，测度 $\mu$ 在相互绝对连续的意义下唯一，空间 $L^\infty(\sigma(T),d\mu)$ 也是唯一的（与 $\mu$ 的选择无关）。
 \end{originaltheorem}
+\endgroup
 \begin{originalproof}
 由于 $\A_T$ 是阿贝尔的，它有分离向量。令 $x$ 为 $\A_T$ 的单位分离向量，$H_0=[\A_Tx]$（$\{Sx:S\in\A_T\}$ 的闭包）。定义 $\Phi:\A_T\to\B(H_0)$，令 $\Phi(S)$ 为 $S$ 在 $H_0$ 上的限制。由定理\OrigRef{thm}{22.6} 的证明，$\Phi$ 是从 $\A_T$ 到 $\B(H_0)$ 中一个阿贝尔 von Neumann 代数 $\mathcal B_T$ 上的 $C^*$ 同构。显然，$\Phi$ 将 $\A[T]$ 映到 $\mathcal B[\Phi(T)]$ 上，后者为由 $\Phi(T)$（以及 $H_0$ 上的恒等算子）生成的 $\B(H_0)$ 的 $C^*$ 子代数。由于 $\Phi$ 也是强算子连续的（也是弱算子连续的），可知 $\mathcal B_T$ 是由 $\Phi(T)$（以及 $H_0$ 上的恒等算子）生成的 $\B(H_0)$ 中的 von Neumann 代数。回顾一下，$C^*$ 同构保持谱，因此 $\sigma(T)=\sigma(\Phi(T))$。于是，若
 \[
```

## book/chapters/ch24-sec05.tex

旧SHA 67250eb449032ce43fa565570298f1766816eb88c0bb3ac4b7688de55ac66808；新SHA 2cbb90f1989d1e13548faded05074891e77c9f6d9e01deba3093e6f38cc7ab41。

```diff
--- B-approved-before
+++ current-layout-after
@@ -21,6 +21,8 @@
 另一方面，$Q$ 的值域是 $\A$ 中每个算子的约化子空间，所以对 $T\in\A$ 有 $QT=TQ$。因此 $Q$ 是大于等于 $P$ 的中心投影。于是 $Z(P)\le Q$，从而 $Z(P)=Q$。
 \end{originalproof}
 
+\begingroup
+\tcbset{textbook statement/.append style={breakable=false}}
 \begin{originalproposition}{24.7}\label{prop:24.7}
 设 $P,Q$ 是作用在 $H$ 上的 von Neumann 代数 $\A$ 中的两个投影。以下条件等价：
 \begin{enumerate}[label=(\alph*)]
@@ -29,6 +31,7 @@
 \item 存在非零投影 $P_1\le P$ 及 $Q_1\le Q$，使得 $P_1\sim Q_1$。
 \end{enumerate}
 \end{originalproposition}
+\endgroup
 \SourcePage{144}
 \begin{originalproof}
 先证明 (c) 蕴含 (b)。令 $V$ 为从 $Q_1$ 的值域到 $P_1$ 的值域上的偏等距算子（属于 $\A$），所以 $V^*V=Q_1$ 且 $VV^*=P_1$。令 $x$ 为 $Q_1$ 的值域中的非零向量。则
```
