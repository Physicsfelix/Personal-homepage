# B对C第21/23讲题名PDF书签差分复审，v2

前次完整源审报告及其真实副本保留。本轮实际读取当前两个wrapper，并与B前次批准的真实字节副本逐字节差分，只有数学标题token加入texorpdfstring；原可见L^infty标题、全部input及其余每一字节相同。新增PDF fallback为L∞，与源题名数学意义相同。合编实际PDF书签由root另验。

## ch21

旧SHA：069f9e56dd9a7f3c4ce621855c285eecee6b1fc27abc5d66115c6b39fbff07cb；新SHA：1e22afb4193bbef1e1a3e2934121b2a68eb5bc9635796bf50983876316c185d3。

```diff
--- B-approved-v1
+++ current
@@ -1,5 +1,5 @@
 % Source: physical135--139, printed124--128.
-\OriginalLecture{21}{$L^\infty$ 作为 von Neumann 代数}
+\OriginalLecture{21}{\texorpdfstring{$L^\infty$}{L∞} 作为 von Neumann 代数}
 \input{chapters/ch21-sec01}
 \input{chapters/ch21-sec02}
 \input{chapters/ch21-sec03}
```

## ch23

旧SHA：2874f4d2a966cfb76868a98a780fb3ac5a5b6deb1952d5747591623aabdd4416；新SHA：ca45ba3f4c1e33ccfcf6190fdb3f511f773981c24a17374efa1e5cdcc4d4562c。

```diff
--- B-approved-v1
+++ current
@@ -1,5 +1,5 @@
 % Source: physical145--150, printed134--139.
-\OriginalLecture{23}{$L^\infty$ 函数演算}
+\OriginalLecture{23}{\texorpdfstring{$L^\infty$}{L∞} 函数演算}
 \input{chapters/ch23-sec01}
 \input{chapters/ch23-sec02}
 \input{chapters/ch23-sec03}
```

