# B对第23讲习题标题局部布局差分复审，v3

B实际读取当前文件并与先前完整源审批准的真实bytes比较。唯一区别是在SourcePage139前插入一行\Needspace{6\baselineskip}；删除该完整新增行后与旧批准bytes逐字节相同。习题23标题、两题的全部文字/公式、SourcePage139及其他每字节未变。此设置让源锚与标题/首题一起申请空间，避免main03物理124页底孤悬标题；实际落点必须在main04新PDF再看。

旧SHA 6b44a07458344d66f54c0f4b51c2357a6c57468cdb75412900346d8958031893；新SHA 82177c585d11bd6f88f6298f94b9e2024cc068847072ea3aaf16610074eb6206。新真实批准副本 qa/approved-bytes/B/C-exercise23-heading-v3/book/chapters/ch23-exercises.tex。

```diff
--- B-approved-before
+++ current-Needspace-after
@@ -1,4 +1,5 @@
 % Source: physical150, printed139; bothcompleteexercises.
+\Needspace{6\baselineskip}
 \SourcePage{139}
 \originalexercisesheading{23}
 \begin{originalexercise}{23.1}\label{exercise:23.1}
```
