# 独立语义审校：copyright

译者root；审者A（未参与该单元翻译）。

源：original.pdf，物理[5]。已实际打开相应原页PNG，逐段、逐对象与当前TeX/JSON核对，OCR只定位。

当前文件：`book/matter/copyright.tex`

SHA256：`367b25d29203480be5e306a95a8865871a3a7e0e01232d2cef6dc5196e348891`

实际核对：核CIP数据含ZhuKehe1961、ISBN、QA分类/年份、512.55dc20与93-7172；四个法律/资料段及地址、版权年份、书号、印次数字1–0、无酸纸语句完整。

发现的未闭环语义/遗漏问题：无。

结论：批准当前哈希的源文语义与完整性。此批准不含编译、成品看图、索引最终页码、冷构建或ZIP验收。

已审原字节副本：`qa/approved-bytes/A/367b25d29203480be5e306a95a8865871a3a7e0e01232d2cef6dc5196e348891/book/matter/copyright.tex`。
