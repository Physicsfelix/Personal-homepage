# A独立原页语义审校：ch14-exercises

译者B，审者A（非译者）。原件固定SHA e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。原物理页[99]均已实际view_image逐页打开，逐段逐式对当前实际文件审读；修订文件另核精确修复牵连处。

4题完整含14.3(a–c)三分问及第22讲定义引用、14.4一维/可数态子集与直和同构两要求，均无新增答案。

文件`book/chapters/ch14-exercises.tex`；SHA256`f89df5e33919f6bc9a0be56d477977c1419f6cd6206b08d83a93f08bf40fac3a`；当前字节语义/完整性批准，无未闭环差异。不涵盖编译、输出看图、冷构建与实际ZIP。

真实已审字节副本：`qa/approved-bytes/A/f89df5e33919f6bc9a0be56d477977c1419f6cd6206b08d83a93f08bf40fac3a/book/chapters/ch14-exercises.tex`。
