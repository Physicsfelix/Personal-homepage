# A独立源文语义审校：ch10-exercises

译者B；独立审者A。原件固定SHA e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。源物理[76]已实际view_image看图，当前文件逐段逐式核查。

9题及所有双分问完整，含10.5两个±、10.6平方根单调+逆序、10.7逆命题、10.9连续函数要求；无添答案。

当前文件`book/chapters/ch10-exercises.tex`；SHA256`1840540d4428a5c37699aeed588bca313a497fad4c44dcea989f4b9e8560fcf1`。语义/完整性当前字节批准，无未闭环差异；不包含编译/成品看图/包验收。

已审原字节副本`qa/approved-bytes/A/1840540d4428a5c37699aeed588bca313a497fad4c44dcea989f4b9e8560fcf1/book/chapters/ch10-exercises.tex`。
