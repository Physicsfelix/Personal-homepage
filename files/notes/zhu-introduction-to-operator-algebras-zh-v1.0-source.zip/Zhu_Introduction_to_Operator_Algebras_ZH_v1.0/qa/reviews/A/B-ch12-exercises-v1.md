# A独立原页语义审校：ch12-exercises

译者B，审者A（非译者）。原件固定SHA e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。原物理页[87]均已实际view_image逐页打开，逐段逐式对当前实际文件审读；修订文件另核精确修复牵连处。

5题全核，12.1唯一分解+道路连通，12.2一般C*失败构造要求，12.3两个引理，12.5三当且仅当及V*原未定义符号保留+应T*注均正确。

文件`book/chapters/ch12-exercises.tex`；SHA256`5744a3f31e71a86e7540adf78f122d8808db9678a1081ff988c164977d71a69e`；当前字节语义/完整性批准，无未闭环差异。不涵盖编译、输出看图、冷构建与实际ZIP。

真实已审字节副本：`qa/approved-bytes/A/5744a3f31e71a86e7540adf78f122d8808db9678a1081ff988c164977d71a69e/book/chapters/ch12-exercises.tex`。
