# A独立审校：index-generation-logic

作者root；审者A。

逐行代码核：原136条/208引用/56星断言；208请求ID唯一且正式模式核实际IndexMark恰一次；aux读实际idx标签页且拒重号/非阿拉伯；实际页分组，同词同页合并，任一原星即保星并优先选该实际锚作链接；QA保留全部208原对应，不用原页数字冒充译页。合成测试已通过嵌套aux、重号/非数字拒绝、非星+星同页、全136/208/56与2注保留；详qa/reviews/A/index-generator-tests/results.json。当前逻辑批准，不批准未齐锚的草TeX或实际最终页。实际aux的新鲜度须由root正式编译输入哈希/日志另绑定，随后实际生成器check与PDF链接核闭环。

文件`scripts/build_index.py`；SHA256`ba9c0ba243e8776d40ed6a867143c3ab5a91236c18bc9d7817eac20ba067d18b`。批准限于上述范围，真实已审字节副本`qa/approved-bytes/A/ba9c0ba243e8776d40ed6a867143c3ab5a91236c18bc9d7817eac20ba067d18b/scripts/build_index.py`。最终PDF页码/目录/链接/冷构建/包验收需另有实际证据。
