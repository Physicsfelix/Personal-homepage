# A独立源文语义审校：ch11-exercises

译者B；独立审者A。原件固定SHA e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。源物理[81]已实际view_image看图，当前文件逐段逐式核查。

4题全核，4正元素两两交换、绝对值正负部分解、商范数式、正锥封闭相加/非负伸缩两要求均完整；idx090p70在正锥命名处。

当前文件`book/chapters/ch11-exercises.tex`；SHA256`145193cfdf4fb6c0843374c37f277db80fc629efe90e3bfcb4b4153e08d3c3a3`。语义/完整性当前字节批准，无未闭环差异；不包含编译/成品看图/包验收。

已审原字节副本`qa/approved-bytes/A/145193cfdf4fb6c0843374c37f277db80fc629efe90e3bfcb4b4153e08d3c3a3/book/chapters/ch11-exercises.tex`。
