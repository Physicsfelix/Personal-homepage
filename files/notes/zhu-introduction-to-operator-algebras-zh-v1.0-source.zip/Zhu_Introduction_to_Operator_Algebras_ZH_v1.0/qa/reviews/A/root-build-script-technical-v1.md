# A独立技术审校：build-script-technical

作者root，审者A；全部当前文件实际读取。

只读逐行核：由PSScriptRoot求项目，PushLocationbook，latexmk-XeLaTeX标准选项与outdirbuild，显式exitcode失败即抛错；调用随包scripts/build_index.py读取实际build/main.aux并write/report，复编后check固定点，finally恢复目录；Python可参数指定且脚本标准库。不含硬编码用户目录/隐藏原PDF/私有字体路径。此为逻辑审，不冒称已执行当前冻结书的干净构建。

全书TeX静态另查未见绝对文件输入、shellwrite18、私有CJK字体设定。动态依赖闭合与运行时包/字体实际加载仍由最终冷构建fls另验。

文件`build.ps1`；SHA256`8117f3a1859f09ae2619f8d8ac0cfd6ca6b8aa49edfdca6266a4e3f36d61ce78`；批准当前技术设置/逻辑范围。真字节副本`qa/approved-bytes/A/8117f3a1859f09ae2619f8d8ac0cfd6ca6b8aa49edfdca6266a4e3f36d61ce78/build.ps1`。
