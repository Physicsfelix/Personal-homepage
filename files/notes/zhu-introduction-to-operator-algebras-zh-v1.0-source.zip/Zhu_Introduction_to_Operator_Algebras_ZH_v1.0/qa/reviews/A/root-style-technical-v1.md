# A独立技术审校：style-technical

作者root，审者A；全部当前文件实际读取。

核A4/24mm/11pt主入口建议、Fandol由ctexbook提供、LatinModern三个公开字体；分色breakable环境手动编号、脚注CJK防断钩子、hyperref字体/颜色/页眉等配置，无私有字体或外部源输入。此style是视觉复原且注释诚实，未声称原TeX。实际页眉碰撞/跨页/脚注链接仍需最终PDF视觉与动作另核。

全书TeX静态另查未见绝对文件输入、shellwrite18、私有CJK字体设定。动态依赖闭合与运行时包/字体实际加载仍由最终冷构建fls另验。

文件`book/style/textbook-template.sty`；SHA256`c03b2346e991871bcc62324c083a2a00adfabc05e4cea75edc6f5c499e800732`；批准当前技术设置/逻辑范围。真字节副本`qa/approved-bytes/A/c03b2346e991871bcc62324c083a2a00adfabc05e4cea75edc6f5c499e800732/book/style/textbook-template.sty`。
