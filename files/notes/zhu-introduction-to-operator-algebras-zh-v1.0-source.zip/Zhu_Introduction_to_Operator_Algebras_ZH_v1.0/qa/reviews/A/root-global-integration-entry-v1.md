# A独立审校：global-integration-entry

作者root；审者A。

已核32原TOC条目对应全26讲/3分部/前言/书目/索引。正式入口所有input无条件，26讲顺序1–26、不用IfFileExists/includeonly静默跳章；前后置cover/half-title/series/title/copyright/dedication/preface/bibliography/index-intro/index-entries/back-cover全纳入，SourcePages和IndexMarks在各实际单元。tableofcontents使用译本真实分页。仅批准此入口内容覆盖与顺序，不替代各单元独审及最后PDF目录/链接/分页验收。

文件`book/main.tex`；SHA256`774957171c210b6d77c294715f523a94666117db74c9d181284275edab32fa7c`。批准限于上述范围，真实已审字节副本`qa/approved-bytes/A/774957171c210b6d77c294715f523a94666117db74c9d181284275edab32fa7c/book/main.tex`。最终PDF页码/目录/链接/冷构建/包验收需另有实际证据。
