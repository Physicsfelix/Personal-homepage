# A独立技术审校：preamble-technical

作者root，审者A；全部当前文件实际读取。

核先加载本包style，再本书标题/章名讲号/数号/TOC0覆盖；手动原号类型前缀引用、SourcePage/IndexMark/IndexRef均本地标签，IndexRef显示真实pageref且超链指实际锚。数学宏无内积槽变更或全局共轭约定；译校注与SourceFootnote区分。额外包均TeX标准包，未引用源PDF/外路径。

全书TeX静态另查未见绝对文件输入、shellwrite18、私有CJK字体设定。动态依赖闭合与运行时包/字体实际加载仍由最终冷构建fls另验。

文件`book/preamble.tex`；SHA256`109ffb06d78fba61f96a547066b5dd463161876750675110b83a406182cfb433`；批准当前技术设置/逻辑范围。真字节副本`qa/approved-bytes/A/109ffb06d78fba61f96a547066b5dd463161876750675110b83a406182cfb433/book/preamble.tex`。
