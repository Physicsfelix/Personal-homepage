# A独立源文审校与修订回查：ch09-exercises

译者B，审者A。原图物理[70]已实际看图；本轮重新读取实际当前文件，核初轮完整逐段审读及精确修订牵连处。

7题所有子要求已全核；9.4商及极大理想空间问题、9.5闭集表示及何时极大、9.6提问、9.7原条件均保留。新SourceError独核：Def9.1(d)确实要求保单位，而源Ex3.7另明定hom保单位显示一般hom不自动保单位；零映射满足压缩且不保单位，故缺条件注正确，不提供原题答案替换。

文件`book/chapters/ch09-exercises.tex`；SHA256`803289d71f1e58a33beb5b8acd275adfdeec7aef53553ff6e05879632ef1e4cb`；当前字节语义及来源完整性批准，无未闭环差异。批准不涉及编译/输出视觉/包。

真正已审字节副本：`qa/approved-bytes/A/803289d71f1e58a33beb5b8acd275adfdeec7aef53553ff6e05879632ef1e4cb/book/chapters/ch09-exercises.tex`。
