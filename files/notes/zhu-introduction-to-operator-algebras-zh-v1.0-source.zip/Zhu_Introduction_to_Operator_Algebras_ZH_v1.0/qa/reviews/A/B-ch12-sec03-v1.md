# A独立原页语义审校：ch12-sec03

译者B，审者A（非译者）。原件固定SHA e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。原物理页[85, 86, 87]均已实际view_image逐页打开，逐段逐式对当前实际文件审读；修订文件另核精确修复牵连处。

复数极表示、Th12.8构造/唯一性每步与闭包/核公式、Cor12.9全段；两处RanW已按原图恢复无左闭包，右RanQ闭包保留。

文件`book/chapters/ch12-sec03.tex`；SHA256`106eddef17e32015bb6be868cff7592ece22ecf6456a704971a8ed5ff7b3b301`；当前字节语义/完整性批准，无未闭环差异。不涵盖编译、输出看图、冷构建与实际ZIP。

真实已审字节副本：`qa/approved-bytes/A/106eddef17e32015bb6be868cff7592ece22ecf6456a704971a8ed5ff7b3b301/book/chapters/ch12-sec03.tex`。
