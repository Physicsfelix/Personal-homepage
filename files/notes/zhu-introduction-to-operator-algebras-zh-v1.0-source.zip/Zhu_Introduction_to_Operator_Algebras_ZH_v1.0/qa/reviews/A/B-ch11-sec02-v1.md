# A独立源文语义审校：ch11-sec02

译者B；独立审者A。原件固定SHA e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。源物理[78, 79]已实际view_image看图，当前文件逐段逐式核查。

Th11.2(a–d)与分段正负函数、所有谱/范数/乘积式、唯一性无常数多项式段完整；已回查B新恢复p(−x2)原缺n。SourceError两处独核：原f+(t)=0应f+(0)=0，极限中p应pn，均保原+另注。正部/负部索引在Th11.2正确。

当前文件`book/chapters/ch11-sec02.tex`；SHA256`d3b81480d383cef4b2e118160d1fd6201f3767202aeeaec418005e8b9a776a60`。语义/完整性当前字节批准，无未闭环差异；不包含编译/成品看图/包验收。

已审原字节副本`qa/approved-bytes/A/d3b81480d383cef4b2e118160d1fd6201f3767202aeeaec418005e8b9a776a60/book/chapters/ch11-sec02.tex`。
