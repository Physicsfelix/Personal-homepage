# A精确差分独立复核：ch13-sec01

译者B，审者A；实际读取A旧批准原字节与当前文件。

idx058p78唯一锚整行从Prop13.3外移到begin/label之后；总字节数不变，删除这条完整锚行（含其换行）后所有bytes完全相同，正文/公式/SourcePage/其他锚不变。位置现在在实际框内，最终03名页落点待A再核。

旧SHA`a11ecb85675f6c0374ba43d79ea20fc8ea4292f43ef609438562b9ad4c9dcd97`；新SHA`1f26d50cda9a26b213badd6e5d32fb9288ef1bb0b99da193e6721a9dc70a87cb`。批准当前字节的纯布局/锚定位修订并承接旧全源语义审。未预签main03可见分页/实际索引结果。

新真实已审字节副本`qa/approved-bytes/A/1f26d50cda9a26b213badd6e5d32fb9288ef1bb0b99da193e6721a9dc70a87cb/book/chapters/ch13-sec01.tex`。
