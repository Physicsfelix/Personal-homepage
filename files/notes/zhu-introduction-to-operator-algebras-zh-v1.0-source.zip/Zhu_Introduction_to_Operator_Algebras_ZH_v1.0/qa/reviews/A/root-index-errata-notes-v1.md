# A独立审校：index-errata-notes

作者root；审者A。

独核两条可见译校注：原索引StoneWeierstrass7*与原Th1.9实printed6/physical17；正平方根原64*与原Th10.5后定义实printed63/physical74。两注未改原元数据，译页指实际定义/定理，文字准确；索引中文与原条目此前已全136行批准。

文件`qa/inventory/index-errata-root.json`；SHA256`2953474dae2b08bccb109ee04b92a528cba727415181f129bb9cd53796eda560`。批准限于上述范围，真实已审字节副本`qa/approved-bytes/A/2953474dae2b08bccb109ee04b92a528cba727415181f129bb9cd53796eda560/qa/inventory/index-errata-root.json`。最终PDF页码/目录/链接/冷构建/包验收需另有实际证据。
