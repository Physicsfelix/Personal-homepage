# 全局原目录32项独立源文审校

译者root；审者A。源物理8–9已实际打开2倍原页图：qa/A-source-visual/root-p008.png、root-p009.png。

逐行核前言ix、3部分原1/49/97、26讲全部英文标题/讲号/原印刷起页、书目154与索引155；32项顺序及页码一一相符。全部给出的中文标题与原英文语义相符（空格/数学样式由正式包装提供）；原页号是来源定位，不用作译本TOC页码。

批准当前转录JSON及其Chinese字段：`qa/inventory/original-global-toc.json`，SHA256`b00b3b4ace071aee15389cccbc1c2c3e443da9c0048d6367a318d08b6f622eef`。真实已审字节副本`qa/approved-bytes/A/b00b3b4ace071aee15389cccbc1c2c3e443da9c0048d6367a318d08b6f622eef/qa/inventory/original-global-toc.json`。

另已读当前book/main.tex：所有26讲、3部分及前后置无条件input，顺序与原目录吻合，使用tableofcontents生成译本页码。目前还未审最终PDF目录页及交互链接；此报告不批准全书正文、最终main版本或最终页码。
