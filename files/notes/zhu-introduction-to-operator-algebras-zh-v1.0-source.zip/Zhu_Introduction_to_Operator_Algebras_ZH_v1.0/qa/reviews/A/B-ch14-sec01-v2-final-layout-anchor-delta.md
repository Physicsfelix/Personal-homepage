# A精确差分独立复核：ch14-sec01

译者B，审者A；实际读取A旧批准原字节与当前文件。

仅在Prop14.2前后增加局部分组与breakable=false；精确删除该局部前后控制段即可逐字节还原A旧批准副本。组范围不含证明，正文/公式/SourcePage/索引锚全相同。新03完整框及相邻分页待视觉复核。

旧SHA`5cf50842516bd24a76292bf65bd72e05c85d2e0aa551cc78e156b3b0f45b454c`；新SHA`a89ea885b216b997d09d1c8a6b09e7ec8c19f1cb3344ee83beb408bb2ac6560f`。批准当前字节的纯布局/锚定位修订并承接旧全源语义审。未预签main03可见分页/实际索引结果。

新真实已审字节副本`qa/approved-bytes/A/a89ea885b216b997d09d1c8a6b09e7ec8c19f1cb3344ee83beb408bb2ac6560f/book/chapters/ch14-sec01.tex`。
