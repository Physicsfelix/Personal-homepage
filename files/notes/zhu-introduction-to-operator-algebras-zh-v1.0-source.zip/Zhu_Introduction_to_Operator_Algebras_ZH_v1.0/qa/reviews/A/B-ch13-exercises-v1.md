# A独立原页语义审校：ch13-exercises

译者B，审者A（非译者）。原件固定SHA e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。原物理页[94]均已实际view_image逐页打开，逐段逐式对当前实际文件审读；修订文件另核精确修复牵连处。

7题所有要求完整。13.5源错误式保留；M2diag(0,1)与(1,1)/sqrt2向量纯态取1/2反例独核，rank1向量态确为纯态。13.7无限维无界Hermitian注同前独核。

文件`book/chapters/ch13-exercises.tex`；SHA256`356d13744cd4af83927ec777d6fa462352da6bfc27f16167850ad3159fc4b7e6`；当前字节语义/完整性批准，无未闭环差异。不涵盖编译、输出看图、冷构建与实际ZIP。

真实已审字节副本：`qa/approved-bytes/A/356d13744cd4af83927ec777d6fa462352da6bfc27f16167850ad3159fc4b7e6/book/chapters/ch13-exercises.tex`。
