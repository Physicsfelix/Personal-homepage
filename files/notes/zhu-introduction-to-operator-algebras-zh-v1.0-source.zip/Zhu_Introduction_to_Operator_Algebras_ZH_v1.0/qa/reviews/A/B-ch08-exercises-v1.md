# A独立语义审校：ch08-exercises

译者B；独立审者A。

源PDF固定SHA：e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c；原物理页[65]均已实际view_image看图，对照当前文件逐段逐式审读。

文件`book/chapters/ch08-exercises.tex`；当前SHA256`9263541dfb7149d3fdc058510eefd235a9d4c1edd8dd847404d52653077f1380`。

9题所有要求逐项核，8.2唯一分解+交换等价，8.6三条件，8.9正规/酉/投影三个当且仅当均完整，无新增答案。

未闭环差异：无。批准当前字节的语义与来源完整性；不涵盖编译、输出看图和交付包。

已审字节副本`qa/approved-bytes/A/9263541dfb7149d3fdc058510eefd235a9d4c1edd8dd847404d52653077f1380/book/chapters/ch08-exercises.tex`。
