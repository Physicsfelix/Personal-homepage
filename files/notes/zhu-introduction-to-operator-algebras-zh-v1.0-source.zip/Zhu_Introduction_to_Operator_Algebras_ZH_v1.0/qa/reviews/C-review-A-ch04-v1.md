# C独立审校：A第4讲 v1

结论：全部6个当前固定文件通过原页完整语义/公式/全部习题/索引锚独立审校。译者A；审者C未参与撰写。编译、排版和交付包不在此结论中。

源SHA256 e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c；C实际查看physical32–37所有6页。逐页渲染和三张双页联系图在qa/C-source-visual/review-A/。每个当前文件完整读入并复核handoffSHA后独立保存真实原字节。

- 4.1/包装：讲题、四节/习题输入、交换代数导语、独立定义4.1非平凡及乘法条件、phi(1)=1、命题4.1单位向量反证/x0归一化/乘逆公式逐段逐式对应。
- 4.2：例4.2–4.4全部点值泛函、矩阵n>1与迹唯一性、H∞更大空间及[3][4]引用完整。
- 4.3：定义4.5极大理想空间及弱星拓扑、命题4.2紧Hausdorff和完整闭像证明准确；定理4.3三个方向全核：kerphi真极大、极大理想闭性/商除代数/Gelfand–Mazur、同核两泛函相同，所有单位分解及最后差式准确。
- 4.4：所有人名与引入文字保留。引理4.4三个条件、g实部界、|g|<=|2r-g|、g_r分子r²g与分母z²(2r-g)、最大值界及固定z后r趋无穷全部完整。定理4.5完整长证明逐段逐式核对：N无可逆元素、范数1三式、归一x与整函数级数、指数及其逆、引理得N平方闭、x1/y1分解、平方恒等式/Jordan积、两个N中元素、差平方恒等式、最后一页phi差平方和xy闭性收束均保留；未换简证。
- 7题逐题完整，包括一般交换代数真极大理想、解析函数Banach代数逐点运算与范数估计、L∞乘法泛函问句、B(H)问句和开映射陈述；无新增答案。
- 当前6个索引锚在真实定义、调用定理及人名处，源位置准确。

|文件|SHA256|真实已审副本|
|---|---|---|
|book/chapters/ch04-exercises.tex|8ff7c89358356038d4c3930072ebd539604c448982e77e4d7221a95b30f64ec9|qa/approved-bytes/C/2026-10-26-C-A-ch04-v1/book/chapters/ch04-exercises.tex|
|book/chapters/ch04-sec01.tex|50665e3cf2ef1f87056eda3c8c3a5ed386e6c16b622d9d1a82c71ca8483ca015|qa/approved-bytes/C/2026-10-26-C-A-ch04-v1/book/chapters/ch04-sec01.tex|
|book/chapters/ch04-sec02.tex|6cbd4f3683e486f34827ca5341416667f0009c30fa5ca99f6f8ce99b975c55b6|qa/approved-bytes/C/2026-10-26-C-A-ch04-v1/book/chapters/ch04-sec02.tex|
|book/chapters/ch04-sec03.tex|d6ec668fd064b6e2c18e009cb77d2fc99a0210d3a022dbdc0432fff07cf332db|qa/approved-bytes/C/2026-10-26-C-A-ch04-v1/book/chapters/ch04-sec03.tex|
|book/chapters/ch04-sec04.tex|1112fad65e9402fa88f3d7ed6f363730cb523825530046ae42e5ef65548ebc9e|qa/approved-bytes/C/2026-10-26-C-A-ch04-v1/book/chapters/ch04-sec04.tex|
|book/chapters/ch04.tex|f9a605cfb5ba5975222f77aa0c364403300c727d0247f88e4c5ee4d5cfc720a9|qa/approved-bytes/C/2026-10-26-C-A-ch04-v1/book/chapters/ch04.tex|

未闭环翻译问题：无。后续更改须另审当前差分/牵连内容并更新SHA。
