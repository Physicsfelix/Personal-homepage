from pathlib import Path
import json,re,hashlib,datetime,fitz
p=Path('work/zhu-operator-algebras');q=p/'qa/reviews/D-final-index-navigation'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def write(f,o):f.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
source_sha=sha(p/'source/original.pdf');pdf_sha=sha(p/'qa/full-main-04/main.pdf');aux_sha=sha(p/'qa/full-main-04/main.aux');index=p/'book/matter/index-entries.tex';index_sha=sha(index)
assert source_sha=='e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c'
assert pdf_sha=='edf36f70c78cfdecc51e9d011810c5188974aee703b9409d64779368fc29a5b4'
assert aux_sha=='bbc8efd6f99007fe6cb0745216634dbe9e928ba9906e47114d393fdc3f22f6ec'
assert index_sha=='0767392bf7f733feeddc7bb63593ebfb2312792f27a912c0731dd1e26c8354a6'
entries=json.loads((p/'qa/inventory/index-entries-root.json').read_text(encoding='utf-8'))['entries'];tex=index.read_text(encoding='utf-8');b=re.split(r'(?m)^% (idx\d+);',tex)[1:];blocks={b[i]:b[i+1] for i in range(0,len(b),2)}
for e in entries:
 assert e['ChineseTeX']+'\\enspace' in blocks[e['id']]
 text=blocks[e['id']].replace('$C^*$','C*').replace('$L^\\infty$','L∞')
 assert '('+e['English']+')' in text,e['id']
nav=json.loads((q/'32-toc-bookmarks.json').read_text(encoding='utf-8'))
for r in nav:r['status']='approved-actual-title-crop-viewed-and-printed-page-checked'
write(q/'32-toc-bookmarks.json',nav)
refs=json.loads((q/'208-reference-targets.json').read_text(encoding='utf-8'))
for r in refs:r['review_status']='approved-current-visible-target-context-viewed'
write(q/'208-reference-targets.json',refs)
links=json.loads((q/'203-visible-links.json').read_text(encoding='utf-8'));merged=[r for r in links if len(r['original_references'])>1]
snapshot=p/f'qa/approved-bytes/D/{index_sha}/book/matter/index-entries.tex';snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(index.read_bytes());assert snapshot.read_bytes()==index.read_bytes()
actual_views=[f'source/pages/page-{n:03}.png' for n in [8,9,166,167,168]]+[str((q/f'original-p{n:03}.png').relative_to(p)).replace('\\','/') for n in [17,74]]+[str(x.relative_to(p)).replace('\\','/') for x in sorted(q.glob('current-p*.png'))]+[str(x.relative_to(p)).replace('\\','/') for x in sorted(q.glob('targets-*.png'))]+[str(x.relative_to(p)).replace('\\','/') for x in sorted(q.glob('toc-landings-*.png'))]+[str(x.relative_to(p)).replace('\\','/') for x in sorted(q.glob('expanded-*.png'))]
report={'reviewer':'D / zhu_final_index','translator':'root','status':'approved','review_type':'independent-complete-index-source-and-current-PDF-navigation-acceptance','source_sha256':source_sha,'source_pages':169,'source_index_physical_pages':[166,167,168],'additional_actual_source_views':[8,9,17,74],'file':'book/matter/index-entries.tex','sha256':index_sha,'pdf':'qa/full-main-04/main.pdf','pdf_sha256':pdf_sha,'pdf_pages':142,'aux':'qa/full-main-04/main.aux','aux_sha256':aux_sha,'approved_bytes_snapshot':str(snapshot.relative_to(p)).replace('\\','/'),'counts':{'original_index_entries':136,'original_page_references':208,'original_stars':56,'visible_current_index_links':203,'toc_links':32,'bookmarks':32,'before_object_anchors_rechecked':28},'source_semantic_review':{'all_136_original_visible_terms_and_references_checked_against_current_Chinese_English_entries':True,'original_alphabetic_order_retained':True,'star_meaning_retained':True,'math_display_normalization':['C* to typeset C^*','L∞ to typeset L^infty'],'original_name_spellings_preserved':['Tychonorff','Uryson'],'notes_independently_verified':[{'id':'idx094','original_index':'64*','actual_source_printed':63,'actual_source_physical':74,'current_printed':52,'finding':'positive square root is defined after Theorem 10.5 at bottom of original p63; visible note and actual target agree'},{'id':'idx120','original_index':'7*','actual_source_printed':6,'actual_source_physical':17,'current_printed':5,'finding':'Theorem 1.9 is visible on original p6; visible note and actual target agree'}]},'navigation_verification':{'method':'Independent brace-depth AUX parser; independent original-reference page grouping; actual PDF link rectangle text; PDF named destinations and page labels; actual target context crops; TOC and bookmark destinations; no call to build_index.py','coordinate_origin':'Empirically confirmed bottom-origin raw y for named destinations from resolve_names/get_links; height - y aligns actual rendered headings/objects. Example idx004p4: raw y771.60 -> top y70.29 on physical13, theorem1.4; bookmark chapter18: raw y773.86 -> top68.03 on physical11 above actual chapter1 title.','merged_reference_groups':merged,'old_three_drift_cases_current':[{'id':'idx004p4','actual_object':'Theorem1.4','printed':4,'physical':13},{'id':'idx075p6','actual_object':'Theorem1.6','printed':5,'physical':14},{'id':'idx058p78','actual_object':'Proposition13.3','printed':64,'physical':73}],'all_208_target_crops_actually_viewed':True,'all_32_heading_landing_crops_actually_viewed':True,'all_28_before_object_anchors_actual_page_and_object_checked':True},'actual_viewed_images':actual_views,'new_vs_reused_evidence':{'new':'All source-index visible-page review and current index semantic review; every main04 index/TOC/bookmark reference check; all 208 current target crop contexts; current index and TOC full pages; two original errata pages; all 32 actual heading-landings; actual byte snapshot.','reused_inputs_with_new_checks':'Root original-index inventory supplies explicit IDs/source refs, independently checked against original visible index. Prior A 28-object inventory used only as a candidate-risk list; all 28 reread against current AUX, destinations and actual main04 crops. Existing A/B/C source-to-body semantic approvals outside index are acknowledged, not re-signed.','not_claimed':'No final A signature invented. No complete body mathematics re-review, whole-book visual inspection, cold build, archive audit or publishing is claimed by D.'},'issues':[],'evidence_files':['qa/reviews/D-final-index-navigation/208-reference-targets.json','qa/reviews/D-final-index-navigation/203-visible-links.json','qa/reviews/D-final-index-navigation/28-before-object-current.json','qa/reviews/D-final-index-navigation/32-toc-bookmarks.json'],'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
write(p/'qa/reviews/D-final-index-navigation.json',report)
md=f'''# D 独立终审：索引与导航

结论：**通过**。审者 D / zhu_final_index 不是本索引译者；译者为 root。本结论仅绑定下列实际文件和实际 main04 PDF，不替代其他审者的正文审校、全书版面验收或冷重建验收。

- 原书：Kehe Zhu, *An Introduction to Operator Algebras*, CRC 1993，169 物理页。实际 SHA256 `{source_sha}`。
- 索引源码：`book/matter/index-entries.tex`，实际 SHA256 `{index_sha}`。
- 当前 PDF：`qa/full-main-04/main.pdf`，142 页，实际 SHA256 `{pdf_sha}`。
- 当前 AUX：`qa/full-main-04/main.aux`，实际 SHA256 `{aux_sha}`。
- 批准的原始字节已实际另存：`{report['approved_bytes_snapshot']}`；另存后逐字节相等核验通过。

## 原索引完整性与译义

实际打开原书物理 166、167、168 页的完整可见索引页，并逐项对照当前源码和译本物理 139、140、141 页。全部 136 个词条按原序保留，中文术语与英文原名对应；原 208 个出处、56 个星号均保留在逐出处数据中。星号说明的首次定义或使用含义与原书一致。C* 和 L∞ 的数学排版变化仅为类型设置。Tychonorff、Uryson 的原索引拼法实际保留，正文中相应定理的落点已经核对，不据惯用拼法静默替换原索引。

两条可见译校注均另行回看原页：物理 74／印刷 63 页底在定理 10.5 后定义 positive square root，原索引却列 64*；物理 17／印刷 6 页底为定理 1.9，原索引却列 7*。当前译校注准确标明差异，链接分别落至译本印刷 52、5 页的真实定义和定理。两条注没有混入原作者正文。

## 当前 main04 链接与真实落点

审者编写独立的括号深度 AUX 解析与检查脚本，没有调用 `scripts/build_index.py`。依据每一个原始出处的当前 AUX 页码自行分组，以组内任一原出处带星则保留星的规则复算，与当前索引每个实际 `IndexRef` 对照；208 出处形成 203 个可见页码组。五组同页合并分别为 idx024、idx058、idx096、idx113、idx124，详见机器证据。

实际读取并核对全部 **203 个当前 PDF 索引链接矩形内的可见页码和星号**，每个均与预期完全相同；目标 named destination、实际物理页及该页标签一致。不是只检查 AUX 数值：为全部 **208 个原出处** 按当前真实目标坐标生成目标上下文图，并已实际逐卡看完 `targets-01.png` 至 `targets-13.png`。它们分别显示对应术语、定义、定理、证明、例子、习题或章节讨论。完备化、左乘、极分解导语和单位分解习题四个上下文较短的落点又另看 `expanded-*.png` 放大图。

named destination 坐标由实际对象验证后统一：本 PDF 的 `resolve_names/get_links` 返回 named-destination 原始 y 保留 PDF 下原点；目标页可见图／文本采用 `page.height - raw_y`。例如 idx004p4 原始 y771.60 转为顶原点约70.29，对准物理13上的定理1.4；章1书签 raw y773.86 转为约68.03，在物理11真实章标题上方。没有把原始 y 直接当作顶原点。

原先列出的 28 个框／标题前锚点已全部以当前 AUX、对象标签、真实目标页和上述实际目标图复核，均同页且落至相应对象之前或内部适当位置。三个历史漂移点当前分别为 idx004p4→定理1.4／译4／物理13，idx075p6→定理1.6／译5／物理14，idx058p78→命题13.3／译64／物理73，均正确。此处使用 A 的旧清单只作风险候选表，结论来自本次 main04 独立检查。

## 目录、书签和实际标题

实际看原书目录物理8、9页、当前目录物理7、8页。前言、3部分、26讲、参考文献、索引共32项均保留，顺序和标题意义匹配原书。实际目录显示的译页均是各目标页的页标签。32个目录链接和32个书签全部另行读取并与当前TOC及 named destination 对照，且逐项实际查看 `toc-landings-01.png` 至 `toc-landings-04.png` 内的真实标题落点。第21、23讲的 L∞ 在书签和真实标题均保留。前言物理9、三部分物理10／49／90、26讲及参考文献物理138、索引物理139均相符。

## 实际看图和证据边界

本次新看：原索引166–168；原目录8–9；原注释回核17、74；当前目录7–8；当前索引139–141；208个真实目标上下文；32个标题落点；四个扩展风险图。当前索引三页完整查看后，未见缺行、被裁词条、重叠或不可读的页码／星号。三个文件身份在写报告、归档字节和签账本时再次重算一致。

本次不声称对正文所有页重新做数学或版面审校；已有A/B/C正文源审仍由其原有记录负责。没有补造A终审签名，没有再次运行 authoring marker，也没有修改任何 book、样式、生成器或其他审者账本。

问题清单：无未闭环项。结构化总报告在 `qa/reviews/D-final-index-navigation.json`；逐出处、逐链接、28对象、32目录书签证据与独立检查脚本在同名目录内。
'''
(p/'qa/reviews/D-final-index-navigation.md').write_text(md,encoding='utf-8')
row={'unit':'index-entries','file':'book/matter/index-entries.tex','translator':'root','reviewer':'D / zhu_final_index','source_sha256':source_sha,'source_physical_pages':[166,167,168],'sha256':index_sha,'status':'approved','review_type':'full-source-semantic-completeness-and-final-PDF-index-navigation','report':'qa/reviews/D-final-index-navigation.md','structured_report':'qa/reviews/D-final-index-navigation.json','approved_bytes_snapshot':str(snapshot.relative_to(p)).replace('\\','/'),'pdf_sha256':pdf_sha,'aux_sha256':aux_sha,'actual_source_views':[x for x in actual_views if x.startswith('source/') or '/original-' in x],'actual_current_visual_evidence':[x for x in actual_views if x not in [f'source/pages/page-{n:03}.png' for n in [8,9,166,167,168]] and '/original-' not in x]}
write(p/'qa/review-ledger-D.json',{'reviewer':'D / zhu_final_index','source_sha256':source_sha,'records':[row]})
print('D approved actual index bytes; ledger, JSON report, Markdown report and raw byte snapshot written.');print('report sha256',sha(p/'qa/reviews/D-final-index-navigation.md'));print('snapshot sha256',sha(snapshot))
