from pathlib import Path
import re,json,hashlib,fitz
from PIL import Image,ImageDraw,ImageFont
p=Path('work/zhu-operator-algebras'); q=p/'qa/reviews/D-final-index-navigation'; q.mkdir(exist_ok=True)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def write(name,o):(q/name).write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
def groups(s):
 out=[]; n=0; start=0
 for i,c in enumerate(s):
  if c=='{':
   if n==0:start=i+1
   n+=1
  elif c=='}':
   n-=1
   if n==0:out.append(s[start:i])
 return out
aux={}
for l in (p/'qa/full-main-04/main.aux').read_text(encoding='utf-8').splitlines():
 if l.startswith('\\newlabel'):
  z=groups(l[len('\\newlabel'):]); vals=groups(z[1]); aux[z[0]]={'number':vals[0],'printed':vals[1],'dest':vals[3]}
source=json.loads((p/'qa/inventory/index-entries-root.json').read_text(encoding='utf-8')); entries=source['entries']; tex=(p/'book/matter/index-entries.tex').read_text(encoding='utf-8'); doc=fitz.open(p/'qa/full-main-04/main.pdf'); names=doc.resolve_names()
blocks=re.split(r'(?m)^% (idx\d+);',tex)[1:]; bytex={blocks[i]:blocks[i+1] for i in range(0,len(blocks),2)}; assert list(bytex)==[e['id'] for e in entries]
alllinks=[(i,l) for i in range(138,141) for l in doc[i].get_links()]; linksbydest={l['nameddest']:(i,l) for i,l in alllinks}; assert len(linksbydest)==203
sourcefiles=list((p/'book/chapters').glob('*.tex')); loc={}
for f in sourcefiles:
 t=f.read_text(encoding='utf-8')
 for m in re.finditer(r'\\IndexMark\{([^}]+)\}',t):loc[m[1]]={'file':str(f.relative_to(p)).replace('\\','/'),'offset':m.start(),'before':t[max(0,m.start()-180):m.start()],'after':t[m.end():m.end()+240]}
refs=[]; grouping=[]; issues=[]
for e in entries:
 expected={}
 for r in e['references']:
  a=aux['idx:'+r['id']]; n=names[a['dest']]; pg=doc[n['page']]; x,y=n['to']; yy=pg.rect.height-y
  assert pg.get_label()==a['printed'],(r,a,n)
  text=pg.get_text('text',clip=fitz.Rect(55,max(0,yy-28),550,min(pg.rect.height,yy+100)))
  refs.append(dict(id=r['id'],original_printed=r['original_printed_page'],original_star=r['star'],translated_printed=a['printed'],physical=n['page']+1,named_destination=a['dest'],raw_destination=[x,y],top_origin_y=yy,target_visible_context=text,source_tex_locator=loc[r['id']]))
  expected.setdefault(a['printed'],[]).append(r)
 rendered=re.findall(r'\\IndexRef\{([^}]+)\}\{([^}]*)\}',bytex[e['id']]); actual={}
 for id,st in rendered:
  a=aux['idx:'+id]; assert a['printed'] not in actual
  actual[a['printed']]=(id,st)
 assert set(actual)==set(expected),(e['id'],actual,expected)
 for page,rr in expected.items():
  id,st=actual[page]; assert st==('*' if any(r['star'] for r in rr) else '')
  a=aux['idx:'+id]; physical,l=linksbydest.pop(a['dest']); rect=l['from']; shown=doc[physical].get_text('text',clip=rect+(-.7,-.7,.7,.7)).strip().replace(' ','').replace('\n','')
  assert shown==page+st,(id,shown,page+st)
  assert l['page']==names[a['dest']]['page']
  grouping.append(dict(entry=e['id'],id=id,original_references=[r['id'] for r in rr],expected_printed=page+st,visible=shown,index_physical=physical+1,rectangle=list(rect),destination=a['dest'],physical_target=l['page']+1))
assert not linksbydest
before=json.loads((p/'qa/reviews/A/final-main02/index-before-object-audit.json').read_text(encoding='utf-8')); risky=[]
for b in before:
 a=aux['idx:'+b['index_anchor']]; o=aux[b['object_label']]; n=names[a['dest']]; target=names[o['dest']]; assert n['page']==target['page'],b
 risky.append(dict(index=b['index_anchor'],object=b['object'],index_page=a['printed'],object_page=o['printed'],physical=n['page']+1,index_dest=list(n['to']),object_dest=list(target['to']),distance_y=n['to'][1]-target['to'][1]))
write('208-reference-targets.json',refs);write('203-visible-links.json',grouping);write('28-before-object-current.json',risky)
# Every destination crop for actual visible target-object review, with nearby complete lines.
font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18)
def montage(rows,prefix,per=12):
 for start in range(0,len(rows),per):
  cards=[]
  for title,physical,yy in rows[start:start+per]:
   pg=doc[physical-1]; clip=fitz.Rect(59,max(0,yy-30),538,min(pg.rect.height,yy+100)); pix=pg.get_pixmap(matrix=fitz.Matrix(1.4,1.4),clip=clip,alpha=False); im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples); card=Image.new('RGB',(690,225),'white'); ImageDraw.Draw(card).text((4,2),title,font=font,fill='black');card.paste(im,(4,31));cards.append(card)
  sheet=Image.new('RGB',(1380,225*((len(cards)+1)//2)),(215,215,215))
  for k,card in enumerate(cards):sheet.paste(card,((k%2)*690,(k//2)*225))
  sheet.save(q/f'{prefix}-{start//per+1:02}.png')
montage([(r['id']+' | '+str(r['physical'])+' / '+r['translated_printed'],r['physical'],r['top_origin_y']) for r in refs],'targets',16)
# Full current translated index and two translated TOC pages.
for n in [7,8,139,140,141]:
 pix=doc[n-1].get_pixmap(matrix=fitz.Matrix(1.6,1.6));pix.save(q/f'current-p{n:03}.png')
write('initial-check.json',{'pdf_sha256':sha(p/'qa/full-main-04/main.pdf'),'aux_sha256':sha(p/'qa/full-main-04/main.aux'),'index_sha256':sha(p/'book/matter/index-entries.tex'),'pages':len(doc),'entries':len(entries),'original_references':len(refs),'original_stars':sum(r['original_star'] for r in refs),'visible_links':len(grouping),'source_english_and_chinese_to_be_visually_reviewed':True,'coordinate_conversion':'PyMuPDF get_links/resolve_names named destinations retain PDF bottom-origin y; actual extracted page coordinates and rendered crop use page.height - raw_y.'})
print(json.dumps(json.loads((q/'initial-check.json').read_text(encoding='utf-8')),ensure_ascii=True))
