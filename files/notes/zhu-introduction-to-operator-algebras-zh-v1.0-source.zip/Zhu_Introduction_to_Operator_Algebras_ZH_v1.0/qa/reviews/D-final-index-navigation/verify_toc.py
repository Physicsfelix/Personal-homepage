from pathlib import Path
import fitz,json,re
from PIL import Image,ImageDraw,ImageFont
p=Path('work/zhu-operator-algebras');q=p/'qa/reviews/D-final-index-navigation';d=fitz.open(p/'qa/full-main-04/main.pdf');names=d.resolve_names()
def groups(s):
 out=[];n=0
 for i,c in enumerate(s):
  if c=='{':
   if n==0:st=i+1
   n+=1
  elif c=='}':
   n-=1
   if n==0:out.append(s[st:i])
 return out
rows=[groups(x[len('\\contentsline'):]) for x in (p/'qa/full-main-04/main.toc').read_text(encoding='utf-8').splitlines() if x.startswith('\\contentsline')];toc=d.get_toc(False);assert len(rows)==len(toc)==32
links={l['nameddest']:(i,l) for i in [6,7] for l in d[i].get_links()};checks=[];font=ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',18);cards=[]
original=json.loads((p/'qa/inventory/original-global-toc.json').read_text(encoding='utf-8'));assert len(original)==32
for k,(r,b,src) in enumerate(zip(rows,toc,original)):
 typ,title,printed,dest=r; n=names[dest];pg=d[n['page']];assert pg.get_label()==printed;assert b[2]==n['page']+1;assert b[3]['nameddest']==dest
 i,l=links.pop(dest);assert l['page']==n['page'];line=d[i].get_text('text',clip=fitz.Rect(60,l['from'].y0-1,535,l['from'].y1+2));assert printed in line
 y=pg.rect.height-n['to'][1]; text=pg.get_text('text',clip=fitz.Rect(60,y,535,y+230))
 checks.append({'order':k+1,'source':src,'toc_type':typ,'toc_title_tex':title,'bookmark_visible_title':b[1],'printed_page':printed,'physical_target':n['page']+1,'dest':dest,'raw_y':n['to'][1],'top_origin_y':y,'toc_visible_line':line,'target_title_context':text,'status':'pending-actual-view'})
 pix=pg.get_pixmap(matrix=fitz.Matrix(1.4,1.4),clip=fitz.Rect(60,max(0,y-4),535,min(pg.rect.height,y+230))),
 pix=pix[0];im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples);card=Image.new('RGB',(680,365),'white');ImageDraw.Draw(card).text((4,2),f'{k+1:02}: {b[1]} | physical {n["page"]+1}',font=font,fill='black');card.paste(im,(4,32));cards.append(card)
assert not links
for start in range(0,32,8):
 sheet=Image.new('RGB',(1360,1460),(215,215,215))
 for j,card in enumerate(cards[start:start+8]):sheet.paste(card,((j%2)*680,(j//2)*365))
 sheet.save(q/f'toc-landings-{start//8+1:02}.png')
(q/'32-toc-bookmarks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2),encoding='utf-8')
# Enlarged low-context anchors and errata reference originals.
refs=json.loads((q/'208-reference-targets.json').read_text(encoding='utf-8'))
for id in ['idx026p85','idx073p90','idx088p75','idx102p123']:
 r=next(r for r in refs if r['id']==id);pg=d[r['physical']-1];y=r['top_origin_y'];pg.get_pixmap(matrix=fitz.Matrix(1.7,1.7),clip=fitz.Rect(60,max(0,y-130),535,min(pg.rect.height,y+230))).save(q/f'expanded-{id}.png')
print('32 TOC and bookmarks matched actual destinations and actual printed page labels; four title-contact sheets saved.')
