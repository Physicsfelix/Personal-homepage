# C独立审校：A第2讲 v1

结论：7个当前文件的完整原页语义、全部公式与证明中间行、7道习题、原书疑点注和索引锚审校通过。译者A；独审C未参与撰写。编译、译本渲染和包审不在本报告范围。

源PDF SHA256 e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。实际查看physical19–25全部7页：qa/C-source-visual/review-A/contact-018-019.jpg、contact-020-021.jpg、contact-022-023.jpg、contact-024-025.jpg。没有把OCR用作公式权威。当前文件均完整读取、对比来源，并复算handoff身份后保存原字节副本。

逐单元核对：

- ch02包装及2.1：讲题、结合代数与复标量域、含幺和单位唯一性、定义2.1(a)(b)的单位范数及次乘性完整。标题与五节/习题输入完整。
- 2.2：最简单C的例子及例2.2–2.6全部保留；C(K)、B(H)及矩阵识别、H-infinity、计数测度L1卷积、Fubini四行估计、单位函数、闭双边理想商范数、紧算子理想及Calkin代数均逐段逐式核对，跨页结尾完整。定义/例共一组编号、与命题组独立。
- 2.3：定义2.7和所有可逆性说明、开映射定理、Fourier双边序列判据与5.2/6.3引用、Fredholm的闭值域/核余核条件及Atkinson出处齐全。命题2.1完整Neumann级数、关于p一致的Cauchy估计、左右逆两行和范数界全部保留。命题2.2开球半径与因式顺序准确。命题2.3从1/(2||x^-1||)到级数x_n^-1 x、界2、逆元差估计全部准确，未删中间式。
- 2.4：定理2.4连通分支、开闭正规子群、陪集和离散商群全部保留。证明各并集非空交、求逆封闭、两个共轭包含及最后陪集段齐全。原书可见证明误印normal subgroup of G0(A)已原样保持；SourceError指出应为G(A)准确。局部连通说明也独核：范数开球凸，足以支持该结论；一般连通空间的开集不足。
- 2.5：例2.9–2.13及所有交叉引用完整；绕数、B(H)平凡指标、Calkin错误Q(A)字样与其解释、Fredholm指标原符号dimkerT*-dimkerT均保留。例2.12错误结论未静默修正；修订注的反例独立核算：w把D映入右半平面，主log解析，f=exp(i log w)有e^-pi/2<|f|<e^pi/2，逆有界；log f=i log w+2pi ik的虚部ln|w|无界，所以无有界解析对数。交换Banach代数G0为指数像的说明由局部log及有限乘积核验通过。该注明确属于译校注，未替代作者正文。
- 7道习题：2.1的2.9/2.12、2.2有限维、2.3导数范数两项、2.4两个行列式与第二个lambda无I、2.5有限/无限维单满射、2.6一般Banach空间算子范数复合、2.7商范数均逐题完整。未新增习题答案。2.4的lambda应理解lambda I注与矩阵类型一致。
- 索引：各锚实际位于相应定义、定理、Fredholm说明或例中；未借原页号虚构译本页码。

当前SHA及真实已审字节：

|文件|SHA256|副本|
|---|---|---|
|book/chapters/ch02-exercises.tex|45003ffaf918ce88d00bc596e5d1c26869496709b8a2f7a738b1cf5661e2fedf|qa/approved-bytes/C/2026-10-26-C-A-ch02-v1/book/chapters/ch02-exercises.tex|
|book/chapters/ch02-sec01.tex|c10c6c502a73e0d2210377aa74e54ecc3ead755c673b1850d95b5346627a7d5b|qa/approved-bytes/C/2026-10-26-C-A-ch02-v1/book/chapters/ch02-sec01.tex|
|book/chapters/ch02-sec02.tex|0e00f36e24f738307a20c671d18dba580ef6a61e70ddf2dec02622772ae36618|qa/approved-bytes/C/2026-10-26-C-A-ch02-v1/book/chapters/ch02-sec02.tex|
|book/chapters/ch02-sec03.tex|3ffd3b8589a366e2e24605c492b6b8298913511db1bb3ab291965e4400939616|qa/approved-bytes/C/2026-10-26-C-A-ch02-v1/book/chapters/ch02-sec03.tex|
|book/chapters/ch02-sec04.tex|1a0fafc5274e59ebcc63b8ff417e8253150ba857d6b7c45872b5cd427148b0f3|qa/approved-bytes/C/2026-10-26-C-A-ch02-v1/book/chapters/ch02-sec04.tex|
|book/chapters/ch02-sec05.tex|7d6b33fca783572f33b383954b91e76650c90e2fae50c76dd759e748bc1bcc1d|qa/approved-bytes/C/2026-10-26-C-A-ch02-v1/book/chapters/ch02-sec05.tex|
|book/chapters/ch02.tex|dbace14572623adc915b8250d886f1f393eb5ad81aeac76d786d02115905cdd9|qa/approved-bytes/C/2026-10-26-C-A-ch02-v1/book/chapters/ch02.tex|

未闭环翻译问题：无。任何后续改动需审差分并更新SHA。
