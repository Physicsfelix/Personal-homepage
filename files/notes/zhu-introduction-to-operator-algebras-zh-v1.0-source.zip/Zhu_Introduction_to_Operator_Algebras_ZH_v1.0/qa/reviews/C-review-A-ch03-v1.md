# C独立审校：A第3讲 v1

结论：全部6个当前固定文件通过原页完整语义/公式/全部习题/索引锚独立审校。译者A；审者C未参与撰写。编译、排版和交付包不在此结论中。

源SHA256 e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c；C实际查看physical26–31所有6页。逐页渲染和三张双页联系图在qa/C-source-visual/review-A/。每个当前文件完整读入并复核handoffSHA后独立保存真实原字节。

- 3.1/包装：讲题The Spectrum，四节与习题输入完整；定义3.1谱与预解集、复参数非可逆条件、交换值域/一般特征值类比、原may not even exist措辞完整。
- 3.2：例3.2–3.7全部保留，包括C(K)像、H∞像的闭包、矩阵与无限维无特征值乘法算子、L1双边Fourier表达及5.2/6.3引用、Calkin本质谱和Fredholm、含幺同态谱包含与满同构等号。
- 3.3：定理3.1非空谱完整反证，固定有界线性泛函、两次差商/预解恒等式/负平方导数、两行范数估计、Liouville与Hahn–Banach调用全部逐式核对；定理3.2构造Phi(z)=z1及等距满同构；定理3.3闭性/圆盘界及Neumann可逆因式全部保留。
- 3.4：独立定义3.8、最佳两端说明、2×2幂零矩阵、矩阵最大特征值模、L1的Fourier上确界均保留。命题3.4逆元y(1-xy)^-1x+1、四行展开、右逆式和两个原无证明推论3.5/3.6准确。
- 11题全部核对：3.2非空紧集/可分括号、3.3移位、3.4共轭谱、3.5逆谱、3.6正整数、3.7极大阿贝尔的三结论、3.8–3.10矩阵条件、3.11任意含谱开集和delta量词完整，无额外答案。
- 10个索引锚实际位于相应定义/例/调用定理，源页对应正确。

|文件|SHA256|真实已审副本|
|---|---|---|
|book/chapters/ch03-exercises.tex|0163920f67d344511a604900c6d8d83fde44ec23743ff0f85dadd8af4fe7261a|qa/approved-bytes/C/2026-10-26-C-A-ch03-v1/book/chapters/ch03-exercises.tex|
|book/chapters/ch03-sec01.tex|69c9921de56198c89236abc97c444c1fe6d5bf42833d3d80b240dcf68f47f1a5|qa/approved-bytes/C/2026-10-26-C-A-ch03-v1/book/chapters/ch03-sec01.tex|
|book/chapters/ch03-sec02.tex|38acec5ffeb4901717a9960b156b8d5704c5f0da0b60ca71f99a0d7aa38d388b|qa/approved-bytes/C/2026-10-26-C-A-ch03-v1/book/chapters/ch03-sec02.tex|
|book/chapters/ch03-sec03.tex|a33b59a60095c3b5d957ebab82c39fd2696a3fee96c565287569119b7e2ba72f|qa/approved-bytes/C/2026-10-26-C-A-ch03-v1/book/chapters/ch03-sec03.tex|
|book/chapters/ch03-sec04.tex|753d48585ccf1c1d079641ea988d0c16edeffddfae7d39a73fa91e7a8987e40d|qa/approved-bytes/C/2026-10-26-C-A-ch03-v1/book/chapters/ch03-sec04.tex|
|book/chapters/ch03.tex|15481b16e3f2733a4d818f2c60f201357ad05e01c1f043d9aa1f890df9b5abfd|qa/approved-bytes/C/2026-10-26-C-A-ch03-v1/book/chapters/ch03.tex|

未闭环翻译问题：无。后续更改须另审当前差分/牵连内容并更新SHA。
