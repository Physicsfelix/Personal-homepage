# C独立审校：A第5讲v1

结论：全部7个当前固定文件通过完整原页语义/公式/所有习题/索引锚及SourceError独审。译者A，独审C未参与这些内容的撰写。编译/译本看图/包审不在此报告中。

源SHA256 e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c。C实际打开查看physical38–44全部7页，证据qa/C-source-visual/review-A-root/对应逐页PNG与双页联系图。所有文件完整读入，对应当前handoffSHA复算相同后保存真实原字节。

- 5.1：极大理想空间回顾、弱星紧Hausdorff、Gelfand定义5.1及压缩/非单非满/空空间可能性全部对应。
- 5.2：命题5.1双向可逆性与极大理想核论证、推论5.2两条显示式、定理5.3交换元素的和积谱包含及所列所有逆元生成子代数证明完整。
- 5.3：解析在闭圆盘邻域的明确解释、幂级数绝对收敛和f(x)定义、定理5.4全部A0生成元及参数区域、交换逆元等价、两谱相同、Gelfand谱映射全部中间行、Riesz推广段齐全。
- 5.4：Taylor与Laurent系数两个Cauchy式及各圆周条件完整，原Laurent式确缺i而Taylor有i；SourceError正确，独核常数函数的n=0积分即应含1/(2pi i)。谱半径定理5.5完整liminf/limsup、预解函数外域Laurent展开、系数唯一性、发散域、最后谱依赖/半径不依赖代数说明无删漏。
- 5.5：定理5.6两向及2^n归纳式、例5.2的f两处负号及卷积平方L1范数7（独立算得系数1,-2,-1,2,1绝对值和7）、例5.3实部虚部分解/自伴满射证明、例5.4与第8讲引用完整。
- 全部7题逐题核；5.2的∞条件缺失和标量反例f(z)=z正确：非正幂幂级数对应1/z=0处解析而z不可去。5.6双交换子错误的C[0,1],S={1}反例独核正确：两次交换子均全A、最小含幺闭代数为常数。原题均保留，未以新解答替换。全部7索引锚源词位置准确。

|文件|SHA256|真实已审副本|
|---|---|---|
|book/chapters/ch05-exercises.tex|a2f8f4a400b0fb7a880867d7a9189c2bd2c8a652742a55aa58ece00ae5b47339|qa/approved-bytes/C/2026-10-26-C-A-ch05-v1/book/chapters/ch05-exercises.tex|
|book/chapters/ch05-sec01.tex|f730cd8145326f2a3d224fed9d77253cbdbca0fa7cad8cd6eed64c3b9e362c02|qa/approved-bytes/C/2026-10-26-C-A-ch05-v1/book/chapters/ch05-sec01.tex|
|book/chapters/ch05-sec02.tex|87285270904ace6e08b86cfdbd30b9551a464bce1f24f08df325a98e16c73b34|qa/approved-bytes/C/2026-10-26-C-A-ch05-v1/book/chapters/ch05-sec02.tex|
|book/chapters/ch05-sec03.tex|b787f13f91fc60fa20ce27488e39c15f39f825c71af8d74d0e29ba42fb19c853|qa/approved-bytes/C/2026-10-26-C-A-ch05-v1/book/chapters/ch05-sec03.tex|
|book/chapters/ch05-sec04.tex|6a56f5e6c873cf38cba15bf6e5176c5a8f67529e0099fe02364719a02e969942|qa/approved-bytes/C/2026-10-26-C-A-ch05-v1/book/chapters/ch05-sec04.tex|
|book/chapters/ch05-sec05.tex|bb4e3edd595e576a6f3c00abdf4d765fd8a2092dcc903db6f577b3f8c598dc08|qa/approved-bytes/C/2026-10-26-C-A-ch05-v1/book/chapters/ch05-sec05.tex|
|book/chapters/ch05.tex|44080ec2b523a5b8e46cdc0aa07e93bb602d93551fefca8409704b1262fc13f3|qa/approved-bytes/C/2026-10-26-C-A-ch05-v1/book/chapters/ch05.tex|

未闭环翻译问题：无；后续修改须核差分并更新SHA。
