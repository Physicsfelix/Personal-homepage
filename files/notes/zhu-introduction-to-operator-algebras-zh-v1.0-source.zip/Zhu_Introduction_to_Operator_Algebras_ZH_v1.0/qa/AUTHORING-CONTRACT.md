# 统一译排接口与内容约定

固定169页原件及SHA见 source/identity.json。可见扫描页是权威，OCR只定位。作者朱克和，原著Kehe Zhu，CRC1993。

## 文件及所有权

- A: `book/chapters/ch01.tex`–`ch07.tex` 包装入口及各 `chNN-secKK.tex`、`chNN-exercises.tex`，`book/matter/part1.tex`；C独审。
- B: ch08–ch15相同结构，`book/matter/part2.tex`；A独审。
- C: ch16–ch26相同结构，`book/matter/part3.tex`；B独审。
- root: main/preamble/style/front/back/index/helper。A独审root语义材料。
- 序言、原目录、索引及出版资料有独立单元；空白页在清单登记无可译内容。

每个实际编号小节单独TeX文件。章标题放包装入口 `\OriginalLecture{1}{泛函分析回顾}`，随后无条件input各节与习题；没有实质导语不要凭空创造导语。原 x.1 无标题的编号保留空题名。每节用 `\OriginalSection{1.1}{}` 或 `\OriginalSection{1.2}{Riesz 表示}`。同讲头和小节之间若有实际导语才另建intro文件。

原书三部分、26 lectures，统一显示“第n讲”，原书正文中chapter指相关讲时可译“第n讲”，前言两种编号体系照原意译。只有标题样式变化，原编号不改。

## 数学环境与引用

模板与统一宏在book/preamble.tex。以XeLaTeX/CTeX/Fandol编译，不调用私有字体。原编号手工保持：

```tex
\begin{originaltheorem}{1.1}\label{thm:1.1}
内容
\end{originaltheorem}
\begin{originalproof}...
\end{originalproof}
\begin{originaldefinition}{2.1}\label{def:2.1}...\end{originaldefinition}
\begin{originalexercise}{1.1}\label{exercise:1.1}...\end{originalexercise}
```

其他环境originalproposition(prop)、originallemma(lem)、originalcorollary(cor)、originalremark(rem)、originalexample(ex)、originalnotation(notation)。原书定理/命题/引理/推论/注共一组编号；定义/例另共一组；绝不能因同号删去一个。标签必须有类型前缀。引用 `\OrigRef{thm}{1.1}`、`\OrigRef{def}{2.1}`、`\OrigRef{sec}{1.2}`、`\OrigRef{ch}{7}`；书目键`bib:1`等，正文可用`\hyperref[bib:9]{[9]}`。公式有原号则保留原tag+eq标签，绝不添加冒充原号；无号公式逐式完整保留。

习题标题 `\originalexercisesheading{1}` 后每题originalexercise。所有子问、提示、原证明中间行、无号公式和证明后文字完整翻译，不加答案。原文同页多个单元需记录起止锚点。

## 来源与索引锚点

各节源码注释记录 `Source: physical13, printed2, first...last...`，跨原页保留页边界。每个原印刷正文页只在其首个可对应段落前插一次 `\SourcePage{2}`，后续同页小节不要重复。原页跨公式则标在对应公式合理位置，不为锚点拆坏公式。原分部页1/49/97亦有各自SourcePage。

root将据原索引提供逐条出处清单。`\IndexMark{stable-id}` 需插于对应真实词语/定义/定理/讨论处，`\IndexRef`用译页重建索引页码，原星号保留。没有精确核对前不猜锚点。先写清来源页与段落边界，随后补索引锚点由原审者核精确差分。

## 记号与术语

内积**第一槽线性、第二槽共轭线性**。原书称bounded bilinear form但定义为第一线性第二共轭线性；译“有界双线性形式”并明确其原定义，不静默改原内容。Banach代数默认有单位且单位范数1，非含幺章节另按作者说明。unital含幺；non-unital非含幺；unitization单位化；multiplicative linear functional乘法线性泛函；maximal ideal space极大理想空间；Gelfand变换；spectrum谱；resolvent set预解集；commutant交换子代数；double commutant双交换子；state态；pure state纯态；partial isometry偏等距算子；initial/final space初空间/终空间；range projection值域投影；central support中心支撑；projection投影；finite/infinite projection有限/无限投影；minimal projection极小投影；abelian projection阿贝尔投影；factor因子；SO强算子/WO弱算子。合理原始同义词不必大幅返修。

## 原书疑点与独审

不得静默修正原书疑似错误。原式保留，另用 `\SourceError{...}` 标“译校注”，该注须非作者独审。独审报告要实际看原图，逐段逐式含全部习题核对，记录未译/错译/条件/方向/记号等并闭环。每批准单元绑定实际当前TeX SHA、原范围、译者、审者、报告；审者独立存真正原字节副本到自己的 `qa/approved-bytes/<reviewer>/...`，不只写哈希或回头无说明补拷贝。各人只维护自己的review-ledger-A/B/C.json，不互相签署；修改后审精确差分/牵连处并更新SHA，保留旧报告/副本。

正式main必须无条件包含全书。预览文件可以临时编译已完成章节，但只能标工作样稿，不作为正式终稿或交付。PDF标记已成功执行一次，所有人不得重复。

## 已确认所有权调整

A确认ch06/ch07未起草后，于本轮正式交由root全译；A只译PartI标题和ch01–05，C仍非作者独审PartI全体。ch06–07合计14个原索引锚由root记录，A的60个其余锚保持不变。历史原始库存中的拟定译者字段不覆盖当前实际作者，实际映射与当前账本为准。

## 最终索引的独立审者

原索引136条转录及生成逻辑已有A独审。A在最终实际PDF索引验收阶段连续遇到模型容量故障，尚未签署最终索引TeX；为继续完成严谨验收，另安排全新非译者D（zhu_final_index）独审实际终版索引/目录/所有跳转并保存自己的真实字节副本及ledger-D。D不代签A，当前book/matter/index-entries.tex以D实际批准为准，其他A/B/C已有当前批准保留。
