# A：Part I 原页完整盘点

原件 SHA256：`e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c`。本清单仅是来源盘点，不是译文或审校批准。

已实际打开图像核读物理页 **12–59 全48页**：`qa/A-source-visual/pair-012-013.png` 至 `pair-058-059.png`（共24组）；另看物理60 Part II 章界。渲染1.65倍，原页尺寸374.4×584.28pt，以下y以原PDF顶端为0。物理12为隐含印刷1，物理13–59印刷2–48，映射本段恒为物理−11。

**36节 + 6组习题 + Part I标题 = 43个交付单元；40道习题；76个有编号陈述对象；无脚注、图、表、交换图；无公式编号。** 无独立于x.1的讲导语；1.1、6.1没有小标题，不补造。第7讲没有习题。所有习题均无字母分问，但每题全部要求已列在JSON。

## 单元与边界

| ID | 原标题 | 物理页 / 印刷页 | 起始y→末尾y | 首末锚点 |
|---|---|---|---|---|
| part1 | Part I — BANACH ALGEBRAS | [12, 12] / [1, 1] | 20→92 | Part I … BANACH ALGEBRAS |
| ch01-sec01 | （原书无小标题） | [13, 13] / [2, 2] | 191→311 | Let C be the space of all complex numbers … We mention [9][5] in particular. |
| ch01-sec02 | Riesz Representation | [13, 15] / [2, 4] | 352→194 | The phrase “Riesz representation” means one of at least three theorems … where μ is a finite regular complex Borel measure on Ω. |
| ch01-sec03 | Weak Topologies | [15, 16] / [4, 5] | 233→246 | Suppose X is a set and F is a family of functions … the image of (X*)₁ in P under the mapping ξ is closed in the product topology. |
| ch01-sec04 | Topological Vector Spaces | [16, 17] / [5, 6] | 292→250 | A space X is called a topological vector space … for every continuous linear functional F on X. |
| ch01-sec05 | Extreme Points | [17, 17] / [6, 6] | 290→450 | Suppose X is a locally convex topological vector space … a₁ + ··· + aₙ = 1. |
| ch01-sec06 | The Stone-Weierstrass Approximation Theorem | [17, 17] / [6, 6] | 488→556 | THEOREM 1.9 … then A = C(K). |
| ch01-sec07 | Zorn’s Lemma | [18, 18] / [7, 7] | 66→268 | Let X be a set. A partial ordering of X … then X has a maximal element. |
| ch01-exercises | Exercises | [18, 18] / [7, 7] | 313→364 | 1.1 Refresh your memory of real analysis and general topology. … and connectedness of topological spaces. |
| ch02-sec01 | Banach Algebras | [19, 19] / [8, 8] | 183→347 | In this lecture we introduce the notion of a Banach algebra … (b) ||xy|| ≤ ||x|| ||y|| for all x and y in A. |
| ch02-sec02 | Examples | [19, 21] / [8, 10] | 392→88 | The simplest Banach algebra is the complex field C … Q(H) is called the Calkin algebra on H. |
| ch02-sec03 | The Invertible Group | [21, 23] / [10, 12] | 136→197 | DEFINITION 2.7 For a Banach algebra A we let G(A) … finishing the proof of the proposition. |
| ch02-sec04 | The Abstract Index | [23, 24] / [12, 13] | 252→147 | THEOREM 2.4 Let A be a Banach algebra and let G₀(A) … then I(A) is isomorphic to I(B). |
| ch02-sec05 | Examples | [24, 25] / [13, 14] | 184→100 | The following are several examples of the abstract index. … with the integer group Z. We omit the details. |
| ch02-exercises | Exercises | [25, 25] / [14, 14] | 145→434 | 2.1 Verify the assertions made in Examples 2.9 and 2.12. … Show that A/I is a Banach algebra with the quotient norm. |
| ch03-sec01 | The Definition | [26, 26] / [15, 15] | 191→403 | In this lecture we introduce the notion of the spectrum … without which the spectrum of an element may not even exist. |
| ch03-sec02 | Examples | [26, 27] / [15, 16] | 452→534 | EXAMPLE 3.2 Let A = C(K) … then σ_B(Φ(x)) = σ_A(x) for all x in A. |
| ch03-sec03 | Basic Properties of the Spectrum | [28, 29] / [17, 18] | 62→323 | We first prove that the spectrum of an element in a Banach algebra is nonempty. … Being bounded and closed, σ(x) is compact. |
| ch03-sec04 | The Spectral Radius | [29, 30] / [18, 19] | 369→544 | DEFINITION 3.8 Suppose A is a Banach algebra … Then r(xy) = r(yx). |
| ch03-exercises | Exercises | [31, 31] / [20, 20] | 62→356 | 3.1 Let T be the operator defined on H = L²[0,1] … whenever y ∈ A satisfies ||y − x|| < δ. |
| ch04-sec01 | Multiplicative Linear Functionals | [32, 32] / [21, 21] | 187→539 | In this lecture we study multiplicative linear functionals … contradicting the earlier conclusion that φ(x₀) = 0. |
| ch04-sec02 | Examples | [33, 33] / [22, 22] | 66→277 | EXAMPLE 4.2 If A = C(K) … is much larger than the unit disk. See [3][4]. |
| ch04-sec03 | The Maximal Ideal Space | [33, 34] / [22, 23] | 318→458 | DEFINITION 4.5 For a Banach algebra A … completing the proof of the theorem. |
| ch04-sec04 | A Theorem of Gleason, Kahane, and Zelazko | [34, 37] / [23, 26] | 499→132 | Finally in this lecture we present a characterization … N is closed under multiplication, completing the proof of the theorem. |
| ch04-exercises | Exercises | [37, 37] / [26, 26] | 181→346 | 4.1 Show that Mₙ(C) has no nontrivial ideals. … always maps open sets in A to open sets in C. |
| ch05-sec01 | The Definition | [38, 38] / [27, 27] | 185→437 | Recall that the maximal ideal space M_A of a Banach algebra A … a very useful tool in the study of commutative Banach algebras. |
| ch05-sec02 | Commutative Banach Algebras | [38, 39] / [27, 28] | 475→359 | PROPOSITION 5.1 Suppose x is in a commutative Banach algebra … the desired results follow easily from Corollary 5.2. |
| ch05-sec03 | The Spectral Mapping Theorem | [39, 40] / [28, 29] | 409→556 | Suppose x is in a Banach algebra A and f(z) is an analytic function … The resulting theory is called the Riesz functional calculus. See [9]. |
| ch05-sec04 | The Spectral Radius Formula | [41, 42] / [30, 31] | 64→558 | Since the spectrum is defined in a purely algebraic way … it can be computed using the smallest Banach subalgebra containing x. |
| ch05-sec05 | When is the Gelfand Transform Isometric? | [43, 44] / [32, 33] | 64→119 | THEOREM 5.6 Suppose A is a commutative Banach algebra … if and only if the algebra is self-adjoint; see Lecture 8. |
| ch05-exercises | Exercises | [44, 44] / [33, 33] | 166→437 | 5.1 If xy = yx in a Banach algebra A … whenever x is an element in a Banach algebra. |
| ch06-sec01 | （原书无小标题） | [45, 45] / [34, 34] | 194→254 | In this lecture we compute the maximal ideal space for several Banach algebras. … The Gelfand transform will be determined accordingly. |
| ch06-sec02 | The Disc Algebra | [45, 46] / [34, 35] | 296→221 | Recall that D = {z ∈ C : |z| < 1} … then the Gelfand transform is simply the inclusion mapping. |
| ch06-sec03 | The Algebra of Continuous Functions | [46, 47] / [35, 36] | 263→317 | We can apply the techniques used in the proof of Theorem 6.1 … the Gelfand transform is then the identity mapping. |
| ch06-sec04 | The Algebra L¹(Z) | [47, 49] / [36, 38] | 358→428 | Recall that L¹(Z) is a commutative Banach algebra … Recall that the Gelfand transform is not isometric either. |
| ch06-sec05 | The Algebra of Bounded Continuous Functions | [49, 50] / [38, 39] | 467→557 | Let Ω be a locally compact (but noncompact) Hausdorff space … Γ(f), is simply the unique extension of f to M. |
| ch06-exercises | Exercises | [51, 51] / [40, 40] | 63→465 | 6.1 If f in C(∂D) has an absolutely convergent Fourier series … the maximal ideal space of B is homeomorphic to σ_B(x). |
| ch07-sec01 | The Unitization | [52, 52] / [41, 41] | 191→438 | For some applications it may be necessary to consider non-unital Banach algebras. … We shall call Ã the unitization of A. |
| ch07-sec02 | Two Examples | [52, 53] / [41, 42] | 484→461 | The following are two classical examples of non-unital commutative Banach algebras. … since dm is invariant under translation. |
| ch07-sec03 | The Maximal Ideal Space | [53, 54] / [42, 43] | 503→436 | Let A be a Banach algebra without identity. … the limit of a net of nonzero multiplicative linear functionals on A may converge to 0. |
| ch07-sec04 | The Gelfand Transform | [54, 55] / [43, 44] | 480→174 | Let M_A be the maximal ideal space of a non-unital Banach algebra A. … Γ(x) vanishes at ∞ and so Γ(x) ∈ C₀(M_A). |
| ch07-sec05 | The Algebra C₀(Ω) | [55, 56] / [44, 45] | 211→224 | We now identify the maximal ideal space of C₀(Ω) … the Gelfand transform is the identity mapping. |
| ch07-sec06 | The Algebra L¹(R,dx) | [56, 59] / [45, 48] | 270→284 | We proceed to identify the maximal ideal space of the non-unital Banach algebra … the Gelfand transform is the generalized Fourier transform. See [10]. |

## 原编号（并行计数）

Two parallel streams: Definition/Example together; Theorem/Proposition/Corollary/Lemma/Remark together. Lecture1hasTheorem1.1–1.10. Lecture7Remark7.9ispartofresultstream. Exercisesseparate. Literalnumbersmustbeexplicit.

- 第1讲：Theorem 1.1 (物理13), Theorem 1.2 (物理14), Theorem 1.3 (物理14), Theorem 1.4 (物理15), Theorem 1.5 (物理16), Theorem 1.6 (物理17), Theorem 1.7 (物理17), Theorem 1.8 (物理17), Theorem 1.9 (物理17), Theorem 1.10 (物理18)
- 第2讲：Definition 2.1 (物理19), Example 2.2 (物理19), Example 2.3 (物理20), Example 2.4 (物理20), Example 2.5 (物理20), Example 2.6 (物理20), Definition 2.7 (物理21), Definition 2.8 (物理24), Example 2.9 (物理24), Example 2.10 (物理24), Example 2.11 (物理24), Example 2.12 (物理24), Example 2.13 (物理25), Proposition 2.1 (物理21), Proposition 2.2 (物理22), Proposition 2.3 (物理22), Theorem 2.4 (物理23)
- 第3讲：Definition 3.1 (物理26), Example 3.2 (物理26), Example 3.3 (物理27), Example 3.4 (物理27), Example 3.5 (物理27), Example 3.6 (物理27), Example 3.7 (物理27), Definition 3.8 (物理29), Theorem 3.1 (物理28), Theorem 3.2 (物理29), Theorem 3.3 (物理29), Proposition 3.4 (物理30), Corollary 3.5 (物理30), Corollary 3.6 (物理30)
- 第4讲：Definition 4.1 (物理32), Example 4.2 (物理33), Example 4.3 (物理33), Example 4.4 (物理33), Definition 4.5 (物理33), Proposition 4.1 (物理32), Proposition 4.2 (物理33), Theorem 4.3 (物理34), Lemma 4.4 (物理35), Theorem 4.5 (物理35)
- 第5讲：Definition 5.1 (物理38), Example 5.2 (物理43), Example 5.3 (物理43), Example 5.4 (物理44), Proposition 5.1 (物理38), Corollary 5.2 (物理39), Theorem 5.3 (物理39), Theorem 5.4 (物理40), Theorem 5.5 (物理41), Theorem 5.6 (物理43)
- 第6讲：Theorem 6.1 (物理45), Theorem 6.2 (物理46), Theorem 6.3 (物理47), Theorem 6.4 (物理50)
- 第7讲：Example 7.1 (物理53), Example 7.2 (物理53), Proposition 7.1 (物理54), Theorem 7.2 (物理54), Theorem 7.3 (物理55), Theorem 7.4 (物理55), Lemma 7.5 (物理56), Lemma 7.6 (物理57), Theorem 7.7 (物理57), Corollary 7.8 (物理58), Remark 7.9 (物理59)

## 习题全部要求

- 1.1: Refresh real analysis/general topology, with five named topics.
- 2.1: Verify Examples2.9 and2.12; two referred assertions, no lettered subparts.
- 2.2: Verify Example2.10 in finite dimensions.
- 2.3: C¹[0,1] algebra with ||f||∞+||f′||∞; show Banach algebra.
- 2.4: Mₙ(C) norm-squared equals each of two determinant maxima; specify conjugate transpose.
- 2.5: Finite-dimensional equivalence of invertible/injective/surjective; show failure for dimH=∞.
- 2.6: B(X): define operator norm and composition; show Banach algebra.
- 2.7: Closed two-sided ideal quotient with quotient norm is Banach algebra.
- 3.1: Multiplication by x on L²[0,1]: spectrum and generalize result.
- 3.2: Every nonempty compactK⊂C is spectrum on separable infinite-dimensionalH.
- 3.3: Unilateral shift on ℓ²: find spectrum.
- 3.4: Adjoint spectrum is conjugate of original spectrum.
- 3.5: Invertiblex: spectrum of inverse.
- 3.6: r(xⁿ)=r(x)ⁿ, every positive integern.
- 3.7: Maximal abelianB: closed, unital, and spectral equality; three assertions without letters.
- 3.8: Matrix spectrum equals eigenvalue set.
- 3.9: Self-adjoint matrix norm equals spectral radius.
- 3.10: Matrix norm-squared equals r(A*A).
- 3.11: Upper semicontinuity of spectrum, openU and δ quantifiers.
- 4.1: Mₙ(C) has no nontrivial ideals.
- 4.2: Every commutative algebra contains proper maximal ideals.
- 4.3: H∞(D) has more characters than point evaluations.
- 4.4: Analytic-function Banach algebra onD: inclusion inH∞ and norm inequality.
- 4.5: Construct a character on L∞[0,1].
- 4.6: Do characters exist on B(H)?
- 4.7: Characters map open sets to open sets.
- 5.1: Commutingx,y: r(xy)≤r(x)r(y).
- 5.2: Exterior analytic Banach-valuedf: claimed seriesΣaₙz⁻ⁿ; missing infinity condition flagged.
- 5.3: Idempotent spectrum⊂{0,1}.
- 5.4: Define centralizerΛ(S) by displayedset; show Banach subalgebra.
- 5.5: Mutually commutingS: bicommutant commutative and spectral equality; two assertions.
- 5.6: Claim bicommutant is smallest generated Banach algebra; source issue flagged.
- 5.7: r(x)=infₙ||xⁿ||¹⁄ⁿ.
- 6.1: Wiener theorem: absolutely convergent Fourier series/nonvanishing implies same for inverse.
- 6.2: Maximal ideal space of C(∂D), using6.2 method.
- 6.3: C¹[0,1] norm; maximal idealspace[0,1]; transform neither isometric nor onto.
- 6.4: Abstract index group ofL¹(Z) isZ.
- 6.5: Ball algebraA(Bₙ) with boundary continuity; maximal idealspace closedball via evaluations.
- 6.6: Spectrum range; invertibility iff no zero; spectral-radius supremum; three displayed assertions.
- 6.7: Closed unital algebra generated bynonzerox iscommutative; maximal idealspacehomeomorphictoσ_B(x).
- 第7讲：原书无习题。

## 无编号公式逐页定位

Each visible standalonedisplayblockcountsone;alignedmultilinechainsandcasescountone;letteredformula-onlyitemsalsooneperitem;inlinemathnotcounted;crosspagechainfragmentscountoneoneachpage. Countsaresecondarycompletenesslocators,notsemanticreview.
当前显示对象合计：171（含跨页链式续行分片）。

- 物理12/印刷1: 0 — 无
- 物理13/印刷2: 1 — operator norm ofT
- 物理14/印刷3: 6 — adjoint identity; adjoint property(a); adjoint property(b); adjoint property(c); adjoint property(d); C(K) sup norm
- 物理15/印刷4: 3 — Riesz integral onK; Riesz integral onΩ; D_x closed disk
- 物理16/印刷5: 3 — P product ofD_x; ξ(F)(x)=F(x); seminorm basic neighborhood
- 物理17/印刷6: 1 — continuous-functional bound inTheorem1.6
- 物理18/印刷7: 3 — order axiom(a); order axiom(b); order axiom(c)
- 物理19/印刷8: 2 — Definition2.1(a) unit norm; Definition2.1(b) submultiplicativity
- 物理20/印刷9: 3 — L¹(Z) convolution; four-line Fubini norm chain; quotient norm
- 物理21/印刷10: 2 — Neumann seriesy; Cauchy estimate forpartial sums
- 物理22/印刷11: 7 — (1−x)y=1; y(1−x)=1; Neumann norm bound; G(A) open-ballset; ||xₙ−x|| bound; ||1−x⁻¹xₙ||<1/2; inverse Neumann series
- 物理23/印刷12: 3 — ||xₙ⁻¹x||≤2; boundfor||xₙ⁻¹||; inverse difference bound
- 物理24/印刷13: 0 — 无
- 物理25/印刷14: 4 — Exercise2.3 C¹set; Exercise2.3 norm; Exercise2.4 two determinant maxima; Exercise2.6 operator norm
- 物理26/印刷15: 0 — 无
- 物理27/印刷16: 1 — Example3.5 spectrum Fourier range
- 物理28/印刷17: 6 — entirefdefinition; first difference quotient limit; resolvent difference identity; resolvent derivative limit; f derivative limit; resolvent norm estimate chain
- 物理29/印刷18: 3 — λ1−x=λ(1−x/λ); r(x)definition; nilpotent2×2matrix
- 物理30/印刷19: 6 — Fourier function; r(f) Fourier supremum; candidate inverseof1−yx; leftinverse calculation chain; rightinverse identity; Corollary3.5 spectrum union
- 物理31/印刷20: 3 — Exercise3.1 multiplicationoperator; Exercise3.3 unilateral shift; Exercise3.5 inverse spectrum
- 物理32/印刷21: 2 — unit-neighborhood norm bound; φ(x₀)φ(x₀⁻¹)=1
- 物理33/印刷22: 0 — 无
- 物理34/印刷23: 2 — 1=(1−x/φ(x))+x/φ(x); difference ofφ₁andφ₂
- 物理35/印刷24: 7 — boundforg; g_r definition; boundforg_r; xdecomposition; kernelmembership; normbound; f power series
- 物理36/印刷25: 11 — φ(xⁿ)bound; fvaluesandgrowth; f=φ(exponentialseries); exponential element; inverse exponential element; x,y decomposition; φ(xy)decomposition; square preservation; symmetrized product; two kernel elements; square commutator identity
- 物理37/印刷26: 1 — φ(commutator)²=φ(commutator²)
- 物理38/印刷27: 1 — Gelfandtransformdefinition
- 物理39/印刷28: 5 — Γ(x)(φ₀)=0; Corollary5.2 spectrum equality; Corollary5.2 radius equality; scalarf power series; absolute normpower-series convergence
- 物理40/印刷29: 8 — f(x)power series; spectral mapping theorem conclusion; two A₀ spectral equalities; σ_A₀(f(x))character range; φ(f(x))=f(φ(x)); character rangeofx; σ_A₀(f(x))=f(σ_A₀(x)); finalσ(f(x))=f(σ(x))
- 物理41/印刷30: 8 — Banach-valued power series; Cauchy coefficients; Laurent expansion; Laurent coefficients (source missingi); spectral radius formula; σ(xⁿ)identity; r(x)ⁿ bound; liminf bound
- 物理42/印刷31: 8 — limsup goal; Ωexterior domain; resolvent function; Laurent resolvent expansion; Neumann resolvent expansion; continued resolvent expansion; series divergence condition; limsup conclusion
- 物理43/印刷32: 4 — square-norm equality chain; iterated2ⁿpowers; Example5.2 piecewisedefinition; Example5.3 conjugateidentity
- 物理44/印刷33: 3 — Exercise5.2 exterior series; Exercise5.4 centralizerset; Exercise5.7 spectralradiusinf
- 物理45/印刷34: 1 — φ_z evaluation
- 物理46/印刷35: 3 — polynomial φ evaluation; kernelset; finitecoverunion
- 物理47/印刷36: 4 — sumofabsolute-squaresf; φ(f)=0sum; L¹(Z)norm; L¹(Z)convolution
- 物理48/印刷37: 5 — φ_z series; Fubini multiplicativity chain; φ(fₙ)=z₀ⁿ; f expansioninbasis; φ(f) series
- 物理49/印刷38: 5 — netcontinuityserieslimit; Gelfandtransform Fourier series; Fouriercoefficients; Fourier expansionformal; continuousf example withnonsummablecoefficients
- 物理50/印刷39: 4 — pointevaluationΦ; basicweakstarneighborhoodU; sumofabsolute-squaresf; φ₀(f)=0
- 物理51/印刷40: 5 — Exercise6.3 C¹set; Exercise6.3 norm; Exercise6.6 spectrumrangefunction; Exercise6.6 invertibilitynonzero; Exercise6.6 radius
- 物理52/印刷41: 2 — unitization multiplication; unitization norm
- 物理53/印刷42: 3 — real-lineconvolution; groupconvolution; Fubini L¹normchain
- 物理54/印刷43: 2 — extensionφtilde; extensionnormbound
- 物理55/印刷44: 4 — Ω_εset; extensionφtilde forC(Ωtilde); fgexpansion; multiplicativity chain
- 物理56/印刷45: 4 — φtilde(f)=f(λ); pointevaluationΦ; Fouriercharacterφ_t; Fubini Fouriercharacterchain starts
- 物理57/印刷46: 4 — c integral; cf(x) integral chain (sourcedx typo); φ(f) viah; φ(f*g) Fubini chain
- 物理58/印刷47: 6 — φ(f*g) productformula; h multiplicativity relation; character-continuity integral limit; testfpiecewise; Cor7.8 φdefinition; Fubini differencechain starts
- 物理59/印刷48: 2 — Cor7.8 Fubini chain continuation; φ(f)=Fourier character

## 原书问题与OCR风险

- **A-S01** bounded bilinear form definition 物理14: linear in x, conjugate linear in y；处理：Preserve author term, identify sesquilinear definition in translator note; first slot linear.
- **A-S02** Theorem1.7 物理17: S is a convex set in S；处理：Preserve printedS and mark likelyX in SourceError; independent review required.
- **A-S03** Example2.11 物理24: abstract index group of Q(A)；处理：Prior context isQ(H); keepQ(A) with note.
- **A-S04** Example2.12 物理24: G(H∞(D)) coincideswithG₀; analytic logarithm used withoutboundedness；处理：Keep assertion; later independently verify counterexample using boundedinvertiblefwhose analytic logarithmsareunbounded, e.g. exp(i log((1+z)/(1−z))) with consistent branches.
- **A-S05** 3.1 lastparagraph 物理26: withoutwhichthespectrumofanelementmaynotevenexist；处理：Preserve wording; ifnoteaddedexplainnonemptinessisrelevant ratherthan set existence.
- **A-S06** Laurent coefficientformula 物理41: aₙ=(1/(2π))∫_C f(ζ)dζ/ζⁿ⁺¹；处理：Visible formula lacks i while preceding Taylor coefficient has2πi; preserveandSourceError.
- **A-S07** Exercise5.2 物理44: analyticfor|z|>r asserted tohaveΣaₙz⁻ⁿ；处理：Missing condition at∞; scalarf(z)=z suffices as counterexample. Preserve exercise;note independently review.
- **A-S08** Exercise5.6 物理44: Λ(Λ(S)) is smallestBanachalgebra containingS；处理：Bicommutant generally larger than closedgeneratedalgebra. Need independentlycheckedcounterexample; candidateS={1,z}inC(T): bicommutant=C(T), generatedalgebra closureofnonnegativepolynomials.
- **A-S09** Fourier coefficients paragraph 物理49: f(z)=Σaₙzⁿforarbitrarycontinuousf；处理：Preserve formula; distinguish Fourier-seriesnotationfrompointwiseconvergence iftranslatornoteused.
- **A-S10** Example7.2 generalG 物理53: locallycompact(butnotcompact)abeliangroup assertedtogivenonunitalL¹(G)；处理：Noncompactdoesnotimplynondiscrete; G=Z contradicts. PreserveandSourceError.
- **A-S11** Theorem7.3 opening 物理55: Suppose φ is a non-unital Banach algebra.；处理：PreserveφandnoteexpectedA.
- **A-S12** Theorem7.3 proof 物理55: for all x∈M_A−Ω_ε；处理：Variable shouldbeφ; preserveandnote.
- **A-S13** Lemma7.6 cf(x) integralchain 物理57: middle integral∫₀^δ f(x+y) dx；处理：Preservedx andnoteexpected dy.
- **A-OCR**  物理[12, 59]: OCRreorderslines,mangles≤as<,bars,tildeOmega,conjugation,ℓ²andL¹,integralsandpowers;manystray)))；处理：Allmathandboundariesreadfromvisiblepages;OCRonlylocator. No scan-unreadableitem remains atinventoryresolution; denseformulasmustberereadwhiletranslating.

这些疑点仅已登记。原文须保留，任何译校注中的数学判断仍由非译者独核。本文与JSON的目标路径按统一接口建立前拟定；实际authoring contract若采用不同目录，将在翻译时按接口执行，不改变源范围。
