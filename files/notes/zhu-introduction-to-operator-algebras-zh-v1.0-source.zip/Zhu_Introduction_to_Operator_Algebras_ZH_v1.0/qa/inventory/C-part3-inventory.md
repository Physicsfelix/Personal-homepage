# C：Part III 原件完整清单

原件SHA256：`e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c`。实际查看physical108–164全部57页（printed97–153）；19张三页联系图及57张逐页渲染保存在`qa/C-source-visual/`。分部页未印页码，97由前后序列确定。

本清单是来源盘点，不代表翻译或证明审校通过。坐标为PDF原生pt、左上角原点；页面374.4×584.28pt。每单元首尾原文片段和y锚点、各定理/定义/例/习题位置详见JSON。

共36个编号小节、11个习题块、46道习题、59个定理类对象、15个定义/例类对象。无脚注、无图表/交换图、无编号公式。17.1和23.1原文只有编号、无题名，是实质导语，不能另造标题。各讲标题下面没有另一个独立的无编号导语。

|单元|原题名|物理页|首y|末y|编号对象/习题|
|---|---|---:|---:|---:|---|
|part3|Part III / VON NEUMANN ALGEBRAS|108–108|32.3|65.4|分部标题|
|16.1|SO and WO Topologies|109–110|192.5|345|definition 16.1|
|16.2|SO and WO Continuous Functionals|110–112|386.5|194|theorem 16.1(a,b,c), theorem 16.2, theorem 16.3|
|16.3|Von Neumann Algebras|112–112|228.7|398|definition 16.2|
|16.ex|Exercises|112–113|448.6|148.2|16.1, 16.2, 16.3, 16.4, 16.5, 16.6, 16.7|
|17.1|（无题名；编号导语）|114–114|187.5|270.8|分部标题|
|17.2|Monotone Sequences of Operators|114–116|325.4|341|theorem 17.1, corollary 17.2, corollary 17.3(a,b), corollary 17.4|
|17.3|Range Projections|116–117|393|543.3|theorem 17.5, corollary 17.6|
|17.4|Existence of Unit|118–118|68.8|354.8|theorem 17.7|
|17.ex|Exercises|118–118|406.1|495|17.1, 17.2, 17.3|
|18.1|The Commutant|119–119|185.4|515.6|definition 18.1, proposition 18.1|
|18.2|Invariant Subspaces|120–120|69.2|399|lemma 18.2, corollary 18.3|
|18.3|Von Neumann’s Double Commutant Theorem|120–122|454.2|374|lemma 18.4, corollary 18.5, theorem 18.6, theorem 18.7, corollary 18.8|
|18.4|Polar Decomposition Again|122–123|423.7|275.8|theorem 18.9|
|18.ex|Exercises|123–123|328.4|461.2|18.1, 18.2, 18.3, 18.4|
|19.1|More on the Strong-Operator Topology|124–125|187|306.2|proposition 19.1, proposition 19.2|
|19.2|The Cayley Transform|125–126|368|433|theorem 19.3, corollary 19.4|
|19.3|The Kaplansky Density Theorem|126–128|507.8|342|theorem 19.5(a,b,c), corollary 19.6(a,b,c)|
|19.ex|Exercises|128–128|387.2|534|19.1, 19.2, 19.3, 19.4, 19.5|
|20.1|Spectral Measures|129–130|182|415|definition 20.1(a,b,c), proposition 20.1|
|20.2|The Spectral Theorem—Version II|130–133|461|216|theorem 20.2|
|20.3|The Borel Functional Calculus|133–133|275.1|548.8|theorem 20.3|
|20.ex|Exercises|134–134|62.5|293.3|20.1, 20.2, 20.3, 20.4(a,b,c,d)|
|21.1|Examples of Abelian von Neumann Algebras|135–137|183.7|131.8|example 21.1, example 21.2, proposition 21.1|
|21.2|Maximal Abelian Algebras|137–137|183.7|551.9|proposition 21.2, theorem 21.3|
|21.3|A Uniqueness Theorem for L-infinity|138–138|66.1|543.8|theorem 21.4|
|21.ex|Exercises|139–139|62.8|187.7|21.1, 21.2, 21.3, 21.4|
|22.1|Cyclic and Separating Vectors|140–142|185.5|126|definition 22.1, example 22.2, example 22.3, proposition 22.1, corollary 22.2, theorem 22.3, corollary 22.4|
|22.2|A Representation of Abelian von Neumann Algebras|142–144|180.9|185|theorem 22.5, theorem 22.6|
|22.ex|Exercises|144–144|244|343.4|22.1, 22.2, 22.3|
|23.1|（无题名；编号导语）|145–145|185.7|366.4|分部标题|
|23.2|The L-infinity-Functional Calculus|145–148|416.9|230.8|theorem 23.1, theorem 23.2|
|23.3|Connectedness of the Unitary Group|148–149|282.8|532.4|theorem 23.3, corollary 23.4, corollary 23.5|
|23.ex|Exercises|150–150|62.5|140.6|23.1, 23.2|
|24.1|The Projection Lattice|151–151|185.9|519.5|proposition 24.1, corollary 24.2|
|24.2|An Equivalence Relation|152–152|65.5|527.4|definition 24.1, proposition 24.3|
|24.3|Kaplansky’s Formula|153–153|64.6|406|lemma 24.4, theorem 24.5|
|24.4|The Center of a von Neumann Algebra|153–154|459.8|67.4|definition 24.2|
|24.5|The Central Support of a Projection|154–155|117.5|316|proposition 24.6, proposition 24.7(a,b,c)|
|24.ex|Exercises|155–155|362.5|461.1|24.1, 24.2, 24.3, 24.4|
|25.1|The Definition|156–156|184.7|301|definition 25.1|
|25.2|Checking the Axioms|156–158|346.6|309.5|lemma 25.1, lemma 25.2, theorem 25.3|
|25.3|The Comparability Theorem|158–159|370.1|309|theorem 25.4, corollary 25.5|
|25.ex|Exercises|159–159|357.4|444.5|25.1, 25.2, 25.3, 25.4|
|26.1|Various Types of Projections|160–161|187.5|163|definition 26.1(a,b,c,d), proposition 26.1|
|26.2|Centrally Orthogonal Projections|161–162|225.3|105|definition 26.2, lemma 26.2|
|26.3|Type Decomposition|162–163|162.2|547.3|definition 26.3(a,b,c), theorem 26.3, corollary 26.4|
|26.ex|Exercises|164–164|63.1|220.9|26.1, 26.2, 26.3, 26.4, 26.5, 26.6|

独立编号组：定理/命题/引理/推论/注共组；定义/例另组。特别是22.1定义之后原书为例22.2、22.3，同时另有命题22.1。原书未编号的说明与例子均留在所属小节，JSON说明了证明后段落和跨页边界。

## 原书疑点与待独审项

- C-source-01：physical141/printed130，Theorem22.3 proof：Visible display is H = union_{x in E_0}[Ax]. The argument uses mutually orthogonal cyclic subspaces and later calls H their direct sum; set union is generally not the whole H. Preserve visible union; independently verified SourceError note should distinguish closed orthogonal direct sum.
- C-source-02：physical153/printed142，Lemma24.4 proof：By Theorem18.4 the partial isometry V belongs to A. 18.4 is a lemma about one-vector approximation; polar decomposition is Theorem18.9. Preserve source reference text and add verified SourceError note.
- C-source-03：physical158/printed147，Theorem25.4 proof：By Theorem24.7 The numbered source object24.7 is a Proposition. Preserve original category and number with independently reviewed SourceError note.
- C-source-04：physical129/printed118，Spectral integral construction：bounded bilinear form The form is linear in first variable and conjugate-linear in second under the book convention, which the author calls bilinear. Retain author terminology and original definition; coordinate book-wide convention note.
- C-source-05：physical144/printed133，Exercise22.2：commutative C*-subalgebra containing the Bergman multiplication operator M_z An abelian C*-algebra has normal elements but Bergman M_z is not normal. This source premise deserves independent mathematical review; do not silently replace C*-subalgebra by algebra. Preserve complete exercise without solutions; reviewer to decide explanatory SourceError note.
- C-source-06：physical149/printed138，Theorem23.3 proof：Scalar finite positive Borel measure L-infinity representation invoked for an arbitrary von Neumann algebra; no separability hypothesis printed. Theorem23.2 assumes separable H; proof application requires scope audit. The unitary path-connectedness conclusion itself holds by Borel argument. Preserve author proof; reviewer to independently assess scope note, without replacing proof.

## 看图证据

每页均已在对应contact联系图实际打开查看。原分部页108及正文109–164均包含；无跳页。高密度矩阵、证明跨页和习题20.4(a)–(d)在联系图可见。所有单元的目标文件按AUTHORING-CONTRACT命名；译者C，独审者B，当前不作自签。
