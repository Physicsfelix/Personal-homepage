# C原书疑点：待B独立核验的数学证据

## 19.4中g(1)

源physical126/printed115可见原式g(z)=f(-i(z+1)/(z-1)), |z|=1。z=1原分母为零。沿单位圆z趋1时，逆Cayley参数为实数且绝对值趋无穷；因f属于C0(R)，g(z)趋0。因此取g(1)=0恰给连续延拓。正文原式保留，SourceError说明隐含延拓值。

## 19.5(c)与printed117的unitary断言

C实际查看源physical127和128：19.5(c)写The set of self-adjoint operators in B is the strong-operator closure of the set of self-adjoint operators in A；前提B为A在B(H)中的SOT闭包。printed117后段明称self-adjoint operators可换unitary operators，习题19.1也要求(b)(c)酉版。原文未注明闭包相对于酉群。

明确反例取A=B=B(l²(N))。令标准基e_k的U_n像为：k<n时e_(k+1)，k=n时e_1，k>n时e_k。这是标准基的置换，因此U_n酉。令S e_k=e_(k+1)。对有限支撑向量x，n大于其支撑后U_nx=Sx；对一般x，先取有限支撑y且||x-y||<epsilon，由||U_n||=||S||=1得||(U_n-S)x||<=2epsilon+||(U_n-S)y||，故U_n强收敛S。S的值域为e_1正交补，不满，故S非酉。这直接反驳在整个B(H)取SOT闭包的酉版(c)。

酉群内的相对闭包版本可由定理19.3及原强稠密近似局部处理验证，但本QA不以标准结论替代源语境。正文注仅说需酉群内相对闭包及强极限可能非满等距；完整反例不放习题后，以免增加习题解答。B应独立重看源(c)和上述构造后决定该注是否通过。

## 20.2证明少写(T)

C另实际放大查看qa/C-source-visual/page-131.png及page-132.png。printed120两处mu下标确为x,bar f(T)x；中文保持bar f，未跟随OCR丢失。printed121中间等式左边确印< (fg)x,x >，少(T)，后面下一display明确为(fg)(T)=f(T)g(T)。正文保留该原式，并在完整证明后SourceError说明类型和应读形式。此处不是添加证明。
