# PartII 全可见原页清单（B）

原件SHA256：`e48b38c484be8bce32b65ba8a40c520f9d1cebb027e6a88736e9a0c544ac224c`。实际看物理60–107全部48页及108分部边界。物理60无可见印刷标签（顺序推定49）；61–107可见印刷50–96。

40单元：29有号小节、3实际导语段、7习题块（45题）、1分部标题。无图、表、脚注、有号公式tag。原页为依据，OCR仅定位；y为近似PDF点，左上原点，页高584.28点。

## 编号组

- 第8讲：definition_example=Definition8.1,Example8.2–8.6,Definition8.7；theorem_family=Theorem8.1,Proposition8.2,Remark8.3
- 第9讲：definition=Definition9.1；theorem_family=Proposition9.1,Corollary9.2–9.3,Theorem9.4,Corollary9.5,Theorem9.6,Lemma9.7–9.8,Theorem9.9–9.10,Corollary9.11
- 第10讲：definition=Definition10.1；theorem_family=Proposition10.1,Theorem10.2–10.7
- 第11讲：theorem_family=Theorem11.1–11.2,Lemma11.3,Corollary11.4,Theorem11.5
- 第12讲：definition_example=Definition12.1,Example12.2–12.4；theorem_family=Lemma12.1–12.3,Corollary12.4,Theorem12.5,Proposition12.6,Corollary12.7,Theorem12.8,Corollary12.9
- 第13讲：definition=Definition13.1；theorem_family=Proposition13.1–13.4,Theorem13.5,Corollary13.6,Theorem13.7,Proposition13.8,Theorem13.9,Lemma13.10,Theorem13.11
- 第14讲：theorem_family=Proposition14.1–14.2,Theorem14.3–14.4
- 第15讲：theorem_family=Theorem15.1–15.2,Corollary15.3–15.4,Theorem15.5,Lemma15.6,Theorem15.7,Lemma15.8,Theorem15.9

## P2-title — Part II — C*-Algebras

类型part-title；物理页[60]；B译/A审。
起p60 y≈15：Part II
止p60 y≈84：C*-ALGEBRAS

备注：No part introduction; visible printed label absent, 49 only inferred.

## L08-s8.1 — The Definition

类型subsection；物理页[61, 62]；B译/A审。
起p61 y≈179：8.1 The Definition
止p62 y≈121：and r(x*)=r(x).

对象：Definition8.1(a)–(d)

公式边界：

- p61: ||x||²=||x*x||≤||x*||||x||
- p61: ||x||²≤||x*x||≤||x*||||x||
- p61: 1*x=(x*1)*=x, x1*=(1x*)*=x
- p62: σ(x*)=overline σ(x)={conj λ:λ∈σ(x)}, r(x*)=r(x)

备注：Includes post-definition involution/adjoint terms, strongest condition(d), both isometry arguments, unit identity 1*=1.

## L08-s8.2 — Examples

类型subsection；物理页[62]；B译/A审。
起p62 y≈161：8.2 Examples
止p62 y≈536：C*-subalgebra of some M_n(C). (See [11].)

对象：Example8.2 C；Example8.3 C(K)；Example8.4 L∞；Example8.5 B(H),M_n(C)；Example8.6 closed unital self-adjoint subalgebra

公式边界：

- p62: all five defining algebra/involution formulas within example paragraphs

备注：Includes finite K consequence C(K)=C^n, conjugate transpose, representation claims and [11].

## L08-s8.3 — Special Elements in a C*-Algebra

类型subsection；物理页[63, 64, 65]；B译/A审。
起p63 y≈64：8.3 Special Elements in a C*-Algebra
止p65 y≈204：This clearly implies b=0, and so c=a∈R.

对象：Definition8.7(a)–(e)；Theorem8.1+proof；Proposition8.2(a)(b)+proof；Remark8.3+alternate proof

公式边界：

- p63: ||x²||=||x*x||=||x||²
- p63: ||x^(2^n)||=||x||^(2^n), n≥1
- p63: spectral radius limit along 2^n
- p63: ||x||²=||x*x||=r(x*x)≤r(x*)r(x)
- p64: ||x||²=||x*x||=r(x*x)=sup{|λ|:λ∈σ(x*x)}
- p64: σ(x)⊂{|λ|≤1}
- p64: σ(x^-1)={λ^-1:λ∈σ(x)}⊂{|λ|≥1}
- p64: σ(x)⊂{|λ|≥1}
- p64: x_n=x−a1+inb1
- p65: i(n+1)b∈σ(x_n)
- p65: (n²+2n+1)b²=...≤||x−a1||²+n²b², three aligned lines
- p65: (2n+1)b²≤||x−a1||², n=1,2,...

备注：Includes normal nilpotents, unique norm for fixed involution, unitary equivalence/invariants, remark continuation. Definition/example and theorem/proposition/remark use separate counters.

## L08-ex — Exercises

类型exercises；物理页[65]；B译/A审。
起p65 y≈255：Exercises
止p65 y≈475：the orthogonal compliment of its kernel.

逐题及并列要求：

- 8.1 self-adjoint x→exp(ix) unitary（无字母子问）
- 8.2 x=x1+ix2；子问/要求：unique real/imaginary decomposition；normal iff parts commute
- 8.3 number of compatible involutions（无字母子问）
- 8.4 nontrivial projection spectrum（无字母子问）
- 8.5 skew-adjoint imaginary spectrum（无字母子问）
- 8.6 x=0 iff xx*=0 iff x*x=0（无字母子问）
- 8.7 positive x→yxy* positive（无字母子问）
- 8.8 unitary diagonalization iff normal matrix（无字母子问）
- 8.9 B(H)；子问/要求：normal iff ||Tx||=||T*x|| all x；unitary iff onto isometry；projection iff identity on orthogonal complement of kernel

## L09-s9.1 — C*-Homomorphisms

类型subsection；物理页[66, 67]；B译/A审。
起p66 y≈188：9.1 C*-Homomorphisms
止p67 y≈191：from A into B.

对象：Definition9.1(a)–(d)；Proposition9.1+proof；Corollary9.2；Corollary9.3+proof

公式边界：

- p66: ||x||²=||x*x||=r(x*x)≥r(Φ(x*x))=r(Φ(x)*Φ(x))=||Φ(x)*Φ(x)||=||Φ(x)||², three aligned lines

备注：Includes condition(d) unital, one-to-one C*-isomorphism wording, post-corollary onto/into comment.

## L09-s9.2 — Representation of Commutative C*-Algebras

类型subsection；物理页[67, 68]；B译/A审。
起p67 y≈234：9.2 Representation of Commutative C*-Algebras
止p68 y≈207：projection iff σ(x)⊂{0,1}.

对象：Theorem9.4+proof；Corollary9.5(a)–(d)

公式边界：

- p67: x1=(x+x*)/2, x2=(x−x*)/(2i)
- p67: Γ(x*)=Γ(x1)−iΓ(x2)=overline(Γ(x1)+iΓ(x2))=overline Γ(x)
- p67: ||Γ(x)||∞²=||Γ(x*x)||∞=r(x*x)=||x*x||=||x||²

备注：Proof completes p68 with Stone-Weierstrass; all four corollary parts.

## L09-s9.3 — An Example

类型subsection；物理页[68]；B译/A审。
起p68 y≈239：9.3 An Example
止p68 y≈556：the closure of U is open.

对象：Theorem9.6+proof

公式边界：

- p68: F={f∈C(K):0≤f≤1,f=0 on K−U}

备注：Includes definition extremely disconnected, least upper bound, Urysohn arguments on closure and complement.

## L09-s9.4 — Subalgebras and the Spectrum

类型subsection；物理页[69, 70]；B译/A审。
起p69 y≈64：9.4 Subalgebras and the Spectrum
止p70 y≈281：σ_A(x)=σ_B(x).

对象：Lemma9.7+proof；Lemma9.8+proof；Theorem9.9+proof；Theorem9.10+proof；Corollary9.11

公式边界：

- p69: ||1−x_n^-1 x||=||x_n^-1(x_n−x)||≤C||x_n−x||
- p69: ||(λ_n1−x)^-1||→∞
- p69: (λ_n1−x)^-1→(λ_01−x)^-1
- p69: ||(λ_n1−x)^-1||→∞ (repeated contradiction)

备注：Intro Banach version; theorem9.9 proof crosses p69→70; theorem9.10 unital.

## L09-ex — Exercises

类型exercises；物理页[70]；B译/A审。
起p70 y≈321：Exercises
止p70 y≈552：then Φ is a C*-homomorphism.

公式边界：

- p70 ex9.5: I={f∈C(K):f=0 on F}

逐题及并列要求：

- 9.1 commutativity iff isometric involution-preserving Gelfand transform（无字母子问）
- 9.2 strict subalgebra spectral containment example（无字母子问）
- 9.3 nontrivial projections iff disconnected maximal ideal space（无字母子问）
- 9.4 unit disc quotient；子问/要求：quotient C(Dbar)/C0(D) is C*；identify maximal ideal space
- 9.5 C(K) ideals；子问/要求：all closed ideals vanish on closed F；when ideal maximal
- 9.6 algebraic homomorphism automatic boundedness question（无字母子问）
- 9.7 contractive algebraic homomorphism from C* preserves *（无字母子问）

## L10-s10.1 — The Spectral Theorem

类型subsection；物理页[71, 72]；B译/A审。
起p71 y≈186：10.1 The Spectral Theorem
止p72 y≈321：for every polynomial p of two variables.

对象：Proposition10.1+proof；Theorem10.2 The Spectral Theorem+proof

公式边界：

- p71: Γ:A[x]→C(M)
- p71: Φ:M→σ(x)
- p71: Φ(φ)=Γ(x)(φ)=φ(x)
- p72: φ_k(x*)=Γ(x*)(φ_k)=overline Γ(x)(φ_k)=overline φ_k(x),k=1,2
- p72: φ1(p(x,x*))=φ2(p(x,x*))
- p72: Γ:A[x]→C(σ(x))
- p72: Γ(p(x,x*))(z)=p(z,bar z)

备注：Initial paragraph defines A[S], A[x1,...,xn], A[x]; no unsectioned lecture introduction.

## L10-s10.2 — An Example

类型subsection；物理页[72, 73]；B译/A审。
起p72 y≈372：10.2 An Example
止p73 y≈131：see [1].

公式边界：

- p72: sup{|p(f,bar f)(z)|:z∈D}=sup{|p(z,bar z)|:z∈K}
- p72: M_p(f,bar f)↔p(z,bar z)

备注：Unnumbered example L²(D,dA), normalized area, M_f, K=f(Dbar), extension to measurable f/arbitrary L², citation [1].

## L10-s10.3 — The Continuous Functional Calculus

类型subsection；物理页[73]；B译/A审。
起p73 y≈172：10.3 The Continuous Functional Calculus
止p73 y≈552：from the definition of the continuous functional calculus.

对象：Definition10.1；Theorem10.3(a)–(d)+proof

公式边界：

- p73: Γ:A[x]→C(σ(x))
- p73(d): Φ(f(x))=f(Φ(x))

备注：Definition f(x)=Γ^-1(f); retain polynomial two-variable part and spectral mapping.

## L10-s10.4 — Some Applications

类型subsection；物理页[74, 75]；B译/A审。
起p74 y≈68：10.4 Some Applications
止p75 y≈555：as will be shown in the next lecture.

对象：Theorem10.4(a)–(c)+proof；Theorem10.5+proof；Theorem10.6+proof；Theorem10.7+proof

公式边界：

- p74: σ(x)=σ(ytilde²)=σ(ytilde)²={t²:t∈σ(ytilde)}
- p74: lim q_n(t)=lim p_n(t²)=f(t²)=t
- p74: ytilde=lim q_n(ytilde)=lim p_n(ytilde²)=lim p_n(x)=f(x)=y
- p75: f(t)=t+i√(1−t²)
- p75: f(t)overline f(t)=1,t=(f(t)+overline f(t))/2
- p75: f(x)≠0,Φ(f(x))=f(Φ(x))=0
- p75: ||x||²=||x*x||=||Φ(x*x)||=||Φ(x)*Φ(x)||=||Φ(x)||²

备注：Includes positive square-root notation, |x|=√(x*x), closed-image post-proof prose. Th10.5 invokes positive spectrum before lecture11 proof; preserve source order.

## L10-ex — Exercises

类型exercises；物理页[76]；B译/A审。
起p76 y≈62：Exercises
止p76 y≈276：continuous function from the spectrum of S into C.

逐题及并列要求：

- 10.1 normal idempotent projection（无字母子问）
- 10.2 unitary proper-circle spectrum exponential self-adjoint（无字母子问）
- 10.3 invertible x admits ε1≤x*x≤ε^-1 1（无字母子问）
- 10.4 normal nonnegative spectrum implies positive（无字母子问）
- 10.5 self-adjoint inequalities；子问/要求：|x|±x≥0；||x||1±x≥0
- 10.6 operator monotonicity；子问/要求：√x≤√y when 0≤x≤y；x invertible implies y invertible,y^-1≤x^-1
- 10.7 skew-adjoint；子问/要求：imaginary spectrum normal implies x*=−x；inverse also true
- 10.8 x,x*,1 dependent iff normal spectrum on a straight line（无字母子问）
- 10.9 normal Hilbert operator T=f(S), S self-adjoint（无字母子问）

## L11-intro — Lecture11 actual introductory paragraph

类型actual-introduction；物理页[77]；B译/A审。
起p77 y≈209：In this lecture we give several more applications
止p77 y≈230：normal elements in a C*-algebra.

备注：Printed after §11.1 heading; retain location, separate review unit.

## L11-s11.1 — The Image of a C*-Homomorphism

类型subsection；物理页[77, 78]；B译/A审。
起p77 y≈187：11.1 The Image of a C*-Homomorphism
止p78 y≈297：completing the proof of the theorem.

对象：Theorem11.1+proof

公式边界：

- p77: ||Φ(x_n+1)−Φ(x_n)||<1/2^n,n≥1
- p77: f_n three-case clipped identity at ±1/2^n
- p77: Φ(x_n+1)−Φ(x_n)=f_n(Φ(x_n+1)−Φ(x_n))=f_n(Φ(x_n+1−x_n))=Φ(f_n(x_n+1−x_n))
- p78: ||f_n(x_n+1−x_n)||=sup{|f_n(t)|:t∈σ(x_n+1−x_n)}≤1/2^n
- p78: x=x1+Σ f_n(x_n+1−x_n)
- p78: Φ(x)=Φ(x1)+ΣΦ(f_n(...))=Φ(x1)+Σ f_n(Φ(...))=Φ(x1)+Σ(Φ(x_n+1)−Φ(x_n))=lim Φ(x_n)

备注：Excludes separately inventoried introductory paragraph only.

## L11-s11.2 — Positive and Negative Parts of an Element

类型subsection；物理页[78, 79]；B译/A审。
起p78 y≈344：11.2 Positive and Negative Parts of an Element
止p79 y≈477：x1=f+(x)=x+ and x2=x−.

对象：Theorem11.2(a)–(d)+proof

公式边界：

- p78: f+(t)={t if t≥0,0 if t≤0}, f−(t)={0 if t≥0,−t if t≤0}
- p78: f(t)=f+(t)−f−(t)
- p79: f(x)=f+(x)−f−(x) or x=x+−x−
- p79: x+=f+(x)=(√f+(x))²≥0,x− analogous
- p79: σ(x+)={f+(t):t∈σ(x)}⊂R+,σ(x−) similarly
- p79: x+x−=f+(x)f−(x)=(f+f−)(x)=0
- p79: ||x||=sup|f(t)|=sup max(f+(t),f−(t))=max(||x+||,||x−||)
- p79: x^n=x1^n+(−x2)^n
- p79: p(x)=p(x1)+p(−x2)
- p79: f+(x)=lim p_n(x)=lim[p_n(x1)+p_n(−x2)]=f+(x1)+f+(−x2)

备注：Full uniqueness argument with polynomials lacking constant term, uniform approximation on union of three spectra.

## L11-s11.3 — Positivity in Terms of the Spectrum

类型subsection；物理页[79, 80, 81]；B译/A审。
起p79 y≈503：11.3 Positivity in Terms of the Spectrum
止p81 y≈204：x=x+ and σ(x)=σ(x+)⊂R+.

对象：Lemma11.3+proof；Corollary11.4+proof；Theorem11.5+proof

公式边界：

- p80: ||x−a1||=r(x−a1)=sup{a−λ:λ∈σ(x)}
- p80: ||x−||x||1||≤||x||,||y−||y||1||≤||y||
- p80: ||(x+y)−(||x||+||y||)1||≤||x||+||y||
- p80: ||x+y||≤||x||+||y||
- p80: v*v=x−xx−=x−(x+−x−)x−=−(x−)^3
- p80: v*v+vv*=2(v1²+v2²)
- p81: v*v=2(v1²+v2²)−vv*
- p81: ||v*v||=r(v*v)=0

备注：Intro p79 bottom, final proof p80→81; use Corollary3.5 for exchanging vv*/v*v.

## L11-ex — Exercises

类型exercises；物理页[81]；B译/A审。
起p81 y≈232：Exercises
止p81 y≈369：x1+x2≥0 and ax1≥0.

公式边界：

- p81 ex11.3: ||Φ(x)||=inf{||x−y||_A:Φ(y)=0}

逐题及并列要求：

- 11.1 normal element four commuting positive elements（无字母子问）
- 11.2 |x|=x++x− for self-adjoint（无字母子问）
- 11.3 norm of image quotient formula（无字母子问）
- 11.4 positive cone；子问/要求：addition；nonnegative scalar multiples

## L12-intro — Lecture12 actual introductory paragraph

类型actual-introduction；物理页[82]；B译/A审。
起p82 y≈211：In this lecture we concentrate on the special C*-algebra B(H)
止p82 y≈270：cannot be carried out in an arbitrary C*-algebra.

备注：After §12.1 heading; I unit, main results and arbitrary-C* caveat.

## L12-s12.1 — Operators on Hilbert Spaces

类型subsection；物理页[82, 83]；B译/A审。
起p82 y≈189：12.1 Operators on Hilbert Spaces
止p83 y≈553：σ(T)⊂R+, and hence T is positive.

对象：Lemma12.1+proof remark；Lemma12.2+proof remark；Lemma12.3+proof；Corollary12.4；Theorem12.5+proof

公式边界：

- p82: ker T=(Ran T*)⊥,closure Ran T=(ker T*)⊥
- p83: ||Tx||≥||T^-1||^-1||x||
- p83: ||x_n−x_m||≤1/ε||Tx_n−Tx_m||
- p83: y=lim Tx_n=Tx
- p83: <Tx,x>=||Sx||²≥0
- p83: ||(T−λI)x||²=||Tx||²−2λ<Tx,x>+λ²||x||²≥λ²||x||²

备注：Lemmas12.1 and12.2 proofs explicitly left to reader. Bounded-below definition after lemma12.3. Intro separate.

## L12-s12.2 — Partial Isometries

类型subsection；物理页[84, 85]；B译/A审。
起p84 y≈66：12.2 Partial Isometries
止p85 y≈467：T* is a partial isometry.

对象：Definition12.1；Example12.2 forward shift；Example12.3 backward shift；Example12.4 between same-dimensional closed subspaces；Proposition12.6+proof；Corollary12.7+proof

公式边界：

- p84: T(Σ a_n e_n)=Σ a_n e_n+1,{a_n}∈l²
- p84: T(Σ a_n e_n)=Σ a_n+1 e_n,{a_n}∈l²
- p84: Tx=0,x⊥X1,T(Σa_αe_α)=Σa_ασ_α,Σ|a_α|²<∞
- p85: <(I−T*T)x,x>=||x||²−||Tx||²≥0
- p85: ||√(I−T*T)x||²=<(I−T*T)x,x>=0
- p85: ||(I−T*T)x||≤||√(I−T*T)|| ||√(I−T*T)x||
- p85: ||Tx||²=<T*Tx,x>={||x||² if x∈X,0 if x⊥X}
- p85: (TT*)²=T(T*T)T*=TT*

备注：Example12.4 continues p84→85. Include initial/final spaces and finite/infinite dimension caveat.

## L12-s12.3 — Polar Decomposition

类型subsection；物理页[85, 86, 87]；B译/A审。
起p85 y≈518：12.3 Polar Decomposition
止p87 y≈102：the uniqueness follows from Theorem12.8 again.

对象：Theorem12.8+proof；Corollary12.9+proof

公式边界：

- p86: ||Px||²=<P²x,x>=<T*Tx,x>=||Tx||²
- p86: ker V=(Ran P)⊥=ker P
- p86: (ker W)⊥=(ker Q)⊥=closure Ran Q
- p86: P²=T*T=QW*WQ=Q²
- p86: (Ran P)⊥=ker P=ker W=ker V
- p86: closure Ran W=closure Ran Q=[ker Q]⊥
- p87: ker V=ker W*=[Ran W]⊥=[ker Q]⊥⊥=ker P

备注：Intro complex polar form z=rζ continues p85→86; theorem T=VP, corollary T=QW and closure ranges uniqueness.

## L12-ex — Exercises

类型exercises；物理页[87]；B译/A审。
起p87 y≈155：Exercises
止p87 y≈296：isometry and only if ker T*={0}.

逐题及并列要求：

- 12.1 invertible polar decomposition；子问/要求：unique positive times unitary x=x1x2；GL(M_n(C)) path connected
- 12.2 C* example no positive-times-partial-isometry decomposition（无字母子问）
- 12.3 prove lemmas12.1,12.2（无字母子问）
- 12.4 when sum of partial isometries is partial isometry（无字母子问）
- 12.5 isometries；子问/要求：isometry iff T*T=I；isometric T unitary iff T* isometry iff ker T*={0}

## L13-s13.1 — Definitions and Basic Properties

类型subsection；物理页[88, 89, 90]；B译/A审。
起p88 y≈188：13.1 Definitions and Basic Properties
止p90 y≈76：consequence of the Cauchy-Schwarz inequality.

对象：Definition13.1(a)Hermitian(b)positive(c)state；Proposition13.1+proof；Proposition13.2+proof；Proposition13.3+proof；Proposition13.4+proof

公式边界：

- p88: φ(x*)=φ(x1)−iφ(x2)=overline φ(x)
- p89: φ(|x|+x)≥0,φ(|x|−x)≥0
- p89: φ(x)=1/2[φ(|x|+x)−φ(|x|−x)]
- p89: ||φ||=sup{φ(x):x*=x,||x||≤1}
- p89: M=sup{φ(x):x*=x,||x||≤1}
- p89: ||φ||−ε<φ(x)=overline φ(x)=φ(x*)
- p89: x1=(x+x*)/2,x2=(x−x*)/(2i)
- p89: ||x1||=||(x+x*)/2||≤||x||=1
- p89: |φ(x*y)|²≤φ(x*x)φ(y*y)
- p89: <x,y>=φ(y*x)

备注：Proposition13.4 proof crosses p89→90. False/general-source issue Hermitian automatic boundedness and Exercise13.7; Prop13.3 finite-norm proof dependency flagged.

## L13-s13.2 — A Characterization of Positivity

类型subsection；物理页[90, 91]；B译/A审。
起p90 y≈124：13.2 A Characterization of Positivity
止p91 y≈249：||φ||=φ(1)=1.

对象：Theorem13.5+proof；Corollary13.6

公式边界：

- p90: φ(1)≤||φ||||1||=||φ||
- p90: σ(1−εx)={1−ελ:λ∈σ(x)}
- p90: ||1−εx||=r(1−εx)≤1
- p90: 1−εa≤|1−ε(a+ib)|=|φ(1−εx)|≤1
- p90: x_n=x−a1+inb1,n≥1
- p90: φ(x_n)=(n+1)ib
- p90: (n+1)²b²=|φ(x_n)|²≤||x_n||²
- p91: ||x_n||²=||x_n*x_n||=||(x−a1)²+n²b²1||≤||x−a1||²+n²b²
- p91: (n+1)²b²≤||x−a1||²+n²b²
- p91: (2n+1)b²≤||x−a1||²

备注：Proof crosses p90→91; forward positivity boundedness proof meaningful independently of earlier false Hermitian assertion.

## L13-s13.3 — The State Space

类型subsection；物理页[91, 92, 93]；B译/A审。
起p91 y≈266：13.3 The State Space
止p93 y≈87：||x||=|φ(x)|.

对象：Theorem13.7+proof；Proposition13.8+proof；Theorem13.9(a)–(d)+proof

公式边界：

- p91: M={ax+b1:a,b∈C}
- p91: φ0(ax+b1)=aλ+b
- p91: sup{|φ0(ax+b1)|:||ax+b1||≤1}=1
- p92: |aλ+b|≤r(ax+b1)≤||ax+b1||
- p92: S(A)={φ∈A*_1:φ(x)≥0,x≥0,φ(1)=1}

备注：Includes state-space weak-star topology introduction, proof13.7 crosses p91→92, proof13.9(d) p92→93, distinguish dual closed unit ball from dual.

## L13-s13.4 — Pure States

类型subsection；物理页[93, 94]；B译/A审。
起p93 y≈137：13.4 Pure States
止p94 y≈123：||x||=|φ1(x)| with φ1∈P(A).

对象：Lemma13.10+proof；Theorem13.11(a)–(d)+proof

公式边界：

- p94: ||x||=Re Φ(φ0)≤Re Φ(φ1)≤|φ1(x)|≤||x||

备注：Intro Krein-Milman, extreme points P(A), finite convex combinations with t_k∈(0,1),Σt_k=1; full final proof crosses p93→94.

## L13-ex — Exercises

类型exercises；物理页[94]；B译/A审。
起p94 y≈176：Exercises
止p94 y≈360：Show that every Hermitian linear functional on a C*-algebra is bounded.

公式边界：

- p94 ex13.5: σ(x)={φ(x):φ∈P(A)}

逐题及并列要求：

- 13.1 vector state T↦<Tx,x>（无字母子问）
- 13.2 unitary conjugation state（无字母子问）
- 13.3 multiplicative functional pure state（无字母子问）
- 13.4 commutative pure states exactly multiplicative（无字母子问）
- 13.5 normal spectrum values on pure states（无字母子问）
- 13.6 φ(x²)=φ(x)² implies φ(xy)=φ(x)φ(y) for self-adjoint x（无字母子问）
- 13.7 asserted Hermitian automatic boundedness（无字母子问）

备注：Exercise13.7 mathematical source issue, preserve and annotate after independent verification.

## L14-intro — Lecture14 actual introductory paragraph

类型actual-introduction；物理页[95]；B译/A审。
起p95 y≈210：In this lecture we show that every C*-algebra is C*-isomorphic
止p95 y≈254：GNS (standing for Gelfand, Neumark, and Segal) construction.

备注：After §14.1 heading; constructive intent and names.

## L14-s14.1 — The Construction

类型subsection；物理页[95, 96, 97]；B译/A审。
起p95 y≈187：14.1 The Construction
止p97 y≈342：This shows that Φ(x*)=Φ(x)*.

对象：Proposition14.1+proof；Proposition14.2+proof；Theorem14.3+proof

公式边界：

- p95: L_φ={x∈A:φ(x*x)=0}
- p95: |φ(x*y)|²≤φ(x*x)φ(y*y)
- p95: φ((ax+by)*(ax+by))=|a|²φ(x*x)+2Re(bar a b φ(x*y))+|b|²φ(y*y)
- p95: φ((yx)*(yx))=φ(x*y*yx)=0
- p96: H_φ^0=A/L_φ
- p96: <[x],[y]>=φ(y*x)
- p96: T_x([y])=[xy]
- p96: ||T_x([y])||≤||x||||[y]||
- p96: ||x||²||[y]||²−||T_x([y])||²=||x||²φ(y*y)−φ((xy)*(xy))=φ(y*(||x||²1−x*x)y)
- p96: ||x||²1−x*x=xtilde*xtilde
- p96: y*(||x||²1−x*x)y=(xtilde y)*(xtilde y)≥0
- p96: ||x||²||[y]||²−||T_x([y])||²=φ(y*(||x||²1−x*x)y)≥0
- p97: T_ax1+bx2([y])=[ax1y+bx2y]=a[x1y]+b[x2y]=aT_x1([y])+bT_x2([y])
- p97: Φ(ax1+bx2)=aΦ(x1)+bΦ(x2)
- p97: T_x1x2([y])=[x1x2y]=T_x1([x2y])=T_x1T_x2([y])
- p97: Φ(x1x2)=Φ(x1)Φ(x2)
- p97: five-stage inner-product identity distinguishing T_{x*} and (T_x)*

备注：Inner product FIRST slot linear. Quotient completion and well-definedness proof; separate intro.

## L14-s14.2 — Review on Direct Sum of Hilbert Spaces

类型subsection；物理页[97, 98]；B译/A审。
起p97 y≈388：14.2 Review on Direct Sum of Hilbert Spaces
止p98 y≈270：(⊕T_α)(⊕S_α)=⊕T_αS_α.

公式边界：

- p97: ||x||²=Σ_α||x_α||²<∞
- p97: <x,y>=Σ_α<x_α,y_α>
- p97: ⊕T_α:⊕H_α→⊕H_α
- p98: ⊕T_α({x_α})={T_αx_α}
- p98: ||⊕T_α||=sup{||T_α||:α∈A}
- p98: ⊕(aT_α+bS_α)=a⊕T_α+b⊕S_α
- p98: (⊕T_α)*=⊕T_α*
- p98: (⊕T_α)(⊕S_α)=⊕T_αS_α

备注：Source missing uniform boundedness assumption, flag independent source-error note.

## L14-s14.3 — A Representation of C*-Algebras

类型subsection；物理页[98, 99]；B译/A审。
起p98 y≈321：14.3 A Representation of C*-Algebras
止p99 y≈315：may no longer be an isomorphism.

对象：Theorem14.4+proof

公式边界：

- p98: H=⊕_{φ∈S(A)}H_φ
- p98: Φ:A→B(H)
- p98: Φ(x)=⊕_{φ∈S(A)}T_x^(φ)
- p99: T_x^(φ)([y])=[xy]
- p99: φ((xy)*(xy))=0, all y and states

备注：Includes post-proof states/pure-states/intermediate subset discussion, strict pure-state subset may fail.

## L14-ex — Exercises

类型exercises；物理页[99]；B译/A审。
起p99 y≈359：Exercises
止p99 y≈550：is a C*-isomorphism.

公式边界：

- p99 ex14.4: Φ:A→B(⊕_{φ∈S′}H_φ)

逐题及并列要求：

- 14.1 verify §14.2 direct-sum properties（无字母子问）
- 14.2 another proof of Th11.5 via representations（无字母子问）
- 14.3 unit vector GNS and Lecture22 definitions；子问/要求：(a) vector state φ_x on A⊂B(H)；(b) cyclic x identifies H_φx with H；(c) separating x identifies H_φx with subspace of H
- 14.4 boundary-circle algebra；子问/要求：point-evaluation states for C(∂D)；H_φz one-dimensional；countable subset of states gives faithful direct sum

## L15-s15.1 — Adjoining a Unit

类型subsection；物理页[100, 101, 102]；B译/A审。
起p100 y≈186：15.1 Adjoining a Unit
止p102 y≈182：therefore ||(x,a)*(x,a)||≥1.

对象：Theorem15.1+proof

公式边界：

- p100: Atilde={(x,a):x∈A,a∈C}
- p100: (x,a)(y,b)=(xy+bx+ay,ab)
- p100: ||(x,a)||=||x||+|a|
- p101: ||(x,a)||=sup{||xy+ay||:||y||≤1}
- p101: ||(x,0)||=sup{||xy||:||y||≤1}≤||x||
- p101: ||xy||=||xx*||/||x||=||x||
- p101: three-line submultiplicativity product expansion
- p101: two-line ||x(yz+bz)+a(yz+bz)|| bound
- p101: ||(x,a)(y,b)||≤||(x,a)|| ||(y,b)||
- p101: ||(x,a)||²=||(x,a)*(x,a)||
- p101: ||(x,a)*(x,a)||≤||(x,a)||²
- p101: ||(x,a)||²≤||(x,a)*(x,a)||
- p102: four-line comparison ||(x,a)*(x,a)||≥||(y,0)*(x,a)*(x,a)(y,0)||=||[(x,a)(y,0)]*[(x,a)(y,0)]||=||(x,a)(y,0)||²≥r²

备注：Includes unit-adjoining motivation, §7.1, involution (x,a)*=(x*,bar a), norm degeneracy contradiction e=−x/a, final inequality continuation p101→102.

## L15-s15.2 — Approximate Identities

类型subsection；物理页[102, 103, 104]；B译/A审。
起p102 y≈234：15.2 Approximate Identities
止p104 y≈244：The desired result then follows from Theorem15.2.

对象：Unnumbered approximate identity definition(a)(b)；Unnumbered increasing definition；Theorem15.2+proof；Corollary15.3+proof；Corollary15.4+proof

公式边界：

- p102: v_α=x1*x1+...+xn*xn
- p102: e_α=(1/n+v_α)^-1 v_α
- p103: f(t)=(1/n+t)^-1t
- p103 source: Σ[(e_α−1)x_i]*[(e_α−1)]=(1/n²)(1/n+v_α)^-2v_α
- p103: (1/n+t)^-2t≤n/4
- p103: Σ[(e_α−1)x_i]*[(e_α−1)x_i]≤1/(4n)
- p103 source: [(e_α−1)x_i]*[(e_α−1)]≤1/(4n)
- p103: ||(e_α−1)x_i||²≤1/(4n)
- p103: α={x1,...,xn},β={x1,...,xp}
- p103: v_α≤v_β,(1/n+v_α)^-1≥(1/n+v_β)^-1
- p103: (1/n)(1/n+t)^-1≥(1/p)(1/p+t)^-1
- p103: (1/n)(1/n+v_β)^-1≥(1/p)(1/p+v_β)^-1
- p103: e_α=1−(1/n)(1/n+v_α)^-1≤1−(1/n)(1/n+v_β)^-1≤1−(1/p)(1/p+v_β)^-1=e_β

备注：Visible left-ideal theorem gives ||x e_α−x||→0, proof p103 instead uses (e_α−1)x_i and e_αx; two factors visibly missing x_i. Right-ideal corollary15.3 also gives x e_α. Empty subset indexing with n^-1 minor omission. Preserve/annotate, no silent repair.

## L15-s15.3 — Two-Sided Ideals in C*-Algebras

类型subsection；物理页[104]；B译/A审。
起p104 y≈290：15.3 Two-Sided Ideals in C*-Algebras
止p104 y≈469：I is closed.

对象：Theorem15.5+proof

公式边界：

- p104: ||x*−x*e_α||=||x−e_αx||→0

备注：Intro says application of approximate identities.

## L15-s15.4 — Quotients of C*-Algebras

类型subsection；物理页[104, 105, 106]；B译/A审。
起p104 y≈517：15.4 Quotients of C*-Algebras
止p106 y≈282：for all x∈A.

对象：Lemma15.6+proof；Theorem15.7+proof

公式边界：

- p105: inf{||x−y||:y∈I}=lim||x−xe_α||
- p105: four-line limsup||x−e_αx|| argument
- p105: limsup||x−e_αx||≤inf{||x−y||:y∈I}
- p105: liminf||x−e_αx||≥inf{||x−y||:y∈I}
- p105: ||[x]||=inf{||x−y||:y∈I}
- p105: ||[x]||=lim||x−xe_α||
- p105: ||[x]||²≤||[x][x]*||
- p106: ye_α−e_αye_α=(y−e_αy)e_α→0
- p106: six-line norm expansion to lim||(1−e_α)(xx*+y)(1−e_α)||≤||xx*+y||
- p106: ||[x]||²≤||[x][x]*||

备注：Opening paragraph crosses p104→105. Lemma statement uses xe_α while proof e_αx: equivalent here two-sided ideal but source exact order retained.

## L15-s15.5 — Non-Unital Commutative C*-Algebras

类型subsection；物理页[106, 107]；B译/A审。
起p106 y≈331：15.5 Non-Unital Commutative C*-Algebras
止p107 y≈320：completing the proof of the theorem.

对象：Lemma15.8+proof citation[8]；Theorem15.9+proof

公式边界：

- p107: ||x||=||(x,0)||=|φtilde(x,0)|
- p107: φtilde(x,a)=φ(x)+a

备注：Includes locally compact noncompact C0(Ω), Stone-Weierstrass separates points/nowhere common zero and [8]. PartII ends p107, p108 PartIII title. No lecture15 exercise block.

## 逐页首尾

|物理页|可见印刷|首|尾|
|---:|---:|---|---|
|60|无，推定49|Part II|C*-ALGEBRAS|
|61|50|8 C*-Algebras|By uniqueness of unit,1*=1.|
|62|51|It is easy to check that an element x|some M_n(C).(See[11].)|
|63|52|8.3 Special Elements|normal and x^n=0 for some positive integer|
|64|53|n,then x=0.|x_n=x−a1+inb1|
|65|54|and observe that|orthogonal compliment of its kernel.|
|66|55|9 Commutative C*-Algebras|proof of proposition.|
|67|56|COROLLARY9.2|Γ image closed in C(M_A).|
|68|57|Finally,it is easy to check|closure of U is open.|
|69|58|9.4 Subalgebras and the Spectrum|||(λ_n1−x)^-1||→∞|
|70|59|We conclude that Ω_B|Φ is C*-homomorphism.|
|71|60|10 The Spectral Theorem and Applications|Φ(φ)=Γ(x)(φ)=φ(x).|
|72|61|By Corollaries5.2 and9.11|M_p(f,bar f)↔p(z,bar z)|
|73|62|extends to a C*-isomorphism Φ|continuous functional calculus.|
|74|63|10.4 Some Applications||x|≥0 for all x.|
|75|64|THEOREM10.6|shown in next lecture.|
|76|65|Exercises|spectrum of S into C.|
|77|66|11 Further Applications|Φ(f_n(x_n+1−x_n)).|
|78|67|Also by the continuous functional calculus|f(t)=f+(t)−f−(t).|
|79|68|and both f+ and f− are nonnegative.|lemma which is independent.|
|80|69|LEMMA11.3|v*v+vv*=2(v1²+v2²).|
|81|70|or|x1+x2≥0 and ax1≥0.|
|82|71|12 Polar Decomposition|ε>0 and all x∈H.|
|83|72|PROOF If T is invertible|hence T positive.|
|84|73|12.2 Partial Isometries|Σ|a_α|²<∞.|
|85|74|It is then clear that T|polar representation for complex|
|86|75|numbers.The following theorem|closure Ran W=closure Ran Q=[ker Q]⊥|
|87|76|if and only if|only if ker T*={0}.|
|88|77|13 Positive Linear Functionals and States|positive functionals Hermitian.|
|89|78|PROOF Suppose φ is positive|<x,y>=φ(y*x).|
|90|79|defines a semi-inner product|(n+1)²b²=|φ(x_n)|²≤||x_n||².|
|91|80|On the other hand,|a,b∈C and ||ax+b1||≤1,|
|92|81|and so|spectral theorem x≥0.|
|93|82|(d) Finally if x is normal|Let Φ be the|
|94|83|weak-star continuous linear functional|Hermitian functional bounded.|
|95|84|14 The GNS Construction|L_φ is a left ideal.|
|96|85|Let φ be a state|Φ(x)=T_x is C*-homomorphism.|
|97|86|PROOF For x1,x2,y∈A|⊕T_α:⊕H_α→⊕H_α|
|98|87|by|Φ(x)=⊕T_x^(φ)|
|99|88|where T_x^(φ) is defined by|is a C*-isomorphism.|
|100|89|15 Non-Unital C*-Algebras|existence can be proved|
|101|90|constructively.Consider semi-norm|||(x,a)||²≤||(x,a)*(x,a)|||
|102|91|for all x∈A and a∈C|e_α=(1/n+v_α)^-1v_α|
|103|92|Since the function|e_β.|
|104|93|This completes proof of theorem.|natural involution.We|
|105|94|proceed to show this involution|||[x]||²≤||[x][x]*|||
|106|95|for all x∈A|Γ:A→C0(M) surjective C*-isomorphism.|
|107|96|PROOF Let B be image of Gelfand transform|completing proof of theorem.|

## 源疑点（未静默修复）

- B-SOURCE-01 p[88, 94] §13.1 and Exercise13.7：Claim any Hermitian algebraic functional bounded is false absent continuity; Prop13.3 finite-norm proof affected. Preserve source and independent-review translator note.
- B-SOURCE-02 p[97, 98] §14.2：Direct sum family requires uniform bound sup||T_alpha||<infinity, absent in source.
- B-SOURCE-03 p[102, 103, 104] Theorem15.2 proof/Corollary15.3：Left/right handedness inconsistent, two visibly malformed products missing x_i. Detail crops p102-detail,p103-detail confirm.
- B-SOURCE-04 p[102] Theorem15.2 finite set indexing：Empty set not explicitly excluded despite 1/n.
- B-SOURCE-05 p[74] Theorem10.5：Invokes positive-spectrum implication established later in lecture11. Preserve source order.
- B-SOURCE-06 p[104, 105] Lemma15.6：Statement uses right product xe_alpha, proof left e_alpha x. Two-sided ideal makes equivalent but transcribe exactly.

本清单不构成译稿批准；逐段语义、当前字节身份、编译、看图与冷重建证据另行登记。

## 逐节独审后的来源清单精确更正

以下由实际源图放大及A独审回查确认，JSON已同步；以上清单的旧简写仅作定位，精确原式以下列为准。

- Th9.4范数链含中间乘积项 `||overline(Γ(x))Γ(x)||∞`，无新增 `r(Γ(x*x))` 项；Γ与Γ^{-1}均保持序。正文已按A逐式回查通过。
- Th11.2原书写 `Since f+(t)=0`（应f+(0)=0），极限式第二项 `p(−x2)` 缺下标n；两原式保留，独审译校注说明。
- Cor12.9原唯一条件是 `RanW=closure(RanQ)`，左边RanW没有上划线；正文两处精确保留。
- Ex12.5原书写未定义的 `V*`，没有静默换T*；译校注明确应T*。Th12.5原称Lemma12.4，实际是Cor12.4，正文保原称呼且可点击引用到实际推论。
- Th13.7源印刷80末是对所有a,b∈C的谱成员式 `aλ+b∈σ(ax+b1)`；印刷81“从而”衔接范数链。没有增加 `||ax+b1||≤1` 限制。
- Prop13.8两处闭单位球都为 `(A*)_1`，以放大可见原页为准，没有OCR误判的双层下标。
- Ex9.7原少保单位条件（零映射反例），Ex13.5一般非交换情形纯态取值不必在正规谱内（M2 diag(0,1)均分向量纯态取1/2）；原题完整保留，均加经A独核的SourceError。

PartII45当前文件现均由A完成独立语义/逐式/全题/全部索引审校，批准身份仍以review-ledger-A.json和A真实字节副本为准。B的机械完整性核证见B-PartII-structural-audit.json，独立批准当前性核证见B-PartII-approval-audit.json，二者均不替代语义审校。
