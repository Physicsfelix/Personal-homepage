from pathlib import Path
import json, hashlib, re, sys

ROOT = Path(__file__).resolve().parents[2]
RANGES = {16: [108,113],17:[114,118],18:[119,123],19:[124,128],20:[129,134],21:[135,139],22:[140,144],23:[145,150],24:[151,155],25:[156,159],26:[160,164]}
for chapter in map(int, sys.argv[1:]):
    files = sorted((ROOT/'book/chapters').glob(f'ch{chapter}*.tex'))
    if chapter == 16:
        files.append(ROOT/'book/matter/part3.tex')
    bounds = RANGES[chapter]
    handoff = dict(translator='C', reviewer='B', status='translated-awaiting-independent-review', source_physical=bounds, source_printed=[p-11 for p in bounds], files=[dict(file=p.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files])
    (ROOT/f'qa/inventory/C-ch{chapter}-handoff.json').write_text(json.dumps(handoff,ensure_ascii=False,indent=2)+'\n', encoding='utf-8')
request = json.loads((ROOT/'qa/inventory/index-anchor-requests-C.json').read_text(encoding='utf-8'))
expected = {reference['id']:dict(English=entry['English'],**reference) for entry in request['entries'] for reference in entry['references']}
placed = []
review_ledger = ROOT/'qa/review-ledger-B.json'
approved = {}
if review_ledger.exists():
    for approval in json.loads(review_ledger.read_text(encoding='utf-8')).get('records',[]):
        if approval.get('status') == 'approved':
            approved[approval['file']] = approval
for path in sorted((ROOT/'book/chapters').glob('ch*.tex')):
    if int(path.stem[2:4]) < 16:
        continue
    for line_number,line in enumerate(path.read_text(encoding='utf-8').splitlines(),1):
        for identity in re.findall(r'\\IndexMark\{([^}]+)\}',line):
            assert identity in expected, identity
            record = dict(expected[identity])
            record.update(status='placed-awaiting-independent-review', translation_file=path.relative_to(ROOT).as_posix(), line=line_number, source_match_note='Actual visible source occurrence at corresponding definition/theorem/discussion; no translated-page arithmetic.', translation_context=line)
            if identity == 'idx124p150':
                record['source_match_note'] = 'Original index covers printed149,150,151,152 as a lecture-wide page reference. Printed150 contains no type-decomposition term in its body. This anchor is at the actual first body object on that source page, Proposition26.1, to carry that page coverage; it is not represented as a term definition.'
            approval = approved.get(path.relative_to(ROOT).as_posix())
            if approval and approval['sha256'] == hashlib.sha256(path.read_bytes()).hexdigest():
                record.update(status='placed-and-independently-approved-in-current-file',reviewer='B',independent_approval_report=approval['report'],current_file_sha256=approval['sha256'])
            placed.append(record)
assert len({p['id'] for p in placed}) == len(placed)
pending = [record for identity,record in expected.items() if identity not in {p['id'] for p in placed}]
(ROOT/'qa/inventory/C-index-anchor-map.json').write_text(json.dumps(dict(owner='C',placed=placed,pending=pending),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(handoffs_updated=list(map(int,sys.argv[1:])),anchors_placed=len(placed),anchors_pending=len(pending))))
