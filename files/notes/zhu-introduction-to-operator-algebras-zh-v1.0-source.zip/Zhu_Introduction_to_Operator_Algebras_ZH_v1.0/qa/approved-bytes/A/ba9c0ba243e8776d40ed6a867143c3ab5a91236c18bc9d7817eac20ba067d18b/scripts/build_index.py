"""Rebuild/check a translated index from preserved original entries and real TeX anchors.

No original printed page is ever used as a translated page. Default: read-only check.
Only --write changes the generated TeX. --draft preserves every unresolved anchor.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fields(text, start):
    assert text[start] == '{'
    depth, out, begin = 0, [], None
    for pos in range(start, len(text)):
        ch = text[pos]
        if ch == '{':
            if depth == 1:
                begin = pos + 1
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 1 and begin is not None:
                out.append(text[begin:pos])
                begin = None
            if depth == 0:
                return out
    raise ValueError('Unclosed AUX group')


def read_pages(aux):
    text = aux.read_text(encoding='utf-8')
    found = {}
    for match in re.finditer(r'\\newlabel\{idx:([^}]+)\}', text):
        f = fields(text, match.end())
        assert len(f) >= 2
        assert match[1] not in found, 'Repeated index label in AUX'
        assert re.fullmatch(r'\d+', f[1]), (match[1], f[1])
        found[match[1]] = int(f[1])
    return found


def generate(data, notes, pages):
    lines = [
        '% Generated from preserved originalindex entries and actual translatedpage anchors.',
        '% 136 originalentries / 208 originalreferences / 56 originalstars are retained in QA data.',
        '% Same translatedpage references within oneentry are merged; star survives if any originalfirst-use mark lands there.',
        r'\begin{multicols}{2}', r'\small\raggedright', r'\setlength{\parindent}{0pt}',
    ]
    evidence = []
    for e in data['entries']:
        groups = {}
        for a in e['references']:
            key = pages[a['id']] if pages is not None else a['id']
            groups.setdefault(key, []).append(a)
        refs, group_evidence = [], []
        for page, source_refs in groups.items():
            chosen = next((a for a in source_refs if a['star']), source_refs[0])
            star = any(a['star'] for a in source_refs)
            refs.append(r'\IndexRef{' + chosen['id'] + '}{' + ('*' if star else '') + '}')
            group_evidence.append({'translated_page': page if pages is not None else None,
                                   'chosen_actual_anchor': chosen['id'], 'star': star,
                                   'all_original_references': source_refs})
        en = e['English'].replace('C*', r'$C^*$').replace('L∞', r'$L^\infty$').replace('&', r'\&')
        lines.extend([
            '% ' + e['id'] + '; sourceindex physical' + str(e['source_index_physical_page'])
            + '; originalprinted references ' + e['original_page_references'],
            r'\par\addvspace{4pt}\noindent ' + e['ChineseTeX']
            + r'\enspace\textnormal{(' + en + r')}\quad ' + ', '.join(refs) + r'\par',
        ])
        if e['id'] in notes:
            lines.append(r'{\footnotesize\noindent\textbf{译校注：}' + notes[e['id']]['ChineseTeX'] + r'\par}')
        evidence.append({'entry': e['id'], 'English': e['English'], 'groups': group_evidence})
    lines.append(r'\end{multicols}')
    return ('\n'.join(lines) + '\n').encode('utf-8'), evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--aux', type=Path)
    parser.add_argument('--write', action='store_true')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--draft', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    source = root / 'qa/inventory/index-entries-root.json'
    data = json.loads(source.read_text(encoding='utf-8'))
    notes = json.loads((root / 'qa/inventory/index-errata-root.json').read_text(encoding='utf-8'))['entries']
    target = root / 'book/matter/index-entries.tex'
    requested = [a['id'] for e in data['entries'] for a in e['references']]
    assert len(data['entries']) == 136 and len(requested) == 208 and len(set(requested)) == 208
    assert sum(a['star'] for e in data['entries'] for a in e['references']) == 56
    occurrences = {anchor: [] for anchor in requested}
    for path in (root / 'book').rglob('*.tex'):
        if path.name.startswith('preview') or 'build' in path.parts:
            continue
        for anchor in re.findall(r'\\IndexMark\{([^}]+)\}', path.read_text(encoding='utf-8')):
            assert anchor in occurrences, ('Unexpected anchor', anchor, str(path))
            occurrences[anchor].append(path.relative_to(root).as_posix())
    missing = [k for k, v in occurrences.items() if len(v) != 1]
    if not args.draft:
        assert not missing, ('Missing or repeated actual anchors', missing)
    aux = args.aux.resolve() if args.aux else root / 'book/build/main.aux'
    pages = None if args.draft else read_pages(aux)
    if pages is not None:
        assert set(requested) == set(pages), ('AUX anchor set differs', sorted(set(requested) - set(pages)))
    result, evidence = generate(data, notes, pages)
    old = target.read_bytes() if target.exists() else None
    report = {'mode': 'draft' if args.draft else 'actual-TeX-anchor-pages',
              'source_data_sha256': digest(source.read_bytes()), 'aux': str(aux) if pages is not None else None,
              'source_entry_count': 136, 'source_reference_count': 208, 'source_star_count': 56,
              'actual_unique_anchor_count': sum(len(v) == 1 for v in occurrences.values()),
              'missing_or_repeated_anchors': missing,
              'generated_sha256': digest(result), 'changed_from_current': old != result,
              'original_reference_to_translated_page_groups': evidence}
    if args.write:
        target.write_bytes(result)
    if args.report:
        args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'original_reference_to_translated_page_groups'}, ensure_ascii=False))
    if not args.write and old != result:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
