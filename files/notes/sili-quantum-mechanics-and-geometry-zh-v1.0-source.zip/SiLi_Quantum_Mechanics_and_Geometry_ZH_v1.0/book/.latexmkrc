$pdf_mode = 5;
$max_repeat = 10;
$xelatex = 'xelatex -no-shell-escape %O %S';
