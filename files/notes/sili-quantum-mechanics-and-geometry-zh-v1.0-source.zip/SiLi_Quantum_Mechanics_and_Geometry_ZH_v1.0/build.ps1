$ErrorActionPreference = 'Stop'
Push-Location (Join-Path $PSScriptRoot 'book')
try {
  & latexmk -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
  if ($LASTEXITCODE -ne 0) { throw 'LaTeX build failed' }
} finally { Pop-Location }
