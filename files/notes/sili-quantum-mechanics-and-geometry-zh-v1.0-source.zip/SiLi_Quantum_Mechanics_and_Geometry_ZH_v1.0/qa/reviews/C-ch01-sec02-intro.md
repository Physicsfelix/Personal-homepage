# 量子讲义独立审校：Q-ch01-sec02-intro（C）

状态：approved。实际源码book/chapters/ch01-sec02-intro.tex SHA256：c4ae866465ebd469f20d94e976b00903eac00facc84a28ae76a3914dc665ffbb。
原件SHA256：aa0d0055bf4f8788a5c14fffd67ba61bb7af7cbab267d85ab950ac3088a97d5e。

- 原物16的1.2只有可观测量标题，紧接1.2.1；译稿准确保留标题而未补造导语。

C未修改译稿。本次不是排版/目录/链接/冷重建终验。
