# PartII向量字体候选03独立审校（C）

26份候选白名单批准，正式book仍是before，C ledger暂未改。24份before SHA与已完成的C语义批准匹配；另两份与我完整4.7数学审前保存的真实raw全文完全相同。

我直接从冻结原PDF162–249按rawdict逐glyph提取，1848条字体、字符、bbox全部独立匹配；其中1601个LMRomanDemi粗体候选，247个CMMI原plain保留。对所审七个字母a/p/q/w/x/y/z，该88页实际所有1601个bold glyph均覆盖，无遗漏。另自写TeX数学上下文检查，每1848个offset均是真变量，不是命令名、注释、label或译校注。

我逐公式核了候选中24个(page,letter)混合组的B/P标记、源行及原bbox，不以数量相等代替对齐判断。原165 f(x)的两plain、176 forall|x|的plain、172的一维量子化表、192的一维例、244的分量q^i/p_i、246的x^i/z^i和向量阶梯a均按实源区分。六个源公式区另3x实际放大看。

每候选由真实before在指定offset独立构造，仅加分组mathbf字母宏；逆向独立恢复全部UTF8 bytes，所有原源锚、注释、换行严格不变。26份SHA详见JSON。全部135当前已批准文件仍实际匹配，未用候选hash冒充已应用版本。

root可在before SHA守卫通过后，仅应用这些已审候选的精确bytes；应用后仍需C核actualafter=candidate，再承接24旧语义批准并用已存4.7完整数学基线签三叶。最终全书图形、目录、链接与冷编另验。
