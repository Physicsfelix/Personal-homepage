# 量子讲义独立审校：Q-ch01-sec02-sub03（C）

状态：**通过**。译者B、审者C分离；实际文件book/chapters/ch01-sec02-sub03.tex。当前SHA256：4794f4ce83dea184b2f47e0e701cbb0657c927040a547d550af6dd38dbc5fd7b。
原PDF SHA256：aa0d0055bf4f8788a5c14fffd67ba61bb7af7cbab267d85ab950ac3088a97d5e。原物理17–18范围已完成逐段逐式实页核；本次对实际新增注作精确差分回查。

保存的旧实际字节SHA 7f113daaa5ae03cfaeab2dc35a1421df2103c18acb2fbf5be30e67e3d1b35b28与此前C报告匹配；当前文件以前者为完整字节前缀，仅追加一个独立source-id及一条sourceerror。

实际读新增注，仅对以Opsi所写内积公式标明0!=psi inDomO；与已独立核的psi_n=c/n反例一致，未夸称所有可能的二次型期望定义都必须DomO。

原作者全部公式/段落/示意图均未改写。两项源范围问题已关闭；实际编译版面、全目录/导航和冷重建仍属后续独立验收。
