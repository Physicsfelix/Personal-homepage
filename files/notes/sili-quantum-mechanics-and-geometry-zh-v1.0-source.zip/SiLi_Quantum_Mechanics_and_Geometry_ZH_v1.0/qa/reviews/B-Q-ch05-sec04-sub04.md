# Q-ch05-sec04-sub04 B独立完整源审

root译稿当前 `bcadac2909e38a746213529dd06414b27abca5ecce0d978a3513ca831962f224` approved，原物理页[288, 289, 290, 291, 292, 293]全部相关段式/原号/证明/图/注已实际核。

复化/共轭/Lagrange子空间、极化三条件/实与Kähler两类、极化截面及相容性全式；两实极化全部连接计算、全纯例的曲率/范数、一般复流形/CP1两个图三条粘合/自旋/辛形式完整。

固定L0张量幂/曲率/h与k对应/χ及HRR/正线丛充分大k消失/首项渐近到状态数全部逐段式核。

原P-potential误称保留+短注；源su直立LMRoman10Regular唯一字形现已恢复，B初读actualbefore与rootbefore全同，单项正逆严格原字节还原。

横截P∩barP=0不强制Hermitian正定，正Kähler还需正性；现note明确这一范围，后面正线丛情形source293也有显式positive，正确。

实极化非零f(x)沿p无限体积不能属于相空间L²，Pprime同理，故原直接子空间只得0；在叶空间/半密度重建内积注正确。

K=|z|²给ω^n/n!=2^n d^(2n)z，与早先(πh)^−n高斯归一常数不同而函数空间同，注正确。

P势截面确原P-potential，按前定义读为P极化，注正确。

HRR中ch(L0^k)=exp(kω)首项k^n Volω，h=1/(2πk)给(2πh)^−n Volω，源正性假设已明，未因前例仅symplectic就误判消失定理无条件。

此报告为完整语义源审；不代替最终PDF版式或冷包。