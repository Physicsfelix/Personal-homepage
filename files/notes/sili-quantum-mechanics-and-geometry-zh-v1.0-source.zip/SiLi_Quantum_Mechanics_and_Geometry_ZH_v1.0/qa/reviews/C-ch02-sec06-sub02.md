# 量子独立源审 Q-ch02-sec06-sub02

批准当前实际SHA `9eb49d93a71fa0ceba7a59688b059e4486019defc170e4451a4f9a7c9a614544`。B译，C非作者逐源审。

- 原113的2.6.2标题至116的2.6.3前全部实际逐段式读，Jacobi参数族/两初值系统/变分方程/phi0=J、原评注2.6.1、完整Hamilton-Jacobi四导数与-pprime=-mvprime、混合Hessian=-m/J及VanVleck–Pauli–Morette全轨道求和式齐。
- 起点0与一般xprime不一致确见原114两初值，原式保留+平移坐标/应xprime注准确。共轭点只保证无穷小场而非精确轨道族的既有注独核：我从Duffing xsecond+x+x³=0独立算v³项y(t)，验证初值和强迫方程，x(pi;v)=-3pi v³/8+O(v5)，尽管J(pi)=0仍是孤立端点解。推理另存QA，不入读者书。
- 原自由例2.6.2全部直线两端插值/作用量/交叉偏导/核，以及谐振例2.6.3明确omegaT不在piZ、整条sin/cos作用量/偏导/核均独算正确；两二次势例Ksc=K精确，归一化及相位与前2.4一致。
- 两个native Jacobi图各原点xprime/xdoubleprime、蓝vprime与所有红J箭头实际3x完整看；原PDF同clip3x独立重建RGB和尺寸严格全同，无省图或习题。

范围各原页已实际整页审读，无未决项；未改译文，最终全书图形/目录/导航/冷编另验。
