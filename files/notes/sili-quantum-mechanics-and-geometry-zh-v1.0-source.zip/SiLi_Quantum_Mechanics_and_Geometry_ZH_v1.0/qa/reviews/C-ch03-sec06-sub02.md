# 量子独立源审：Q-ch03-sec06-sub02（C）

结论：通过。译者root、审者C分离。当前实际SHA256：`d9e99c09a8457b7d4b40053fb1fc604d304cb69faf602a1497ab006756ed2a8d`。
原PDF SHA256：`aa0d0055bf4f8788a5c14fffd67ba61bb7af7cbab267d85ab950ac3088a97d5e`。

- 原190–193全段式、3.6.3/4全证明及例3.6.5完整。边缘双积分的两个共轭、δ归一化与中心变量Jacobian绝对值1、动量hat的非酉Fourier归一化正确；源证明末两无帽ψ照录并短注，命题原正确帽式全保。
- Wigner实性可由y换−y取共轭独核，Cauchy–Schwarz换元每积分2^n因子给1/(πh)^n上界，体积不确定性和全部归一化条件齐。推论源未平方normψ那行在明确normψ1前提下仍真，不添假错误注。
- 相干态完整Gaussian各项/共轭barz2/交叉−z1barz2、两步Gaussian积分/全归一化因子独算准确。源W_z1,z2采用正Fourier相位，与前Wig负相位不同，当前忠实保留；最终实Hermite态的Wigner关于ξ为偶，两种相位给相同u表达式，没有静默改号。
- 收集对角(z1barz2)^n/n!系数得(−1)^n∑binom(n,j)(−1)^j(2u)^j/j!，与源Laguerre公式一致。全部Hn/a系数、u定义、Laguerre Rodrigues式与L0–L4五项和末省略号齐，无新增习题解答。

原190–193全部实际逐页读，按本单元排他边界核完整内容。待修项0；C未改作者稿。正式版面与冷编另验。
