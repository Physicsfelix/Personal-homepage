# 量子独立源审 Q-ch04-sec04-sub01

批准当前实际SHA `a60daeb5fa1540f3c6a07648278ee8b4fe78c7ae9068023d84ae6bc72fadcdd6`。root译，C非作者审。

- 实看原226下–227的4.4.2前全段式；2n正则对易子及两个零对易/Schrodinger乘法与微分算子/两单参数群移位hbar t与调制tx/Weyl相位+i hbar st全保。
- 独核U(t)V(s)作用为exp(is(x+hbar t))phi(x+hbar t)，所以源正相位正确；源BCH仅形式、无界域条件不等价的限制性结尾忠实保留。

原范围逐页完整实看，未决项0。未改译文，最终全书版面/目录/导航/冷编另验。
