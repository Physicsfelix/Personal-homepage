# 量子独立源审 Q-ch05-sec01-sub04

批准当前实际SHA `1758dc5f5785de99a50c9381ee093bf8cb7d6d5a824c99b9d91023060e3560ab`。root译，C非作者逐源审。

- 原260标题至264的5.2前全部实际逐段逐式读，十五原号5.1.18–32齐，原无证5.1.26/31均未invent证明。辛闭/非退化两条件、局部omega逆矩阵和Hamilton向量场三步收缩证明全保。
- 严格保原i_V omega=df、Poisson=i_Vf i_Vg omega=Vf(g)、Cartan/Liouville/向量场交换子及Jacobi全部长推导；独核原omega=dp∧dq给Vf=+f_q∂p−f_p∂q和{q,p}=1，不按另一符号习惯翻号。
- 余切Liouville1form p dq、lambda拉回alpha、Lagrangian graph闭形式/phase和非exact circle积分±πR²逐式核；两个当前native图3x独立原clip RGB全同且全图实际看，X/T*X/Lalpha及p/q/L和定向箭头完整。
- 原体积处n=dimM照留并明确应2n=dimM的注正确；一般flow forall t仅存在域/完备性短注正确（Vf可不完备），而底函数引起的纤维平移(p,q)→(p+t df,q)全时有定义，零截面到L_df及Lalpha到Lalpha+df全部齐。

范围各原页已实际整页审读，无未决项；未改译文，最终全书图形/目录/导航/冷编另验。
