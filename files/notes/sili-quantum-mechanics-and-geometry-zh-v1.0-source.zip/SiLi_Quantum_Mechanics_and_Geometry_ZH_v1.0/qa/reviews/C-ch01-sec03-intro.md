# 量子独立源审：Q-ch01-sec03-intro（C）

状态：approved。译者B、审者C分离；当前文件book/chapters/ch01-sec03-intro.tex SHA256：558448ad96be08b542b2f47c27b3630c406067c341eb8e1e6bbbe47c30c01e7b。
源PDF SHA256：aa0d0055bf4f8788a5c14fffd67ba61bb7af7cbab267d85ab950ac3088a97d5e。

- 原18页1.3标题后直接1.3.1；仅标题单元，未虚构节导语。

本次实际逐页对原18–22及当前源文核验，不含后续1.4；C未改B稿。正式版面、导航和冷重建仍须后续验收。
