# 量子4.7独立源审 Q-ch04-sec07-sub01

批准当前实际SHA `edf82af5fb35c03152ee9566a2c929234e09bf01b4a52ce008bd5a8fac1f823f`。root作者C非作者。

- 原242的4.7.1至245的4.7.2前全部完整实读，五原号4.7.1–5的陈述/全部证明齐，psi0归一化/Heisenberg位移算子全相位/coherentGaussian/超完备恒等分解全部公式与x,y,q,p积分维数、2pi hbar系数齐。
- 独立直接求导a=(x+hbar partialx)/sqrt2得特征值(q+ip)/sqrt2；source分母多hbar之注准确。原证明f,g∈S(R2n)维数错误保留+应Rn注正确。恒等分解通过p积分的delta和q Gaussian积分独算正确。
- 相干态重叠的Heisenberg群因子、全Gaussian配方与结果exp(-distance²/(4hbar)+i(q1p2-q2p1)/(2hbar))独核；从模平方得到heat时间hbar/2的Berezin期望正确。
- 投影Wigner变换逐五步，完成平方y-2i(p-xi)、结果2^n Gaussian，积分Berezin符号给heat时间hbar/4，故aB=(exp(hbarDelta/4)a)^W成立；全部原13对象中的首5完整，既有scope注正确。
- 源LMRomanDemi向量字形已由C独立1848glyph/bbox/真数学token与24混合组逐式检查批准，再独核26实际after全byte等已批候选；本叶非字形数学/中文/锚/行尾严格恢复完整数学审前raw。标量分量与符号a等原plain保留，没有全局统一。

原242–249全段式已实际读，先保完整数学基线；后只以实源字体白名单精差分闭环，没有重读未变数学的虚签。无未决项，最终全书版面/目录/链接/冷编另验。
