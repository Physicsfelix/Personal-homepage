# 量子讲义独立审校：Q-ch01-sec02-sub01（C）

状态：approved。实际源码book/chapters/ch01-sec02-sub01.tex SHA256：9547d1fd2f917ae0476ea8f79fa5bda45cccad99e1a2503486fe0bd661e20a7a。
原件SHA256：aa0d0055bf4f8788a5c14fffd67ba61bb7af7cbab267d85ab950ac3088a97d5e。

- 物16–17完整逐段式核，Obscl/O(M)、函数类别说明、Poisson映射、斜对称/Leibniz/Jacobi三项及坐标例俱全。
- x上i/p下i、dx^i wedge dp_i、两项括号符号与偏导次序按可见页准确，无原号对象/图/练习遗漏。

C未修改译稿。本次不是排版/目录/链接/冷重建终验。
