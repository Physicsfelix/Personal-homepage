# 量子PartI六叶O/A字体恢复的独立差分审校（C）

批准六份实际current。逐份读取真实before和current，before SHA与C旧语义批准完全相同；仅85个TeX用法从mathcal O/A恢复EuScript O/A，严格逆向恢复原bytes。所有原源锚、注释、换行和非字母字体命令/文字/数学均未变。

我独立从冻结原PDF重新提取物16、18、19、20、22、23的实际字母font/text/bbox，逐条匹配源证据，确认这些O/A为EUSM10，邻近plain算子A为CMMI且不变。85包括译校注引用，未冒称有85个不同原书glyph。原有逐段逐式审校通过身份据此继承到新SHA，未虚称重读旧数学。

六份前后SHA与承接的旧报告逐项见JSON。C ledger全部108个当前批准文件已重算hash零不符。最终全书图形、导航、冷编另验。
