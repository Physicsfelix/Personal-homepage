# 量子独立源审：Q-ch01-sec04-sub02（C）

结论：**通过**。当前实际源码book/chapters/ch01-sec04-sub02.tex SHA256：245c7ae97bb9afc8cfbf8313d5f713046b10c97ed070d160c4977fce7d77d78a。译者B、审者C分离。
原PDF SHA256：aa0d0055bf4f8788a5c14fffd67ba61bb7af7cbab267d85ab950ac3088a97d5e。

- 原25–26完整逐段式读，有限维trace矛盾、无界算子域讨论、DomAB交DomBA条件、原例1.4.5全过程完整。
- 周期动量分部积分中bar覆盖整条−ihbar dpsi1/dx，边界项及内积次序正确；C1周期域可延拓自伴的原措辞保留，没有错误宣称C1域本身已自伴。
- 独立算psi=e^{2piix}：norm1，p本征值2pihbar，Deltap0；X均值1/2、二阶矩1/3故Deltax1/sqrt12。Xpsi端点0/1不周期，故psi不在Dom(pX)。已有note001准确将对易子期望称形式值并保留原“失效”说法。
- 新增note002实际读并独核：A=diag n,B0,psi_n=c/n²处于共同域DomA却不在DomA²；二阶矩按||Apsi||²/||psi||²的二次型或谱积分有意义，literalA²psi需更强域。原Robertson范数版及其共同域条件均未改。

源文完整阅读快照SHA 0f930fb62456500a59943b88a4b0ccced3b6a19d569f76cb7ccce9d0397be7d7与作者保存的actualbefore逐byte相同；当前仅追加note002，严格保持旧字节前缀。新增注已实际读并数学独核。

待修项0。原物22–26完整页实看，1.5及后文未包括；C未改B稿。正式版面、导航、字体与冷重建另验。
