# 量子独立源审 Q-ch02-sec08-sub04

批准当前实际SHA `68837f2e5bb1477945305ee1b456c72431c1f9b11d999917484326c898032ca1`。B译，C非作者逐源审。

- 实际152的2.8.4至156的2.8.5前全五页逐段式读，四原号2.8.11–14与所有例的完整13行推导齐；原theta周期1、Fourier基/删0模/hatdelta=delta−1/逆dtheta引号完整，未声称全空间导数可逆。
- Green Fourier系数i/(2πn)和g(theta)=theta−1/2、端点0/反对称、Fourier分部积分原少系数的零残余积分如源保留、五步distribution检查全部核；独核∂theta1g(theta2−theta1)=delta−1和两单侧±ih/2无反号。
- Cyc顺时针互异配置域、旋转商simplex体积1/m!、关联定义外m!、全部多变量Wick指数/最后各背景向量同一评价和h→0主项完整；source155 Demi粗体背景x/p与156标量混排、EuScriptA均按源。
- 例2.8.13六步积分/平移theta/去奇次项/偶次系数(2m+1)2^(2m)(2m)!及xp、x²p²−h²/6齐；例2.8.14七步三项propagator和二项乘积全正负完整。C独立SymPy按0<=theta2<=theta1<=1积分得到1/12与0，外2!给ih*xp/6，note001实A需复化正确。
- 3native当前图独立sourceclip3xRGBexact且C全部3x实际看，S1到R2n映射gamma、完整锯齿所有实心/空心/刻度、循环theta标签/省略号无裁漏。

范围各原页已实际整页审读，无未决项；未改译文，最终全书图形/目录/导航/冷编另验。
