# 量子4.7完整数学源审基线（待字形差分，C）

实际全读原242–249八页，包括末两行。三叶actual raw全文已在审前snapshot保存并现再次逐byte匹配。13原号/全部陈述、证明与既有四类译校注均完整逐式核验，数学待修0；尚未把三叶加入批准ledger。

- ch04-sec07-intro: 源242原4.7节标题完整，未删导语或虚添。
- ch04-sec07-sub01: 原242的4.7.1至245的4.7.2前全部完整实读，五原号4.7.1–5的陈述/全部证明齐，psi0归一化/Heisenberg位移算子全相位/coherentGaussian/超完备恒等分解全部公式与x,y,q,p积分维数、2pi hbar系数齐。; 独立直接求导a=(x+hbar partialx)/sqrt2得特征值(q+ip)/sqrt2；source分母多hbar之注准确。原证明f,g∈S(R2n)维数错误保留+应Rn注正确。恒等分解通过p积分的delta和q Gaussian积分独算正确。; 相干态重叠的Heisenberg群因子、全Gaussian配方与结果exp(-distance²/(4hbar)+i(q1p2-q2p1)/(2hbar))独核；从模平方得到heat时间hbar/2的Berezin期望正确。; 投影Wigner变换逐五步，完成平方y-2i(p-xi)、结果2^n Gaussian，积分Berezin符号给heat时间hbar/4，故aB=(exp(hbarDelta/4)a)^W成立；全部原13对象中的首5完整，既有scope注正确。
- ch04-sec07-sub02: 源245的4.7.2起至249末两行全部实读，八原号4.7.6–13/所有原证明及末6.1.3回指齐。Gaussian测度e^(-|z|²/hbar)/(pi hbar)^n、Fock全纯L2空间/多指标lambdaI及范数、Bargmann核z²而非|z|²、两个分量交织与全向量阶梯公式正确。; Bergman e^(z barw/hbar)核的标准正交基和/再生内积第一槽共轭/恒等分解全证独核；Bpsi0=1及Bpsi_qp=e^(-|w|²/(2hbar))K_w，w=(q-ip)/sqrt2由完成平方独算。原证明末误写/2保留+注正确。; 一般无界f的Mf/Tf需要自然定义域，而Schwartz符号有界；既有最短域注准确。Toeplitz核及积分、Bargmann坐标w=(q-ip)/sqrt2等同、正性/两种恒等分解全链齐。; 范数上界来自Pi压缩和Ma；下界取Schwartz符号的模最大点，coherent期望=heat hbar/2 a=a+O(hbar)给liminf。再以heat hbar/4的CV有限半范数界导出Weyl范数同一极限，所有常数/符号与极限均独核，无新数学待修。

剩余实源字形问题：LMRomanDemi向量q/p/x/y/z/w和向量a被plain排写，须与符号a、标量坐标x^i/z^i区别。root将按真实span给白名单纯字形delta。该delta精验后可继承本次数学完整审读，不重读未变正文，不以旧hash冒签current。
