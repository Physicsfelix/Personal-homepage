# 量子独立源审 Q-ch02-sec04-sub01

批准当前实际SHA `88b9523fd24fa41b62eb8174fa8a9a94c00f9edca3b5d7ee839946e9c8bbbe29`。B译，C非作者审。

- 实看原94–95全页，经典轨道两端插值/全部gamma边界与二次作用量分解/椭圆算子A=-d²-omega²/泛函Gaussian全部步骤齐；源hat正体H和原x/p字体、T与t上下标逐式保留。
- Dirichlet正弦谱lambda_m、行列式双乘积、zeta第一因子2T和收敛Euler正弦乘积均独核，得到detA=2sin(omegaT)/omega和自由短时归一化。经典作用量全部五步积分分部/两端值代入/交叉2xprime xdoubleprime/最终cot与csc核精确。
- 既有范围注正确：sin(omegaT)非零保证原两点边界唯一轨道与普通函数核表达；焦散需分布，平方根相位沿短时演化延拓（Maslov跳跃）而非逐点主值。作者原公式全保，无图或习题遗漏。

原范围逐页完整实看，未决项0。未改译文，最终全书版面/目录/导航/冷编另验。
