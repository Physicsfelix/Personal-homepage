# 量子4.7独立源审 Q-ch04-sec07-sub02

批准当前实际SHA `ffb627a95c8680da7bdefa8496c6450b0557bd481cf3bf87811b65e64c0d8af6`。root作者C非作者。

- 源245的4.7.2起至249末两行全部实读，八原号4.7.6–13/所有原证明及末6.1.3回指齐。Gaussian测度e^(-|z|²/hbar)/(pi hbar)^n、Fock全纯L2空间/多指标lambdaI及范数、Bargmann核z²而非|z|²、两个分量交织与全向量阶梯公式正确。
- Bergman e^(z barw/hbar)核的标准正交基和/再生内积第一槽共轭/恒等分解全证独核；Bpsi0=1及Bpsi_qp=e^(-|w|²/(2hbar))K_w，w=(q-ip)/sqrt2由完成平方独算。原证明末误写/2保留+注正确。
- 一般无界f的Mf/Tf需要自然定义域，而Schwartz符号有界；既有最短域注准确。Toeplitz核及积分、Bargmann坐标w=(q-ip)/sqrt2等同、正性/两种恒等分解全链齐。
- 范数上界来自Pi压缩和Ma；下界取Schwartz符号的模最大点，coherent期望=heat hbar/2 a=a+O(hbar)给liminf。再以heat hbar/4的CV有限半范数界导出Weyl范数同一极限，所有常数/符号与极限均独核，无新数学待修。
- 源LMRomanDemi向量字形已由C独立1848glyph/bbox/真数学token与24混合组逐式检查批准，再独核26实际after全byte等已批候选；本叶非字形数学/中文/锚/行尾严格恢复完整数学审前raw。标量分量与符号a等原plain保留，没有全局统一。

原242–249全段式已实际读，先保完整数学基线；后只以实源字体白名单精差分闭环，没有重读未变数学的虚签。无未决项，最终全书版面/目录/链接/冷编另验。
