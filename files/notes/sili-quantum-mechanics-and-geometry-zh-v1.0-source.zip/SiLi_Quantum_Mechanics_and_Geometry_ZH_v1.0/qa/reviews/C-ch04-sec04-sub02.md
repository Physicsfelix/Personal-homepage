# 量子独立源审 Q-ch04-sec04-sub02

批准当前实际SHA `20013958f5e8b8814912c898033dc0811eed2010fcf085199feb68c87e91196f`。root译，C非作者审。

- 实看原227的4.4.2起至229例4.4.2末全部，源定理4.4.1与完整原证明/例4.4.2无省略。伴随三步双共轭/对称条件、P_phi复合四重积分四步、扭卷积与delta_ab/Gaussian Phi及全配方中间式全部原常数/相位保留。
- 独立展开二重Gaussian配方前后指数恒等差0；并以Schrodinger标准基态直接积分核验P_Phi U(a)V(b)P_Phi的标量exp(-hbar(a²+b²)/4+i hbar ab/2)，源dagger确漏hbar，注正确。P²=P/P*=P、原P!=0请证明提示未擅加解答、正交循环子空间/不可约性/全内积确定酉等价链齐。
- 原单个中心eK值不足定特征的既有注独核：kappa与kappa+2pi在参数1值相同、参数1/2不同；固定整条rho(exp(tK))=exp(it/hbar)I才能指定该表示类。未把该注混成原作者定义。
- 源后段给定any xi的循环生成最后结论确须xi非零：xi=0时Hxi=0。作者在原dagger注仅追加最短条件，C持审前actuala9ae44全字节与作者before完全相同，删除唯一新句严格还原。其余数学/源锚/行尾不变，新current20013958...91196f已实际再读。
- 例4.4.2全部三积分和配平方项/cross ihbar ts/基态最终比例因子与投影意义齐。全部root字体恢复current按源Hilbert rsfs/Schwartz plain等区别保留，未以纯fontdelta替代本次全部语义审。

原范围逐页完整实看，未决项0。未改译文，最终全书版面/目录/导航/冷编另验。
