# 量子独立源审 Q-ch04-sec05-sub02

批准当前实际SHA `b968c4a23344e83ab9d8ecaa0661b69c92ef093d22e27a2d6aad3ec963e40cbb`。root译，C非作者逐源审。

- 原230的4.5.2至231的4.5.3前全部实读，A=-Delta/2+omega²x²/2、两阶梯算子/omega(a†a+1/2)、基态归一化/第n态sqrt(n!)/sqrt(2^n n!)及Hermite定义逐式齐。
- 完整性原反证保留：对所有xn的Gaussian加权矩为零、L2内指数幂级数、Gaussian加权Fourier为零、推出phi零。独核部分和由exp(|xi||x|)Gaussian作L2控制，phi乘Gaussian属于L1且Fourier唯一，原论证成立。
- 正交基特征值(n+1/2)omega和离散谱集合全部保留；前文谐振子默认omega>0沿用，无新增习题解答/原无证明未被扩写，原积分省略dx的简记忠实保留。

范围各原页已实际整页审读，无未决项；未改译文，最终全书图形/目录/导航/冷编另验。
