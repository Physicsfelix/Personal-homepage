# 量子独立源审 Q-ch02-sec08-sub05

批准当前实际SHA `fd84f87bc3a8ed256e6e2b3103fb79a8bf8bad6c414661503e020be3279cd1dc`。B译，C非作者逐源审。

- 原156的2.8.5标题至161末全六页实际逐段式读，五原号2.8.15–19齐。HochschildCp=A^(p+1) tensorbasek、b各交替合并/末cyclic项、b²四行结合性抵消、HH定义/HH0、原HKR无证明定理与非交换形式评注全部保留。
- 普通rho映射和rho b=0的Leibniz五行抵消/链映射/拟同构文字完整。C独立核char2的Koszul degree2非零cycle1|x|y−1|y|x被所写rho映2 dx∧dy=0，note001区分抽象HH与未归一化具体map正确，不错误否定多项式HH定理本身。
- 量子EuScriptA=C[x,p]/superscripthbar Weyl代数、Of/Odf、原cyclicm!与rhoh定义无m!及显式Wick指数全保。C独立据Cycvolume1/m!、h0收缩全消证明rhoh0=rho/m!，note002归一化和源161sigma→rho误记均正确，原式未静改。
- dagger总导数m项交替/蓝色未微分插入/邻近两端的Moyal极限、160七行boundary贡献、d(f*g)的两个微分形式表达及组合成rhoh b的六行完整；第二算法theta导数G=−1、两空间导数的±ihbar/内乘Delta全项无省。
- C独立核degree1 b(x|p)=ihbar、rhoh(x|p)=x dp、Delta(x dp)=1，链恒等式正号正确；几何L_(omega^-1)、Delta²0、BV原型、hbar线性延拓、局部化与FeiginFelderShoikhet末段齐。note003相对基环解释独核：pprime=p/hbar后固定Weyl tensorLaurent，绝对HH多参数dhbar方向，不能仍只集中2n。
- 两nativecircle图独立实际源clip3xRGB全同且C逐幅实际看，全部b/Σ±/双向碰并箭头、theta上下标、顶点/省略号无裁漏；所有check原已有步骤全译，未补练习详解或原缺定理证明。

范围各原页已实际整页审读，无未决项；未改译文，最终全书图形/目录/导航/冷编另验。
