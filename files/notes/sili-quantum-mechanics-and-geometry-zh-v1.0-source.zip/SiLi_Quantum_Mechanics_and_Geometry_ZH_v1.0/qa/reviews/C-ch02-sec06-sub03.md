# 量子独立源审 Q-ch02-sec06-sub03

批准当前实际SHA `01063c5314ab7e2a713dc61aeb187ae2089e90b6d942340cd08d36e19d32d3cf`。B译，C非作者逐源审。

- 原116的2.6.3标题至118的2.7前全部实际逐段式读，半经典贡献两公式、启发式措辞、时间切片N和epsilon定义/omega_j²采样/三行有限维Gaussian与总归一化系数全部保留。
- 两完整三对角矩阵逐格核原117：维N-1及j、首末2-epsilon²omega下标、所有-1、两个角0/省略线均齐；sourceepsilon/varepsilon混排原样保留。独核D_j按末行展开给D_(j+1)=(2-epsilon²omega_(j+1)²)D_j-D_(j-1)，u_j=epsilon D_j符合原递推和u0=epsilon。
- 原u1-u0差商=1-epsilon²omega1²及连续初值u(tprime)=0,uprime1/omega²=Vsecond/m、末epsilon detA_N趋u(tdouble)全齐。独核N片Gaussian积分N-1变量恰留sqrt(m/(2pi i hbar epsilon detA_N))；常频闭解epsilon sin(Ntheta)/sin theta→sin(omegaT)/omega，free极限T，和前Jacobi/GY常数2一致。
- 原时间线native图3x实际看，t0=tprime/tN=tdouble、j/j+1、epsilon括号、N-1端点及原红等号均完整；独立原PDF同clip3x重建RGB全同，无裁边、漏标或新增解答。

范围各原页已实际整页审读，无未决项；未改译文，最终全书图形/目录/导航/冷编另验。
