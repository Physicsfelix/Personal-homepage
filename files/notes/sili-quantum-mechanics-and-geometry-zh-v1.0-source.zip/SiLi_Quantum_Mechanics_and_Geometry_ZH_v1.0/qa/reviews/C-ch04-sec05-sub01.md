# 量子独立源审 Q-ch04-sec05-sub01

批准当前实际SHA `103e0536b9ec27fe85089f283b770e204a9d6c5772d79fdbfb84e6dbd4b3991a`。root译，C非作者逐源审。

- 自由Hamilton H0=-Delta、未归一化Fourier正负号、定义域xi²hatphi属于L2、自伴性/本质谱全半轴全部保留；原谱测度记号dvarphi仍按源，未擅改前文mu。
- 预解式二次型的共轭/1除(2pi)^n、极坐标r^(n-1)与lambda=r²变量替换三步独核，谱密度前系数1/[2(2pi)^n]、lambda^(n/2-1)、S^(n-1)角积分齐。一般L2沿球面限制只按极坐标几乎处处解释，无误强成每一lambda。
- 热半群Laplace变换Re z<0给(A-z)^-1，核(4pi t)^(-n/2)及exp(-r²/(4t)+zt)精确保留。独立利用K_nu标准积分换元得1/(2pi)(sqrt(-z)/(2pi r))^(n/2-1) K_(n/2-1)(sqrt(-z)r)，source参数无额外n，当前符合实际源。此处无图或练习。

范围各原页已实际整页审读，无未决项；未改译文，最终全书图形/目录/导航/冷编另验。
