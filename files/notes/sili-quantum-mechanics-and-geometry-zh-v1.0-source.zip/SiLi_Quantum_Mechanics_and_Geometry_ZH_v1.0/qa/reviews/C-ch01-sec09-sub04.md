# 量子独立源审：Q-ch01-sec09-sub04（C）

结论：通过。译者B、审者C分离。实际当前SHA256：`f4f22e6fd181f712a0eedee3d47cab2c19a23415fc7f29c58760dac6adbe333e`。
原PDF SHA256：`aa0d0055bf4f8788a5c14fffd67ba61bb7af7cbab267d85ab950ac3088a97d5e`。

- 原54全部时间反演段式读：本章既有实值标量势语境下，barψ(x,−t)仍解，定态共轭将入射/出射方向对换；每个A/B/C/D上的bar及±ikx准确。
- 原“在这一表示中”barPsi_in/out是时间反演解的新输入输出名称，译文保留其原记法与新列(Bbar,Cbar)/(Abar,Dbar)，没有静默换成旧列的共轭。
- 完整S关系与取逆/取共轭顺序准确：从AbarDbar=S BbarCbar得out=barS^−1in，结合酉性barS^−1=S^t可得S=S^t；原所有三步全保留。

原49–54完整页实际阅读（49为前一相邻批已读，源SHA保持；本批新读50–54）。待修项0，C未改B正文。正式版面、导航和冷编另验。
