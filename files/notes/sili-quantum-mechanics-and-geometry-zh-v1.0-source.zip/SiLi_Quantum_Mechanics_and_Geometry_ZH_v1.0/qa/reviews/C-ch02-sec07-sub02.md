# 量子独立源审 Q-ch02-sec07-sub02

批准当前实际SHA `1be24aed34215bfc7517b9db44cc23fa67921f4b4c8d17f62ea24957e8179e20`。B译，C非作者逐源审。

- 原122中2.7.2至132的2.7.3前全部11原页实际逐段式读，三原号2.7.4–6与所有三个case齐；G的双重形式积分、两鞍条件、HamiltonJacobi能量条件及两次Gaussian因子全保，原启发式论证未静默改成严谨定理。
- J初值/ODE、v同方程、Wronskian W=v(0)、J/v积分到dT/dE及VanVleck比值−1/(v0vT)，再Wcl=ET+S=∫p dx整链逐步核；原p=正平方根在单调分支理解，note001明确速度非零/内部非退化及转向或端点另处理正确。
- 自由粒子轨道/T_s绝对位移、G=m/(iℏ²k)相位系数正确；线性势V=−λx轨道和作用量S=mΔ²/(2T)+λTsum/2−λ²T³/(24m)、四鞍根/鞍作用量/初末速度乘积全四行逐项核。
- 三情形0<xprime<xdouble、xprime<0<xdouble、xprime<xdouble<0的四±±鞍位置与选入鞍点/两个thimble或一个thimble的说明完整；反复的原导数因式分解以及各iSsecond实/复符号四条列表无漏。
- 原127 whole iSprime 的共轭和barT²两处逐图实核保留；负复共轭梯度使dRe(iS)/du=−|Sprime|²、Im(iS)常数，方向正确。note002原130时间分母把速度写动量的缺m确原页可见，注给sqrt(2(E−V)/m)或分子m正确。
- 11当前原生图全部3x实际看；C独立原PDF同clip重建比较尺寸/RGB，四个T-plane仅已核原英文bbox变中文，排除词框外全0差，另七图全像素同。全部xprime/xdouble、T_s±±、实/虚轴、四蓝切线、红围道与箭头完整，无邻文侵入和裁字。

范围各原页已实际整页审读，无未决项；未改译文，最终全书图形/目录/导航/冷编另验。
