# 量子独立源审 Q-ch02-sec04-sub02

批准当前实际SHA `95373d748d6456c255c8fe74954f3d3355a4729a2b4f21df41bb1934dbdc283f`。B译，C非作者审。

- 实看原96的2.4.2全部，配分函数Tr exp(-betaH)、本征能谱几何级数与虚时间T=-itau/欧氏核/迹积分三步原式齐。
- 独核E_n=(n+1/2)hbar omega的几何级数为1/(2sinh(beta hbar omega/2))；对角Euclidean核的Gaussian指数系数为2momega sinh²(betaomega hbar/2)/(hbar sinh(betaomega hbar))，积分平方根约掉相同结果。所有m/omega/pi/hbar/2常数及两条途径/末原评语均齐。

原范围逐页完整实看，未决项0。未改译文，最终全书版面/目录/导航/冷编另验。
