# 量子独立源审 Q-ch02-sec01-sub01（C）

通过，B译C审。实际current SHA `42f549f2e6a4dc623efa6b2dfbbbfe31dd3ad8afbcd91ca368ac9151846396a2`；源SHA `aa0d0055bf4f8788a5c14fffd67ba61bb7af7cbab267d85ab950ac3088a97d5e`。

- 物81–83至2.1.2前全段式：Schrodinger方程/Hhat自伴且与时间无关、两时间指数/核作用式、经典S与L/EulerLagrange/Legendre和p_i下标均核全。
- 原pathintegral的两端点上下标/Dmeasure/振荡相位、所有路径与经典驻相说明/跨82–83 BrownMarkov/Wiener段及严谨测度暂缺/形式性质计算/DiracFeynman叙述完整，无源步骤删略。
- 独核最短Wiener注：实时间权重exp(iS/h)一般为复数（S=pi h取−1），不为概率密度，虚时间热核与Wiener联系适当。原全部论述留，未加入源无的测度构造证明。
- 唯一原路径图当前3x全看、原生crop3x扣新旧caption并集独立比较，红经典/四蓝其它路径/两x端点及中文颜色完整。

物81–85全五页实际阅读，全部原段/式/图保留，无未决项。正式版面/导航/冷编另验。
