# B Quantum第6章所派范围作者完稿

已完整写齐导语与6.1–3共15单位，原物298–322到6.4标题前。所有对应25原页实际逐幅2x读，38原编号对象与全部证明/原练习提示/4原生图组俱齐，源锚579条。15实际SHA全重算匹配，待非作者A逐单元独审，不自签。6.4五叶已转root作者，无B草稿。

末叶SHA `3eb79fbf82ab960a9aef53d5cd20475606aa4c9874406327851e8c245a9942c9`；完整源范围/current identities见JSON与translation-B-ch06。最终合编PDF/导航/冷编另验。


2026-10-26 当前定位别名差分：`ch06-intro.tex` 仅新增 `\label{chap:6}`，current SHA `c70996a1f75e67bafdac46f3cb8e9b65f2fbd7727f7c77a6b0ea959e087b0212`；原 `d05c…bbe2` 是该别名添加前历史。完整 before/exactdiff 在 `qa/translation-B-revisions/ch06-intro-before-root-label-alias`。全部作者段式不变，交 A 独立审。
