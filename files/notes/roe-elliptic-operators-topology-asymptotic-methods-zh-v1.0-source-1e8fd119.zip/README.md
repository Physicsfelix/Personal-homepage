# 椭圆算子、拓扑与渐近方法：中文翻译重排版源码

原著 John Roe，第二版（1998），CRC 2001重印。对应用户提供的200页原DJVU；原件身份见 qa/source-identity.json。收录题名、版权、献词、原目录与引言、十五章、全部证明及习题、注释、参考文献与索引。正文沿用所提供《泛函分析I》v0.2样张的视觉复原样式。

## 编译

使用带完整中文宏包的 TeX Live、XeLaTeX 和 latexmk；本次实测 TeX Live 2026。中文字体 Fandol 与西文字体 Latin Modern 随 TeX Live 提供。所有源码均为 UTF-8。

```text
latexmk -norc -xelatex -interaction=nonstopmode -halt-on-error -file-line-error -outdir=build main.tex
```

Windows 可从任意目录运行本包 build.ps1，输出 build/main.pdf。目录和索引页码需要多轮编译，由 latexmk 自动运行至稳定。

## 回查

main.tex 为正式入口；chapters、matter、backmatter 分别包含正文、前置及后置材料；figures 包含难辨原数学公式的精确局部图像；style 与宏文件都是正式编译输入。原编号、原书记号差异和可确认原误植保留原样，另列“译校注”，不加原书没有的习题答案。

SourcePageStart/End 对应原件物理页；qa/source-page-map.json 与 CSV 给出本PDF页面及显示页码的对应。qa/compile-inputs.json 固定全部实际编译输入。原页末脚注的结束锚位于其注体，可能低于同一译页的下一原页正文开始锚。

全原范围逐单元经过非作者独立审校；当前输入身份见 qa/current-accepted-inputs.json，排版、导航、源页和冷重建证据见 qa/ 中相应记录。详细报告保留修订经过，当前文件身份以该清单为准；QA中的本机绝对路径已规范为可携带引用，原件、译稿和审校哈希保持原值。编译不需要整书原扫描、OCR、作者工作目录或旧辅助文件。
