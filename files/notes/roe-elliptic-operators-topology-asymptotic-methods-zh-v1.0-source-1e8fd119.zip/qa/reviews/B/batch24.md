# Roe batch24 r2 非作者审校 B

状态：**approved**。物81–82完整习题，83章6只作边界。全源图及当前完整1译页实际看，五题5.33–37、5.34全部五小项、两原显示组及全部提示/括注齐，不增解答。

## 5.33/5.34 all5subitems/all2displays

Original81/82andcurrentcandidatecompared: criticalWn/2torus/log(1-logr)hint;phi normalized/radial/compactpositive/scaledepsilon^-n; YounguniformL2bound,compactcontinuousuniformconvergence,thenL2convergence;commutatorbothintegrals/derivativea(y)/differencea(x)-a(y)/epsilon^(n+1)/allplus signs;finalcompactmanifoldchart/partitionconstruction. Hintisconsistentinn2becausegradientloglog has squaredradialintegral dr/(r(1-logr)^2)finite butfunctionunbounded. Alloriginalrequestsretained;noansweradded.

## New5.34(iv) conditionnote independentlyderived

Actualiv onRn hasnoexplicitcoefficientbound,while(v)compactchartlocalizationisintended. Ifgradienta bounded, firstkernelL1bound<=||partial1a||infty||phi||1;secondLipschitzdifference givesL int|z||partial1phi(z)|dz independentlyepsilon. Smoothcutoffoflocalcoefficientsensuresboundedgradientonfinitecompactcharts. Arbitraryglobal smoothainsufficient: n1,a=x²,T_Rf(x)=f(x-R),C=[x²partial,F]. Translation givesC T_R=T_R(C+2R E),E=[xpartial,F]; multiplierE=-epsilon xi phihatprime(epsilon xi) isnotidenticallyzero since normalizedcompactmollifierFouriertransformnonconstant. ChooseSchwartzfwithFouriersupportwhereE nonzero; ||C T_Rf||>=2|R|||Ef||-||Cf|| divergeswith||T_Rf||fixed. Thisshowstheunrestrictedglobalreadingfails, withoutrefutinglocalconstruction. Addednoteonlystatesconditions/noprooforanswer.

## 5.35 oldweightnote/5.36/5.37

KernelL2normcontrolledbyL2->C0operatornorm throughfiberevaluationHSboundandsummation/integrationovercompactM. ProjectionkernelWkpolynomialboundwithsomeell>k+n/2isconsistentwithproductellipticityandbaseSobolevembedding. Zeromodecircleconstantprojectionnonzero whilelambda^ell0,negativepowersalsoneedabsolutevalueasappropriate: oldnoteuniform(1+|lambda|)^ellcorrectandunchanged. HeatFriedrichsfamilyrequest5.36retained,nopreprintedproofinvented. 5.37fullFredholmalternativegivencomplexlambda/nonzerosolutionORforallvuniqueu/bothCinfty retained;discreteselfadjointspectralgapgivesconsistentstatement. Allfivequestions/twooriginaldisplays/fivesubitemsallcomplete.

## 差分与身份

初稿B反馈仅涉及5.34(iv)全空间系数条件。作者只在完整题后新增分离注；删除这条注逐字恢复r1，原题、两积分、旧5.35注及所有其他内容不变。当前 SHA256 `d0d4f3cdd659e537f6009ee08935e82fa512438ccd72cffda7d7e009f5424df5`；实际批准快照 `[project]\qa\approved-bytes\B\d0d4f3cdd659e537f6009ee08935e82fa512438ccd72cffda7d7e009f5424df5\book\chapters\ch05-exercises.tex`。独立两编0，1页几何/文字/1.5倍像素与当前PDF相同，12字体嵌，无诊断。旧B30快照冻结。

Start81在前函数演算，End81在5.34(i)跨句；Start82绑定首L2对象，End82在原最后括注末，全页所有对象完成后。非全章验收。
