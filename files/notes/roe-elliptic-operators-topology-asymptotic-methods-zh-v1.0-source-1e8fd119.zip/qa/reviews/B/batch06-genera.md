roe-ch02-genera：approved

当前SHA `42851291cac708e6f817569a27b319bc1cfd63e6a883de37ca5906d89f5f1a95`，真实批准字节：[project]\qa\approved-bytes\B\42851291cac708e6f817569a27b319bc1cfd63e6a883de37ca5906d89f5f1a95\book\chapters\ch02-unit03.tex

完整逐页/数学/视觉证据见batch06.json/md；本单元单独通过。
