roe-ch02-exercises：approved

当前SHA `93b5400526a5330d6628f9e69f39df9c1757ed65d522c6e01da008a894a03811`，真实批准字节：[project]\qa\approved-bytes\B\93b5400526a5330d6628f9e69f39df9c1757ed65d522c6e01da008a894a03811\book\chapters\ch02-exercises.tex

完整逐页/数学/视觉证据见batch06.json/md；本单元单独通过。
