# Roe batch25 非作者审校 B

状态：**approved**。章6完整 opening 与无原题头完整主论述分别批准。物83–87逐页实际看，另回看物17/18的实形式 Hodge 星定义及49的3.27；全4译页实际看。6环境、2编号普通段、式6.6、13显示组、九箭头图、4完整原证明及全部段落核齐。

## Opening/6.1/fullunnumbered narrative

Source83chaptertitle/openingseparatefromuntitledmain, noaddedsubsectionheading. Allcompact/oriented/Hermitian/connectionconditions anddj+1dj0 retained;D=d+d* precise. Weierstrassnormminimizerheuristicmarkednonrigorous as source;existence notassumedasproof. deRhamcomplex/coefficientsC/ref24and15 andDolbeaultparagraphallretained.

## Dolbeault normalizationnote independentlycheckedwithsource49

Freshnative49Proposition3.27 explicitlyDcl=sqrt2(barpartial+barpartial*)onKahler andsameprincipalpart up tozeroorderonHermitiancomplexmanifold. ThusDprimewithoutfactorhassecond-orderprincipalpart halfthatofDcl² atsamefixedmetric. d=sqrt2barpartial hasunchangedkernel/imageandharmonics, soHodgecohomologyconclusionunchanged. Candidatepreservesraworiginaloperatorandonlyseparatesnormalizationconditions;nofalseclaimtheoremHodgefails.

## 6.2 wholeproof/allnine arrows

d²=(d*)²0 implyD²=dd*+d*d,degreepreserving. Harmonicssatisfybothdalpha0andd*alpha0byenergyidentity. SourceP/iota/f/gcasefunctionsallretained. Compactselfadjointspectrumhaszeroisolatedwithfinitemultiplicity, sog(lambda)=lambda^-2off0 isbounded. G isfunctionofD², notclaimarbitraryfunctionDcommutesd;sinceD²d=dD² eachD²eigenspaceinvariant, henceGd=dG onsmooths. ThenD²G=I-iotaP andH=d*G givesdH+Hd=I-iotaP,P iota=I. Thisproveschain-equivalence/surjectivityanduniqueness, notonlyexistence. Threeverticalinclusions,threetoparrows(two0labelsandcontinuation) andthreebottomarrows(dj-1,dj,continuation) exactlysource.

## 6.3/6.4 Poincare duality/capterminology

Finiteharmonicspacesgivefinitecohomology. Source6.4 explicitlyconnected, soreal/complex topcohomology identifiedbyintegrationwithfield. Twoinputscohomologydegreesadd; originalcapwordandcapglyphretained, separateusualcup-name/typeclarificationcorrect. NoHodgeorpairedproductcounterexampleasserted.

## Hodge star convention independentlyrereadsource17/18, not imported

Original1.20/1.21 actual17/18 definesmetric/staronrealRiemanniantensors, bilinearformulaandreal-linearity;itdoesnotprescribeacomplex-extensionconvention. Thus complex6.4proofcanbereadwithHermitianconjugate-linearstar, whereintegralalpha wedge staralpha=||alpha||² andstarintertwinesLaplacian, orprovepositivedualityoverrealsfirstthencomplexify. Ifchoosingcomplex-linearstarinstead, alpha=dx+i dy onflatT2hasalpha wedge staralpha0,andappropriatepositive-testformisstar(baralpha); thisconditionaltestisnotaproofthatsourceintendedwrongconvention. Candidatekeepsraw*alpha andfirst-slot-linearRieszpairing, no silentbarorcross-bookconventionchange.

## 6.5/6.6 complete Riesz/Poincare dual argument

ForclosedorientedC,Stokes makesclosedformintegrationcohomological. P finite-ranksmoothingmakesalpha->integral_C Palpha L2continuous. Withfirst-slot-linearHilbertpairing,RieszbetaandselfadjointPgive<alpha,beta>=<Palpha,beta>=<alpha,Pbeta>, sobetaP-fixedandharmonic. ForrealC, thisRieszrepresentativerealonrealforms;starbeta givescohomologicaldual. Equation6.6readforclosedcohomologyrepresentatives, notallL2forms; sourceexplicitlowerdimensionalintegrationwarningretained. Metricindependencebynondegeneratepairingcharacterization. Complementarydimensionexchangehas(-1)^(k(n-k)),negativeiffbothdimensionsodd;closed/generalposition/intersection/Thom/ref15/wholeparenthesis/exercise6.13retained.

## 6.7/6.8 wholeproof and6.9 shortproof

ContractedmathsfKdistinguishedfromcurvature2formitalicKthroughout. MetricparallelisomorphismTM->T*M intertwinescurvature, noartificialdualminussign. Cliffordtripleproduct e_i e_j e_l haslinearpart -deltaij e_l+deltail e_j-deltajl e_i;cycliccurvatureidentitykillscubicpart andremaining contractionmatchesinput-index-firstRic_ka. ThereforemathsfK on1formsequalsRic,includingonehalfandallindices. PositiveRicandharmonic1formgive0=||nablaalpha||²+<Ricalpha,alpha>,forcingalpha0;HodgeidentifiesH1soBetti1nonzeroimpossible. Sourceone-sentenceproof6.9exactlypreserved, nofullnewproofadded.

## 字节与预览

独立两遍0，4页文字、几何、1.5倍像素与作者PDF相同；19字体嵌，无缺字溢出未定义。旧B28批准实际快照冻结，作者核心输入一致。Start83严格在OriginalChapter清页后并与真正章页同页；83–86的End和84–87的Start各一次，End87留后Notes，无88标记。

- `chapters/ch06-intro.tex` SHA256 `4d57a6b6dc76ac31b30c281201f9d11a624dd2fba82952dbb471ed1ad964e711`；真实快照 `[project]\qa\approved-bytes\B\4d57a6b6dc76ac31b30c281201f9d11a624dd2fba82952dbb471ed1ad964e711\book\chapters\ch06-intro.tex`。
- `chapters/ch06-unit01.tex` SHA256 `0773a477d237be4e992c766a1044f50ff26aed59a2bb7dcbe7899cd0f9c52000`；真实快照 `[project]\qa\approved-bytes\B\0773a477d237be4e992c766a1044f50ff26aed59a2bb7dcbe7899cd0f9c52000\book\chapters\ch06-unit01.tex`。

本报告不替代章链或全书验收。
