# Roe batch27 非作者审校 B

状态：**approved**。完整原单元、全部原图与当前译页实际核，原生新解码与阅读PDF像素逐位相等。

## 6.10 all4items andhint

CompactCONNECTEDLiegroup,KillingTr(ad u1 ad u2),negative-definitesemisimplecondition,unique bi-invariantmetric-B, leftinvariantfieldnabla_u u0 andhalfbracket, originalR(u,v)w=-1/4[[u,v],w],positiveRic/Betti1requestandoneparametersubgroupsgeodesichintallpreserved. CurvatureconsistentwithconnectionhalfbracketviaJacobi, notsilentlychangedtowrongpositivequarter.

## 6.11 note/complete tworequests

Original6.9assumescompactoriented,no globalconnectedconvention. ConnectedcaseBochnerenergywithRic>=0 forcesharmonic1formparallel;positive-definiteatonepointforceszerothereandhencewholeconnectedcomponent. OnS² disjointunionflatT²,allcomponentsdimension2compactoriented,Ric>=0everywhereandpositiveonS², buttorusparallelformsdx/dyextendbyzeroandgiveC²inH1. Thusonepositivepointontotaldisconnectedmanifoldinsufficient, requirepositivepointineachcomponent. Notequalifiescontextwithoutdenyingintendedconnectedresult. Positiveatjustonepointmeansatleastone,notexactisolatedpositivepoint. OriginalzeroRicquestionretained, noansweradded.

## 6.12 all3items andthreeLaplacians

CompactRiemannsurfaceandmetricconformalcompatibility;holomorphicplusantiholomorphic1formsrequest;generalcompactKahlercase; allthreefullsquaredoperatorsD/partial/barpartialand equalityDelta_barpartial=Delta_partial=halfDelta_Dwith[36,p115];complexconjugationswapp/qandoddBettiinparityretained. Halfnormalizationagreeswithalreadychecked3.27D=sqrt2barpartialDirac. NoextraKahleridentitiesproofinserted.

## 6.13 all5items andhints

Closedorientedk-submanifold/reference6.5, rapidg onR+withg0=1, completefirst-slot-linearRieszdefinition; smoothing/closedness/independentcohomology/forallgdual; GIVENarbitraryUthereEXISTSappropriategwithsupportU andfinite-propagationhint; ivcontinueswiththatlocalizedchoicegandU tubular normalbundle, notgenericg. Consistentorientations/fiberintegral1/localproductmetrichint retained. Complementarydimensionsandtransverseintersection/productPCwedgePCprime/geometricintersectionlastrequestretained. Noformulasbar-swapped,noobstructioninventedfromarbitrarynonlocalizedg,andnosolutionsadded. Total12subitems4+3+5and4displayscorrect.

## 身份及验证

当前 `chapters/ch06-exercises.tex` SHA256 `3b565f9bf0450b147d876f55bef091091d9c5ec1654efc2c8c77bdc914d26b49`；真实快照 `[project]\qa\approved-bytes\B\3b565f9bf0450b147d876f55bef091091d9c5ec1654efc2c8c77bdc914d26b49\book\chapters\ch06-exercises.tex`。独立两遍编译0，全部译页文字/几何/1.5倍像素与作者PDF相同，无诊断，字体全嵌。旧B31实际快照及核心身份冻结。

Start88在6.10首词，End88在6.12(ii)引出三Laplace式处；Start89在同一显示首式，End89在6.13(v)原最后句，无90锚。 本记录不是全章或全书验收。
