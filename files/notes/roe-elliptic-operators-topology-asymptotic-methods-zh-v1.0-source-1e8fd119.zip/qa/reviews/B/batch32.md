# Roe batch32：独立审校通过

作者 C；审者 B。源物理页 [103]，首对象 Exercises heading on103 before7.25，末对象 Full7.26 finalTaylor[71,ChapterXIII] reference on103 beforeChapter8。原件 SHA 1dd11f0e10a8c16b096154162d7028992132dd5814322bb0bacd0b0a3dbf5d9c。

逐段回核原生页图、当前完整译页及当前字节，全部正文、原题、提示、引用和源锚保留。未修改作者稿。当前 SHA `5cdb2924246ee6d5ed17762a94bf9a3ec1a8377bc52ac7a9e6cd19c04dfde5d7`；实际批准快照 `[project]\qa\approved-bytes\B\5cdb2924246ee6d5ed17762a94bf9a3ec1a8377bc52ac7a9e6cd19c04dfde5d7\book\chapters\ch07-exercises.tex`。

7.25 whole request and Poisson hint: Flat torus heat kernel is the lattice image sum of Euclidean Gaussians. For locally matching lifts with distance below half the shortest nonzero lattice length, all nonzero images have a uniform positive separation; Gaussian tails, including finite derivative/polynomial factors, are exponentially small as time tends0. The source comparison is understood locally, not with arbitrarily mismatched fundamental-domain representatives. Complete request/hint retained; no answer inserted.

7.26 whole S0 estimate, pseudolocality and Fourier hint: All k symbol estimates, every L2 section, smoothness off support, hint7.20 and Taylor71 ChapterXIII retained. B independently checked distributional Fourier issue: fhat need not be a Schwartz function; away0 repeated integration by parts using integrable derivatives and weighted derivatives makes it smooth with rapidly decreasing tails. Cut off near Fourier0. The tail inverse is Schwartz and has smooth functional-calculus kernel. The compact-distribution Fourier part pairs with wave matrix coefficients against smooth separated test sections; these vanish near0 by finite propagation, so the compact part vanishes there. This establishes the stated pseudolocal conclusion without falsely applying the Schwartz-only formula directly to arbitrary S0 functions. QA reasoning only, no exercise solution added.

两遍独立编译退出码均0；单页几何、文字及1.5倍像素与已实际查看作者PDF相同；全部11字体嵌入。诊断：[]。 既有38份批准输入和实际快照均冻结。此记录只批准本单元，不代替全书验收。
