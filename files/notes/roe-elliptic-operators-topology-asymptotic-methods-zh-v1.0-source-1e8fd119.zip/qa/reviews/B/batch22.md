# Roe batch22 非作者审校 B

状态：**approved**。作者 C；审者 B。实际原生解码图与阅读PDF嵌入像素逐位相等，已完整实际看所涉原页及当前1译页。

## 5.29/complete original shortproof andnote

Fullsource79/80read. SourceboundCk lambda^k ||s|| isfalseatlambda0fornonzeroconstantcircleeigenfunction, andnegativeoddpowerscannotupperboundpositivenorm. EllipticestimateiteratedonD-eigenvector gives ||s_lambda||k<=Ck(1+|lambda|)^k||s_lambda||0, and ||s_lambda||0<=||s||0. Originalunqualifiedlambda retained, separateasymptoticweightnotecorrect; doesnotdenyrapid-decaycharacterization.

## 5.29 iff, polynomialcount andsummability

Smooths: lambda^j P_lambda s=P_lambda D^j s givesrapidblockdecayforlargeabsolutevalue. Converse requiresmorethandiscreteness. Oncompactn-manifold, finitecharts/quadraticpartitionandFouriercutoffT_N giverankO(N^n) and ||s-T_Ns||0<=C N^-1||s||1. On E_L=sum_{|lambda|<=L}ker(D-lambda), Garding givesW1<=C(1+L)L2. PickN>2C(1+L) soT_N injectiveonE_L, whencedimE_L=O((1+L)^n). Dyadicshells make sum(1+|lambda|)^-q finiteforq>n. Arbitrarilyrapidblockdecaythen givesabsoluteconvergenceinallSobolevordersandhencesmoothness. ThisindependentjustificationisQAonly; originalshortproofnotexpandedintranslation.

## 5.30 allfiveclaims

Spectralorthogonalblocks implyboundedunitalmultiplicativediagonalmapandnorm<=sup. Operatorcommutationreadwithusualdomain-preservingmeaning, soeachD-eigenspaceinvariantandblockscalarfDcommutes. Boundedf preservesrapidblockdecay. If f=lambda g and f,g bounded, sumlambda²|g(lambda)|²||s_lambda||²<=||f||infty²||s||², so g(D)s inDomD andDg(D)=f(D) everywhere asboundedoperator. Noarbitraryunbounded-domainclaimadded.

## 5.31 complete kernel argument/5.32

Finite-rankorthogonalprojectionkernel sum_j e_j(p)e_j(q)* issmooth. EvaluationofK:L2->C0 into rankr fiberhasHSnorm<=sqrt(r)operatornorm, hence ||kernelK||L2<=sqrt(r volM)||K||L2->C0. Sobolevembeddingonbasewithm>n/2andGarding give ||P_lambda||L2->C0<=C(1+|lambda|)^m; productmanifoldellipticestimate onkernel (D_p²+D_q² eigenvalue2lambda²) yieldsWk kernel boundC(1+|lambda|)^(k+m), compatiblewithsourceell>k+n/2. PolynomialcountandrapidfensureabsolutekernelseriesinallWk, thenallCk. EverykernelFrechetseminormcontrolledbyahigherweightedfseminorm; continuityvalid. FiniteNdependingonlyondimension sufficesforC0kernel;constantsmaydependongeometry/operator. Negative/zeroweightqualificationalreadyinseparatenote.

## 身份与版面

当前文件 `chapters/ch05-unit03.tex` SHA256 `bae9bc1b8268b16452bee64bea86135dddb7d736a5f3a42227ef8b1a49569a86`，真实批准字节 `[project]\qa\approved-bytes\B\bae9bc1b8268b16452bee64bea86135dddb7d736a5f3a42227ef8b1a49569a86\book\chapters\ch05-unit03.tex`。旧A4/B26语义批准字节及本批核心输入身份均核相同。独立两遍编译0，当前1页文字、几何、1.5倍像素与作者PDF相同，无缺字溢出或未定义，字体全嵌入。

Start79在上节，End79在5.29陈述末；Start80绑定原证明首词，End80在5.31末；Start81在5.32首句，End81留后习题。 本报告不作章或全书验收。
