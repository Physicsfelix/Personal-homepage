# C75 collector 技术差分独立批准

状态 TECHNICAL_INPUT_ONLY approved。只批准当前独占辅助宏的hbox/numberline双格式识别与既有目录行导航。原89行不变，差分精确反向恢复旧全字节/EOL；两个真实序列化种子各89项实际TeX捕获通过。真实main目录89页标/178链接只做当前局部独立验证；未重做整书编译、全页视觉或源码包。
