# Roe batch30 非作者 B 独审

状态：**approved**。完整有限传播单位物99–102至7.24全证明末、Notes前；四原页/三译页全部实际看。三命题、两编号式、11无号显示、两完整证明、能量断言及全部普通论证齐。

## 7.20 completeenergyclaim/Radaptive/groupduality

Shrinkingballenergyderivative=bulkcurrentminusboundarymassas7.21. First-slot-linearRoe pairingandwave dt s=iDs give densityderivativei divJ forJ(X)=<c(X)s,s>. Outwardnormalfluxis+iJ(Nout);source -iJ(N) consistentwithINWARDnormal, sourceonlysaysunitnormalunoriented. Absolutevalueboundindependentofthischoicebecausec(N)*c(N)=I, givingnonincreasingenergy. No silentrawsignrepairorfalsecounterfromunfixednormal. Forpointwithd(m,supps)>tandtsmall,chooseR ADAPTIVELY t<R<min(d,uniformnormalradius);energyinitial0andshrinkingballcontainsm, soamplitudethere0. NotonefixedRwhichonlyprovesR-neighborhood. Groupcompositionextendspositivealltimes;unitaryadjointdualityextendsnegative. Fullsourceproof retained.

## Fourier/7.22/7.23 wholeweakargument

hatf=intf(x)e^-ixlambda, inverse(1/2pi)inthatf e^+ixlambda. WithFIRST-slot-linearL2pairing, weakintegralhasUNCONJUGATEDhatf outsidepairing. Spectralformulaonfiniteeigenvectorcombinationsandunitarynorm1/hatfL1boundextendtoallL2x/y;normBochnercontinuityofunbounded-Dunitaryfamilynotasserted. Compacthatfsupport[-c,c]andwaveunitspeedkillpairingsforseparation>c;localizedsmoothfiber-valuedtestsprovekernelvanishesoffcorrespondingdiagonalneighborhood. Originalweakmeaning/allordinaryproofparagraphsandnoformal7.23proofinvented.

## 7.24 wholeproof/scalingSourceError

Forf_u(x)=f(ux), substitutey=uxandreverseboundsfornegativeu:hatf_u(lambda)=|u|^-1hatf(lambda/u), source1/uvalidu>0only. Originalt->0parameterletterretainedandnoted. Splitbypsiequal1near0,0outside2delta;firstkernelcompactpropagationinsidegivendiagonalneighborhood. Forweightedderivativeorderk/weightN ofhatf2, outside|lambda|>=delta,arbitrarySchwartzdecayLdominatesallscale factors |u|^-k-1; choosingL>N givesboundC|u|^(L-k-1). Derivativesofpsioncompactannulusaway0obeysamearbitrarydecay. Thushatf2->0inSfrombothsides;Fourierhomeomorphismandapproved5.31continuouskernelmap giveCinfkerneldecayoutsideneighborhood. Nonzerouscalingonly,notclaimingf(0)Iissmoothing. Allrawformulasandproofretained.

## 身份与预览

当前 `chapters/ch07-unit03.tex` SHA256 `f91b561b2afdbb56191fe5f732dfe29738f19464f347fcec420b745ead9e1b0e`；真实快照 `[project]\qa\approved-bytes\B\f91b561b2afdbb56191fe5f732dfe29738f19464f347fcec420b745ead9e1b0e\book\chapters\ch07-unit03.tex`。独立两遍0，三页文字/几何/1.5倍像素与作者PDF相同；15字体嵌，无诊断。旧B37实际批准输入（含C29辅助）及core冻结。共享99首锚在前批，本批End99；Start102在7.24首词，End102留后Notes。当前第2页首完整证明收句及方框可读，未改正文为追求版式。非整章验收。
