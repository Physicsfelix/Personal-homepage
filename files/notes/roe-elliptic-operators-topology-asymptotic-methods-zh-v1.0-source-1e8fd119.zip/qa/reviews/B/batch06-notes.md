roe-ch02-notes：approved

当前SHA `b515e8cf260b9c7350f27fb739fb6a5bd6dfc98d16697de9aa373a0f8bc07f3c`，真实批准字节：[project]\qa\approved-bytes\B\b515e8cf260b9c7350f27fb739fb6a5bd6dfc98d16697de9aa373a0f8bc07f3c\book\chapters\ch02-notes.tex

完整逐页/数学/视觉证据见batch06.json/md；本单元单独通过。
