# Roe batch29 非作者 B 独审

状态：**approved**。完整热核渐近单位物94–99至7.19末、有限传播题头前；原6页及当前5译页全实际看。6对象、2编号式、20无号显示、3完整原证明、7子项、原脚注1及整个7.18计算齐。正文与局部辅助宏分别批准。

## 7.12 fullGaussian derivativeproof

Gausslemma innormalcoordinatesmakesgrad r=partial_r andbothmetricandinversefixradialvector, so theprintedr²=sumg^ij xi xj isconsistenthere, notagenericcoordinateformula. PositiveDelta=-divgrad. dh=-h r dr/(2t), div(rpartialr)=n+r g_r/(2g), soDelta h=(n/(2t)-r²/(4t²)+r g_r/(4gt))h. Addingh_t=(-n/(2t)+r²/(4t²))h gives7.12b. Allr/g/tcoefficients,negativeadjointdivergenceandfourdisplaysmatchsource.

## 7.13 wholecommutatorproof/7.16sign

Atarbitrarypointchoose synchronousorthonormalframe, D(fs)=fDs+c(gradf)s. SymmetricHessiancontractseiejto -traceHessf=Deltaf;crossderivativepairscanceloffdiagonalbyCliffordanticommutationanddiagonal e_i²=-1 gives -2nabla_gradf. Thereforeh^-1(dt+D²)(hs)=dt s+D²s+(r g_r/(4gt))s+(1/t)nabla_(rpartialr)s exactly7.16. NooppositeLaplacesignintroduced.

## 7.14 wholedefinition/Maclaurin interpretation

Allforalln/existsell_n/foralllargerell/existsC_ell,n/smallt quantifiersexact. TaylortoanyfiniteordergivesBanachnormasymptoticexpansion. Here aconvergentexpansionforf isunderstoodasconvergencetoTHEFUNCTIONfnear0,whichisequivalenttoanalyticity;mereconvergenceoftheformalnumericalpowerseriestosomeotherfunctionwouldnotimplyfanalytic (e.g.flatfunction). Thiscontextinterpretationpreventsafalseextraerratum;originalwordingkept,notstrengthenedintoanunqualifiedTaylor-seriesnecessityclaim.

## 7.15 transport/all3items/source-note

Original97mixedindexsum_j t^iTheta_i clearlyread,where98sum_j t^jTheta_j consistent; bodykeepsrawi/jandseparatenoteappropriate. Since7.16isdt+D²,thelaterdt-LnotationmusthaveL=-D²,notchangingheatflow. Coefficientcomparisonwithu_-1=0asexplicitj0piecewiselinegivesnabla_rad uj+(j+radlogg/4)uj=-D²u_(j-1). Integratingfactor r^j g^1/4correct. Radialparallelidentification givesu0=g^-1/4paralleltransport; forj>=1 substitute radialparameteru in[0,1] intointegralj-condition toshowjointsmoothextensionatq,notonlyseparateraywiseexistence. Homogeneousr^-jtermcannotbesmoothunlesszero. Taylorjetcoefficientrecursiondividesbypositiveintegersj+degree;henceeachdiagonalcoefficientisfinitealgebraicexpressioninmetric/connectionjets,Theta0diagI. Fullsourceproofkept, no replacementintegralformulaadded.

## 7.15 cutoff/cut-locus/largeJ/globalCr

Independentlychecked thelocalconstructioncanbeglobalized:compactMhasuniformsmallnormalneighborhoodofdiagonal;choose smoothchi(r²)=1near0,supportedinsideinjectivityradius,andextendchi uj byzero. ThusglobalTheta smooth;hTheta avoidsnonsmoothcut-locus. Commutatorcutofferrorssupportedannulus r>=c>0areO(t^N)withanyfixedspace/timederivativeasGaussiansabsorbfiniteinversepowers. Near diagonalspatialderivativeordermcostsatmostt^-m(crude); t^J h->0CmforJ>m+n/2 asprinted. ToobtainORDerm residualt^m rt withrt continuousCm, chooseJsufficientlylarger, e.g.J>2m+n/2; sourceonlyclaimsexistenceforsufficientlylargeJanddoesnotassertitsfirstthresholdisthenecessaryandsufficientapproximationthreshold. GaussianmassandTheta0diagI giveuniformdelta property. Withprior7.11thisyieldsallCr expansions;extra Jabsorbsfinite derivatives/time-differentiationloss. TheseareindependentQAexplanations,notnewbookproofsteps.

## 7.18 entirecurvaturecalculation/7.19

u0=g^-1/4readinradialparalleltrivialization, notasconstantglobalidentityinanyframe. Radialconnectiongaugex^iAi=0 impliesAi(0)=0and sum_i partial_i Ai(0)=0;hence connection-Laplaciandivergencetermonconstantidentityvanishesat0. Thusu1(0)=-D²u0(0)=sum_i partial_i² g^-1/4 -mathsfK. Frozenapproved1.32hasg_ij=deltaij+(1/3)sumxp xq R_ipqj; determinanttrace givesg=1+(1/3)sum_i,p,qxp xq R_ipqi. Binomialcoefficient-1/4 gives-1/12;two derivativescontractto -(1/6)sum_i,p R_ippi=+kappa/6 byantisymmetryandapproved1.13kappa=sumR_ipip. ThereforeTheta1=kappa/6-mathsfK, alloriginalsums/signs/two coefficients preserved. ContractedmathsfKnotordinarycurvature2formitalicK.

## Newauxiliarymacros-C29/Arabicfootnote

OnlynewprefixedRoeArabicBoxFootnotes environment,begingroup/endgroupwithlocalthempfootnoteArabicrenewal;nooldmacrooverridesoutsidegroup. Unitexplicitinputonce,usesenvironmentoncearound7.15. ActualPDForiginalcallandbodyArabic1samepage3, notdefaultlettera;all3statementitemscomplete. Thisauxiliarybyteidentityisapprovedseparatelyandrecordedwithreal snapshot.

## 身份与预览

独立两遍0，5页文字、几何、1.5倍像素与作者PDF相同；20字体嵌，无诊断。旧B35实际批准快照和核心身份冻结。End96绑定原脚注1最后字，呼号/注体同页3；同页出现原97的第三子项不改变原96最后对象身份。共享99末锚留后单元。

- `chapters/ch07-unit02.tex` SHA256 `6abcaeaa6254a5a900e4df3e88fc5444f84804877baa0679536be39b2baf726c`；真实快照 `[project]\qa\approved-bytes\B\6abcaeaa6254a5a900e4df3e88fc5444f84804877baa0679536be39b2baf726c\book\chapters\ch07-unit02.tex`。
- `macros-C29.tex` SHA256 `9a0385f2d5a6dbd009345566e29b47e7e26c5182c5244d2ece1fbaa2be08533e`；真实快照 `[project]\qa\approved-bytes\B\9a0385f2d5a6dbd009345566e29b47e7e26c5182c5244d2ece1fbaa2be08533e\book\macros-C29.tex`。

不是整章验收。
