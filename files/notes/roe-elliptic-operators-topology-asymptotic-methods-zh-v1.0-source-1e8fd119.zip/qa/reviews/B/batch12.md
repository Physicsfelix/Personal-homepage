# Roe batch12 独立审校 B

结论：章4完整导语及首完整超代数单元分别 approved。原物52–54完整图逐段核，55仅后续语境；54只取页首中心分类与留读者验证一句，止Groups of invertibles标题前。B重新解码52–55四原生图，逐位等固定阅读PDF嵌图。

3编号环境4.1–3、普通编号段4.4、两完整原证明/7显示及所有普通段落齐，未补原书留给读者的证明。无新宏/图/脚注/SourceError。

- **Full chapter opening / Definition4.1**：Onecompleteintroductoryparagraphretainsallsubgroups/representations/geometricDiracpurposeandskip/returnguidance. Fourgradingproductinclusions, homogeneousunion,deg0conventionandepsilon construction retained. Incharacteristic0,epsilon²I decomposes into +/-1 eigenspaces, and automorphism property gives multiplication rules. Original deg(X) uppercase afterlowercasex actually seen on52 andkept as factual symbol-case difference; no unnecessary false-theorem SourceError introduced.
- **4.2 intrinsic parity**：Cliffordrelations interchange generators orremove2factors, preservingparity. Independently, universality extends v->-v to involutive automorphism, which acts(-1)^length on orderedmonomials, proving basis-independence. Original full short proof retained without adding QA proof tobook.
- **4.3 all steps /supercenter**：For homogeneousx=a+e1b of parityd witha,b excludinge1: a e1=(-1)^d e1a and e1 b e1=(-1)^(d-1)e1²b=(-1)^d b. Hence x e1=(-1)^d(e1a+b), whilee1x=e1a-b, so[x,e1]_s=2(-1)^d b. OverR/Cthisforcesb0; repeatforallbasisvectorsleavingscalar. Supercenter isgraded,so homogeneousreduction legitimate; zerodimensionalValreadyhas scalar algebra. Allthree calculationlinesandoriginalminus/e1²sign preserved.
- **Plain4.4 volume and ordinary center**：Reversek Cliffordgenerators requiresk(k-1)/2swaps and squaringeach contributes(-1)^k, givingomega²=(-1)^(k(k+1)/2). Movinggeneratoracrossvolume gives(-1)^(k-1)=(-1)^(k+1). Forevenk2m,Adomega negatesgenerators=grading,omega^-1=(-1)^momega; oddk2m+1,omega centraland square(-1)^(m+1). Apropernonempty monomialsubsetwouldneed evenlengthtocommutewithoutsidegenerator andoddlengthtocommutewithinsidegenerator,impossible;onlyempty and(fullsubsetwhenkodd)remain. This independentlychecks the statedcenterclassification, while original leavesverificationtoreaderandnoextrasolutionwasinserted.

2张当前译页全看，两遍独立冷编0，无缺字/未定义/overfull/underfull，各页几何/文字/像素等作者当前PDF `6a1bd0a0a28aad18fdf1c500a85157902fc8694e25156ece90c65c47ed189891`。另非空前页夹具两编且实看，Start52位于真正章页2。Start54取页首中心分类续句，End54留下一单元真实末对象，不误作为本批漏项。

旧B14数学输入、作者旧基线与root四份章1/2技术批准快照均保持；未改译稿/core。

- `chapters/ch04-intro.tex`：`b6b3be5cda4b8ce908d208a4edaa28e5b33073e76b312931c739207b46c51895`；真实快照 `[project]\qa\approved-bytes\B\b6b3be5cda4b8ce908d208a4edaa28e5b33073e76b312931c739207b46c51895\book\chapters\ch04-intro.tex`。
- `chapters/ch04-unit01.tex`：`e06073fad2fdcc7d8e6e4f1a9737642bb7b91b28f715c788eeeae5fd9f71af87`；真实快照 `[project]\qa\approved-bytes\B\e06073fad2fdcc7d8e6e4f1a9737642bb7b91b28f715c788eeeae5fd9f71af87\book\chapters\ch04-unit01.tex`。
