# Roe batch28 非作者 B 独审

状态：**approved**。章7完整opening与完整存在唯一性单位分别批准，原90–94全页及93/94原生细图、当前4译页全实际看。八对象、三编号式、14无号显示、五完整证明、7.6两子项、全部普通段落齐。原7.9的无条件无限正则性不作为真命题批准；忠实正文与分离注通过。

## Opening/7.1/whole7.4proof

Source90openingcompactRiemannM/CliffordS/DiracD andselfadjointzero-orderAextensionallretained. Sourceheatdt+D²andwave dt-iDsignsexact. Energyderivative-2||Ds||²validwithRoe first-slot-linearinnerproduct/selfadjointD;differenceofsolutionsgivesuniquenessC²space/C¹time. Spectralsolutione^-tD² s0smoothfort>0;alltime-derivativesareuniformspectralmultipliersoncompactpositivetimeintervals. Smoothinitials0givesallrightderivativesatt0viaD^(2j)s0andSobolevgraphestimates. Wavee^(itD)s0unitary/allrealtnormconservedandsmoothspectralcoefficients. Wholeoriginalshortwaveargumentandfinite-regularityuniquenesssentencepreserved, no newwaveproofinserted.

## 7.6 wholeproof/terminology-time note

Heatkernelpositive-t smoothfromrapiddecayfunctionalcalculus;D_p²actsfirstvariable,S_q*finiteparameterfactor. ActualoriginalcandidateonlyC²p/qandC¹t, notCinfty:callingit smoothingatstartisstrongerthanDefinition5.20allows, soseparatednoteaccurate. Forfixingt>0 take0<epsilon<t;candidateKtsclassicalheat/shiftedenergyuniquenessgivesKts=T_(t-epsilon)Kepss. UniformKepss->soncompactMimpliesL2. For epsilon<t/2, ||T_(t-eps)-T_t||<=epsilon sup_(x>=0) x exp(-tx/2)<=2epsilon/(e t),sooperatornormlimitvalid. ContractiontimesL2limitgivesKts=T_ts,testingall smooths identifiescontinuouskernels. Notequalifiesforwardboundedargument,doesnotdeclareidentityfalseonappropriateunboundeddomainsforlaterbackwardtimes.

## 7.8/7.9 actualsource regularity and counterexample

OriginalDefinition7.8mpositive/residualt^m rt/jointCmrtcontinuousdownt0retained. Native93explicitlyC²forcingandsmoothsolutionclaim, nohiddenCinftyhypothesis. OncircleD=i partialx, timeconstantf_m=(1+|m|)^-4 fornonzerom,f0=0; sums m^j|f_m|convergeforj<=2,givingC²forcing. Duhamelu_m=(1-e^-t m²)/(m²(1+|m|)^4). Atfixedt>0,m^6u_m->1,soif uC6 sixthderivativeFouriercoefficientswouldfailtend0,contradictingRiemannLebesgue. ThusnotCinfty, althoughuC4byabsolutesummabilityandclassicalequation/zeroinitialvaluehold. Noteaddressesonlyunlimitedregularityclaim,notDuhamelformulaorclassicaluniqueness. Fulloriginaldifferentiate-integralproofretained.

## 7.10 fullSobolevestimate

IteratedellipticGardingmakesWk-normequivalentfinitegraphnormsum_j<=k||D^j s||L2. SpectralTt=e^-tD²commutesD^jandcontractsL2,soisuniformlyboundedonWkforallpositivet. IntegratingDuhamelgives t Ck supforcingWk;finiteright-handestimateunderstoodwhereforcinghasthatSobolevregularity. No falseclaimC²datahasallSobolevorders; sourcewholeproofretained.

## 7.11 printedindices/fullproof/jointregularity

Ownnative94detailclearlyt^m r_m,C^m,next-t^m r_t,butlater||s||mprime<=C t^(mprime+1),whilehypothesisisordermprime. Source5wrongindicesretained,separatenoteproperlypointsdefinitionrequiresmprime. Withcorrectresidual-t^mprime rt,parameter-qDuhamelgives||partial_q^b s_t||W_p^(mprime-b)<=C t^(mprime+1),sincejointCmprime rtcontrolstheseSobolevnormsandheatsemigroupactsonponly. For totalorder a+b<=m, mprime>m+n/2impliesmprime-b>a+n/2;Sobolevembeddinginp givesalljointCmderivativescontinuously. Divideby t^m =>O(t^(mprime+1-m)),extend e0=0. Canchoosetheexistentialmprime sufficientlylargeforclassicaloperations;identificationkprime+s=kcanbetestedonsmoothsectionsandapplyspatialheatuniqueness,notrelyonfalselyassuminggenericDuhameldataCinfty. No mechanical doublingdimensionthresholdorfalsecounterexampleagainstasymptoticconclusion.

## 字节与预览

独立两遍0，4页文字、几何、1.5倍像素与作者PDF相同；18字体嵌，无诊断。旧A4/B33实际语义快照及核心身份冻结。Start90在清页章命令之后，实际同章页；共享94末锚留后单元。定义7.8在页3一行盒续文完整可读，未删补来源。

- `chapters/ch07-intro.tex` SHA256 `de9e07c30bb0144ba4fe1808fe0d44fa424aa3eaf78ed5df66d29ee9eb44d27e`；真实快照 `[project]\qa\approved-bytes\B\de9e07c30bb0144ba4fe1808fe0d44fa424aa3eaf78ed5df66d29ee9eb44d27e\book\chapters\ch07-intro.tex`。
- `chapters/ch07-unit01.tex` SHA256 `27aefd88a5bec7044d7a7b66a6cdaf7f4adf48aadfc696e5d5692de443237653`；真实快照 `[project]\qa\approved-bytes\B\27aefd88a5bec7044d7a7b66a6cdaf7f4adf48aadfc696e5d5692de443237653\book\chapters\ch07-unit01.tex`。

不作整章验收。
